"use strict";
(() => {
  // packages/extension/src/devtools.ts
  chrome.devtools.panels.create("breakhound", "icons/32.png", "panel.html", () => {
  });
})();
