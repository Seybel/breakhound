"use strict";
(() => {
  // packages/engine/src/bridge.ts
  var BRIDGE_PORTS = Array.from({ length: 10 }, (_, i) => 47821 + i);

  // packages/extension/src/shims/crypto.ts
  function sha1(bytes) {
    const length = bytes.length;
    const words = new Uint32Array(((length + 8 >> 6) + 1) * 16);
    const or = (i, bits) => {
      words[i] = words[i] | bits;
    };
    for (let i = 0; i < length; i++) or(i >> 2, bytes[i] << 24 - i % 4 * 8);
    or(length >> 2, 128 << 24 - length % 4 * 8);
    words[words.length - 1] = length * 8;
    let h0 = 1732584193;
    let h1 = 4023233417;
    let h2 = 2562383102;
    let h3 = 271733878;
    let h4 = 3285377520;
    const w = new Uint32Array(80);
    for (let block = 0; block < words.length; block += 16) {
      for (let t = 0; t < 16; t++) w[t] = words[block + t];
      for (let t = 16; t < 80; t++) {
        const x2 = w[t - 3] ^ w[t - 8] ^ w[t - 14] ^ w[t - 16];
        w[t] = x2 << 1 | x2 >>> 31;
      }
      let a = h0;
      let b = h1;
      let c = h2;
      let d = h3;
      let e = h4;
      for (let t = 0; t < 80; t++) {
        let f;
        let k;
        if (t < 20) {
          f = b & c | ~b & d;
          k = 1518500249;
        } else if (t < 40) {
          f = b ^ c ^ d;
          k = 1859775393;
        } else if (t < 60) {
          f = b & c | b & d | c & d;
          k = 2400959708;
        } else {
          f = b ^ c ^ d;
          k = 3395469782;
        }
        const temp = (a << 5 | a >>> 27) + f + e + k + w[t] >>> 0;
        e = d;
        d = c;
        c = b << 30 | b >>> 2;
        b = a;
        a = temp;
      }
      h0 = h0 + a >>> 0;
      h1 = h1 + b >>> 0;
      h2 = h2 + c >>> 0;
      h3 = h3 + d >>> 0;
      h4 = h4 + e >>> 0;
    }
    return [h0, h1, h2, h3, h4].map((h5) => (h5 >>> 0).toString(16).padStart(8, "0")).join("");
  }
  function createHash(algorithm) {
    if (algorithm !== "sha1") throw new Error(`Only sha1 is available here, not ${algorithm}`);
    const chunks = [];
    const hash = {
      update(data) {
        chunks.push(data);
        return hash;
      },
      digest(encoding) {
        if (encoding !== "hex")
          throw new Error(`Only hex digests are available here, not ${encoding}`);
        return sha1(new TextEncoder().encode(chunks.join("")));
      }
    };
    return hash;
  }

  // packages/engine/src/issues.ts
  var DESIGNED_IF_AT_WIDEST = /* @__PURE__ */ new Set(["clipped-text"]);
  var FIXED_WIDTH_DETECTORS = /* @__PURE__ */ new Set(["page-overflow", "content-overflow"]);
  var OVERFLOW_PRIORITY = ["page-overflow", "media-overflow", "content-overflow"];
  var RELATED_IS_EXAMPLE = /* @__PURE__ */ new Set(["clipped-text", "small-tap-target", "tiny-text"]);
  var INACTIVE = "inactive";
  function findingKey(f) {
    const related = RELATED_IS_EXAMPLE.has(f.detector) ? "" : f.related?.selector ?? "";
    return `${f.detector}|${f.element.selector}|${related}`;
  }
  function severityScore(f) {
    const e = f.evidence;
    if (typeof e.overflowPx === "number") return e.overflowPx;
    if (typeof e.overlapWidth === "number" && typeof e.overlapHeight === "number") {
      return e.overlapWidth * e.overlapHeight;
    }
    if (typeof e.lines === "number") return e.lines;
    return 0;
  }
  function wrapFindings(widths, results) {
    const baseline = /* @__PURE__ */ new Map();
    for (let i = widths.length - 1; i >= 0; i--) {
      const r = results.get(widths[i]);
      for (const w of r?.wraps ?? []) {
        const key = `${w.kind}|${w.element.selector}`;
        if (!baseline.has(key)) baseline.set(key, w.lines);
      }
    }
    const out = /* @__PURE__ */ new Map();
    for (const width of widths) {
      const list = [];
      for (const w of results.get(width)?.wraps ?? []) {
        const base = baseline.get(`${w.kind}|${w.element.selector}`);
        if (base !== 1 || w.lines <= 1) continue;
        list.push({
          detector: "unexpected-wrap",
          severity: "warning",
          title: w.kind === "row" ? `Row of ${w.items} items wraps onto ${w.lines} lines` : `Label wraps onto ${w.lines} lines`,
          element: w.element,
          evidence: { lines: w.lines, linesAtWidest: base, items: w.items },
          styles: {},
          suggestion: w.kind === "row" ? "Collapse this row into a menu below this width, tighten its spacing, or let it scroll sideways." : "Shorten the label, reduce its padding, or give the button room to grow at this width."
        });
      }
      out.set(width, list);
    }
    return out;
  }
  function dedupe(findings) {
    const bestOverflow = /* @__PURE__ */ new Map();
    for (const f of findings) {
      const rank = OVERFLOW_PRIORITY.indexOf(f.detector);
      if (rank === -1) continue;
      const prev = bestOverflow.get(f.element.selector);
      if (prev === void 0 || rank < prev) bestOverflow.set(f.element.selector, rank);
    }
    return findings.filter((f) => {
      const rank = OVERFLOW_PRIORITY.indexOf(f.detector);
      return rank === -1 || bestOverflow.get(f.element.selector) === rank;
    });
  }
  function issueId(route, f) {
    return createHash("sha1").update(`${route}|${findingKey(f)}`).digest("hex").slice(0, 10);
  }
  function buildIssues(route, widths, results) {
    const wraps = wrapFindings(widths, results);
    const perWidth = /* @__PURE__ */ new Map();
    for (const width of widths) {
      const all = dedupe([...results.get(width)?.findings ?? [], ...wraps.get(width) ?? []]);
      perWidth.set(width, new Map(all.map((f) => [findingKey(f), f])));
    }
    const keys = /* @__PURE__ */ new Set();
    for (const m of perWidth.values()) for (const k of m.keys()) keys.add(k);
    const widest = [...widths].reverse().find((w) => results.get(w)?.signature !== INACTIVE);
    const issues = [];
    const lineages = /* @__PURE__ */ new Map();
    for (const key of keys) {
      const ranges = [];
      let worst = null;
      let open = null;
      const elementWidths = /* @__PURE__ */ new Set();
      const atWidest = widest !== void 0 ? perWidth.get(widest)?.get(key) : void 0;
      if (atWidest && DESIGNED_IF_AT_WIDEST.has(atWidest.detector)) continue;
      for (const width of widths) {
        const f2 = perWidth.get(width)?.get(key);
        if (f2) {
          if (typeof f2.evidence.elementWidth === "number") elementWidths.add(f2.evidence.elementWidth);
          if (open) open.to = width;
          else {
            open = { from: width, to: width };
            ranges.push(open);
          }
          if (!worst || severityScore(f2) > severityScore(worst.finding))
            worst = { width, finding: f2 };
        } else {
          open = null;
        }
      }
      if (!worst) continue;
      const f = worst.finding;
      let evidence = f.evidence;
      let suggestion = f.suggestion;
      const spansWidths = ranges.some((r) => r.to > r.from);
      const [onlyWidth] = elementWidths;
      if (FIXED_WIDTH_DETECTORS.has(f.detector) && elementWidths.size === 1 && spansWidths && onlyWidth !== void 0 && !f.evidence.causedByText) {
        evidence = { ...evidence, fixedWidthPx: onlyWidth };
        suggestion = `It stays ${onlyWidth}px wide no matter the screen size. Replace the fixed width with max-width: 100% (or a fluid width) so it can shrink.`;
      }
      const issue = {
        id: issueId(route, f),
        fingerprint: findingKey(f),
        detector: f.detector,
        severity: f.severity,
        title: f.title,
        ranges,
        worstAt: worst.width,
        element: { ...f.element, source: f.element.source ?? null },
        ...f.related ? { related: f.related } : {},
        evidence,
        styles: f.styles,
        ...suggestion ? { suggestion } : {}
      };
      issues.push(issue);
      if (f.lineage) lineages.set(issue, f.lineage);
    }
    const order = { error: 0, warning: 1, info: 2 };
    return mergeRepeats(mergeOverflowFamily(issues, lineages)).sort(
      (a, b) => order[a.severity] - order[b.severity] || (a.ranges[0]?.from ?? 0) - (b.ranges[0]?.from ?? 0)
    );
  }
  function joinRanges(ranges) {
    const sorted = [...ranges].sort((a, b) => a.from - b.from);
    const out = [];
    for (const r of sorted) {
      const last = out[out.length - 1];
      if (last && r.from <= last.to + 1) last.to = Math.max(last.to, r.to);
      else out.push({ ...r });
    }
    return out;
  }
  function mergeOverflowFamily(issues, lineages) {
    const family = new Set(OVERFLOW_PRIORITY);
    const byElement = /* @__PURE__ */ new Map();
    const out = [];
    const leads = [];
    for (const issue of issues) {
      if (!family.has(issue.detector)) {
        out.push(issue);
        continue;
      }
      const list = byElement.get(issue.element.selector);
      if (list) list.push(issue);
      else byElement.set(issue.element.selector, [issue]);
    }
    for (const list of byElement.values()) {
      const [lead, ...rest2] = list.sort(
        (a, b) => OVERFLOW_PRIORITY.indexOf(a.detector) - OVERFLOW_PRIORITY.indexOf(b.detector)
      );
      if (!lead) continue;
      if (rest2.length) {
        lead.ranges = joinRanges(list.flatMap((i) => i.ranges));
        lead.evidence = { ...lead.evidence, alsoReportedAs: rest2.map((i) => i.detector).join(", ") };
        if (!lead.related) {
          const withRelated = rest2.find((i) => i.related);
          if (withRelated?.related) lead.related = withRelated.related;
        }
        const lineage = rest2.map((i) => lineages.get(i)).find(Boolean);
        if (!lineages.has(lead) && lineage) lineages.set(lead, lineage);
      }
      leads.push(lead);
    }
    return [...out, ...mergeNested(leads, lineages)];
  }
  function selectorTemplate(selector) {
    return selector.replace(/:nth-(?:of-type|child)\(\d+\)/g, "");
  }
  function mergeRepeats(issues) {
    const groups = /* @__PURE__ */ new Map();
    const out = [];
    for (const issue of issues) {
      const template = selectorTemplate(issue.element.selector);
      if (template === issue.element.selector) {
        out.push(issue);
        continue;
      }
      const key = `${issue.detector}|${template}|${issue.title.replace(/\d+/g, "#")}`;
      const list = groups.get(key);
      if (list) list.push(issue);
      else groups.set(key, [issue]);
    }
    for (const list of groups.values()) {
      const [lead, ...rest2] = list;
      if (!lead) continue;
      const alike = rest2.filter((i) => touches(i.ranges, lead.ranges));
      out.push(...rest2.filter((i) => !alike.includes(i)));
      if (alike.length) {
        const count = alike.length + 1;
        lead.ranges = joinRanges([lead, ...alike].flatMap((i) => i.ranges));
        lead.title = `${lead.title} (${count} places)`;
        lead.evidence = { ...lead.evidence, similarElements: count };
      }
      out.push(lead);
    }
    return out;
  }
  function touches(a, b) {
    return a.some((x2) => b.some((y) => x2.from <= y.to + 1 && y.from <= x2.to + 1));
  }
  function mergeNested(leads, lineages) {
    const bySelector = new Map(leads.map((i) => [i.element.selector, i]));
    const inner = /* @__PURE__ */ new Map();
    const absorbed = /* @__PURE__ */ new Set();
    const deepestFirst = [...leads].sort(
      (a, b) => (lineages.get(b)?.length ?? 0) - (lineages.get(a)?.length ?? 0)
    );
    const rank = { error: 0, warning: 1, info: 2 };
    for (const issue of deepestFirst) {
      for (const selector of lineages.get(issue) ?? []) {
        const outer = bySelector.get(selector);
        if (!outer || outer === issue || absorbed.has(outer)) continue;
        if (!touches(issue.ranges, outer.ranges)) continue;
        outer.ranges = joinRanges([...outer.ranges, ...issue.ranges]);
        if (rank[issue.severity] < rank[outer.severity]) outer.severity = issue.severity;
        inner.set(outer, [
          ...inner.get(outer) ?? [],
          issue.element.selector,
          ...inner.get(issue) ?? []
        ]);
        absorbed.add(issue);
        break;
      }
    }
    for (const [outer, selectors] of inner) {
      outer.evidence = { ...outer.evidence, alsoOverflowing: selectors.join(", ") };
    }
    return leads.filter((i) => !absorbed.has(i));
  }
  function buildBreakpoints(tabs, declared, minWidth, maxWidth) {
    const found = /* @__PURE__ */ new Set();
    const switched = /* @__PURE__ */ new Set();
    for (const results of tabs) {
      const widths = [...results.keys()].sort((a, b) => a - b);
      for (let i = 1; i < widths.length; i++) {
        const prev = results.get(widths[i - 1]);
        const cur = results.get(widths[i]);
        if (!prev || !cur) continue;
        if (prev.signature !== cur.signature) found.add(widths[i]);
        if ((prev.containers ?? "") !== (cur.containers ?? "")) switched.add(widths[i]);
      }
    }
    const observed = [...found].sort((a, b) => a - b);
    const containers = [...switched].sort((a, b) => a - b);
    const inRange = declared.filter((w) => w > minWidth && w <= maxWidth);
    const explained = [...inRange, ...containers];
    return {
      observed,
      declared: inRange,
      ...containers.length ? { containers } : {},
      unexplained: observed.filter((w) => !explained.some((d) => Math.abs(d - w) <= 1))
    };
  }

  // packages/engine/src/result.ts
  function createScanResult(routes, meta) {
    const bySeverity = { error: 0, warning: 0, info: 0 };
    const unique = /* @__PURE__ */ new Set();
    let issues = 0;
    for (const r of routes) {
      for (const issue of r.issues) {
        issues++;
        if (unique.has(issue.fingerprint)) continue;
        unique.add(issue.fingerprint);
        bySeverity[issue.severity]++;
      }
    }
    return {
      schemaVersion: 1,
      tool: { name: "breakhound", version: meta.version },
      project: {
        framework: meta.framework ?? null,
        baseUrl: meta.baseUrl ?? null,
        root: meta.root ?? null
      },
      startedAt: meta.startedAt.toISOString(),
      durationMs: Date.now() - meta.startedAt.getTime(),
      settings: {
        minWidth: meta.minWidth,
        maxWidth: meta.maxWidth,
        step: meta.step,
        browsers: meta.browsers ?? ["chromium"]
      },
      routes,
      summary: { routes: routes.length, issues, uniqueIssues: unique.size, bySeverity },
      ...meta.from ? { from: meta.from } : {}
    };
  }

  // packages/engine/src/settle.ts
  var RESIZE_PROBE = `(() => {
  const MAX_DEPTH = 3;
  const MAX_DELAY = 2000;
  let depth = 0;
  let pending = 0;
  let listeners = 0;
  const live = new Map();
  const nativeSetTimeout = window.setTimeout;
  const nativeClearTimeout = window.clearTimeout;

  const tracked = (fn, level) => function (...args) {
    const prev = depth;
    depth = level;
    try {
      return typeof fn === 'function' ? fn.apply(this, args) : fn.handleEvent(...args);
    } finally {
      depth = prev;
    }
  };

  window.setTimeout = function (fn, delay, ...args) {
    if (depth === 0 || depth > MAX_DEPTH || typeof fn !== 'function' || (Number(delay) || 0) > MAX_DELAY) {
      return nativeSetTimeout.call(window, fn, delay, ...args);
    }
    pending++;
    let open = true;
    const settle = () => { if (open) { open = false; pending--; } };
    const level = depth + 1;
    const run = tracked(fn, level);
    const id = nativeSetTimeout.call(window, function (...a) {
      live.delete(id);
      try { return run.apply(this, a); } finally { settle(); }
    }, delay, ...args);
    live.set(id, settle);
    return id;
  };
  window.clearTimeout = function (id) {
    const settle = live.get(id);
    if (settle) { live.delete(id); settle(); }
    return nativeClearTimeout.call(window, id);
  };

  const wrappers = new WeakMap();
  const wrap = (listener) => {
    if (!listener) return listener;
    let w = wrappers.get(listener);
    if (!w) { w = tracked(listener, 1); wrappers.set(listener, w); }
    return w;
  };

  const add = EventTarget.prototype.addEventListener;
  const remove = EventTarget.prototype.removeEventListener;
  const watched = (target, type) =>
    (target === window && type === 'resize') ||
    (typeof MediaQueryList !== 'undefined' && target instanceof MediaQueryList && type === 'change');
  EventTarget.prototype.addEventListener = function (type, listener, options) {
    if (watched(this, type) && listener) {
      listeners++;
      return add.call(this, type, wrap(listener), options);
    }
    return add.call(this, type, listener, options);
  };
  EventTarget.prototype.removeEventListener = function (type, listener, options) {
    if (watched(this, type) && listener && wrappers.has(listener)) {
      return remove.call(this, type, wrappers.get(listener), options);
    }
    return remove.call(this, type, listener, options);
  };
  if (typeof MediaQueryList !== 'undefined') {
    const legacyAdd = MediaQueryList.prototype.addListener;
    const legacyRemove = MediaQueryList.prototype.removeListener;
    MediaQueryList.prototype.addListener = function (l) { listeners++; return legacyAdd.call(this, wrap(l)); };
    MediaQueryList.prototype.removeListener = function (l) { return legacyRemove.call(this, wrappers.get(l) || l); };
  }
  if (typeof ResizeObserver !== 'undefined') {
    const Native = ResizeObserver;
    window.ResizeObserver = class extends Native {
      constructor(callback) { listeners++; super(tracked(callback, 1)); }
    };
  }

  Object.defineProperty(window, '__breakhound_settle', {
    value: { pending: () => pending, listeners: () => listeners + (window.onresize ? 1 : 0) },
  });
})();`;
  var FREEZE_CSS = `
*, *::before, *::after {
  animation-duration: 0s !important;
  animation-delay: 0s !important;
  animation-iteration-count: 1 !important;
  transition: none !important;
  caret-color: transparent !important;
  scroll-behavior: auto !important;
}`;
  async function settleResize(page, maxWaitMs) {
    await page.evaluate((maxWait) => window.__breakhound?.settleAfterResize(maxWait), maxWaitMs);
  }

  // packages/engine/src/sweep.ts
  function coarseWidths(minWidth, maxWidth, step) {
    const out = [];
    for (let w = minWidth; w < maxWidth; w += step) out.push(w);
    out.push(maxWidth);
    return out;
  }
  var REFINE_BUDGET_PER_WIDTH = 6;
  function stateKey(r) {
    const findings = r.findings.map(findingKey).sort().join(",");
    const wraps = r.wraps.map((w) => `${w.kind}|${w.element.selector}|${w.lines}`).sort().join(",");
    return `${r.signature}#${findings}#${wraps}#${r.containers ?? ""}`;
  }
  var Sweeper = class {
    constructor(page, settings, prepare) {
      this.page = page;
      this.settings = settings;
      this.prepare = prepare;
    }
    page;
    settings;
    prepare;
    results = /* @__PURE__ */ new Map();
    /**
     * True when the page's layout changed while nobody resized it (an
     * auto-playing carousel, live data): measuring the same width twice
     * disagreed, or bisection ran out of budget chasing changes.
     */
    unstable = false;
    keys = /* @__PURE__ */ new Map();
    async measure(width) {
      const cached = this.results.get(width);
      if (cached) return cached;
      const result = await this.analyzeAt(width);
      this.results.set(width, result);
      this.keys.set(width, stateKey(result));
      this.settings.onMeasure?.(width, result);
      return result;
    }
    async analyzeAt(width) {
      await this.page.setViewportSize({ width, height: this.settings.height });
      await settleResize(this.page, this.settings.maxSettleMs);
      return this.analyzeHere(width);
    }
    async analyzeHere(width) {
      if (this.prepare && !await this.prepare(width)) {
        return { width, findings: [], wraps: [], signature: INACTIVE };
      }
      return this.page.evaluate((opts) => {
        const api = window.__breakhound;
        if (!api) throw new Error("breakhound analyzers were not injected into the page");
        return api.analyze(opts);
      }, this.settings.analyze);
    }
    /** Measures a width from a different starting layout without touching the cache. */
    async probe(width) {
      const { minWidth, maxWidth, height } = this.settings;
      const away = width - minWidth > maxWidth - width ? minWidth : maxWidth;
      await this.page.setViewportSize({ width: away, height });
      await settleResize(this.page, this.settings.maxSettleMs);
      await this.page.setViewportSize({ width, height });
      await settleResize(this.page, this.settings.maxSettleMs);
      return this.analyzeHere(width);
    }
    key(width) {
      return this.keys.get(width) ?? "";
    }
    /** Coarse pass over the given widths, then bisect every interval whose state changed. */
    async run(coarse) {
      if (this.settings.order === "ascending") return this.runAscending(coarse);
      for (const w of coarse) await this.measure(w);
      let budget = Math.max(64, coarse.length * REFINE_BUDGET_PER_WIDTH);
      const queue = [];
      for (let i = 0; i < coarse.length - 1; i++) {
        queue.push([coarse[i], coarse[i + 1]]);
      }
      for (let next = queue.shift(); next; next = queue.shift()) {
        const [a, b] = next;
        if (b - a <= 1 || this.key(a) === this.key(b)) continue;
        if (budget-- <= 0) {
          this.unstable = true;
          return;
        }
        const mid = Math.floor((a + b) / 2);
        await this.measure(mid);
        queue.push([a, mid], [mid, b]);
      }
      if (coarse.length < 2) return;
      const again = /* @__PURE__ */ new Set([
        coarse[0],
        coarse[Math.floor(coarse.length / 2)],
        coarse[coarse.length - 1]
      ]);
      for (const w of again) {
        if (w === void 0) continue;
        if (stateKey(await this.analyzeAt(w)) !== this.key(w)) {
          this.unstable = true;
          return;
        }
      }
    }
    /** The same measurements as the breadth-first run, taken from narrowest to widest. */
    async runAscending(coarse) {
      let budget = Math.max(64, coarse.length * REFINE_BUDGET_PER_WIDTH);
      const refine = async (a, b) => {
        if (b - a <= 1 || this.key(a) === this.key(b)) return;
        if (budget-- <= 0) {
          this.unstable = true;
          return;
        }
        const mid = Math.floor((a + b) / 2);
        await this.measure(mid);
        await refine(a, mid);
        await refine(mid, b);
      };
      for (let i = 0; i < coarse.length; i++) {
        await this.measure(coarse[i]);
        if (i > 0) await refine(coarse[i - 1], coarse[i]);
      }
      const back = coarse[coarse.length - 2];
      if (back !== void 0) {
        const again = await this.analyzeAt(back);
        if (stateKey(again) !== this.key(back)) this.unstable = true;
      }
    }
  };
  var CONFIRM_BELOW_PX = 3;
  async function confirmNarrowIssues(issues, sweeper) {
    const kept = [];
    for (const issue of issues) {
      const narrow = issue.ranges.every((r) => r.to - r.from < CONFIRM_BELOW_PX);
      if (!narrow || issue.detector === "unexpected-wrap") {
        kept.push(issue);
        continue;
      }
      const again = await sweeper.probe(issue.worstAt);
      const reproduced = again.findings.some((f) => findingKey(f) === issue.fingerprint);
      if (reproduced) kept.push(issue);
    }
    return kept;
  }

  // packages/report/src/format.ts
  var DETECTOR_LABELS = {
    "page-overflow": "Horizontal overflow",
    "content-overflow": "Content spills out",
    "media-overflow": "Media too wide",
    overlap: "Overlap",
    "unexpected-wrap": "Unexpected wrap",
    "clipped-text": "Clipped text",
    "squished-text": "Squished text",
    "distorted-media": "Distorted image",
    "small-tap-target": "Small tap target",
    "tiny-text": "Tiny text",
    "oversized-text": "Oversized text",
    "edge-gutter": "No edge spacing",
    "viewport-meta": "Viewport meta",
    vision: "Looks off"
  };
  var SEVERITY_ORDER = { error: 0, warning: 1, info: 2 };
  function formatRange(r) {
    return r.from === r.to ? `${r.from}px` : `${r.from}\u2013${r.to}px`;
  }
  function formatRanges(ranges) {
    return ranges.map(formatRange).join(", ");
  }
  function groupIssues(result) {
    const groups = /* @__PURE__ */ new Map();
    for (const route of result.routes) {
      for (const issue of route.issues) {
        const g = groups.get(issue.fingerprint);
        if (g) g.routes.push({ route, issue });
        else
          groups.set(issue.fingerprint, {
            fingerprint: issue.fingerprint,
            issue,
            route,
            routes: [{ route, issue }]
          });
      }
    }
    return [...groups.values()].sort(
      (a, b) => SEVERITY_ORDER[a.issue.severity] - SEVERITY_ORDER[b.issue.severity] || b.routes.length - a.routes.length || (a.issue.ranges[0]?.from ?? 0) - (b.issue.ranges[0]?.from ?? 0)
    );
  }
  function evidenceText(issue) {
    return Object.entries(issue.evidence).map(([k, v]) => `${k.replace(/([A-Z])/g, " $1").toLowerCase()}: ${v}`).join(", ");
  }
  function openInstruction(state2) {
    const verb = state2.kind === "details" ? "expand" : "click";
    const name = state2.label !== state2.kind ? ` ("${state2.label}")` : "";
    return `${verb} \`${state2.trigger}\`${name}`;
  }
  function routeLabel(route) {
    return route.route || new URL(route.url).pathname;
  }

  // packages/report/src/markdown.ts
  function alsoOn(group) {
    return group.routes.length > 1 ? group.routes.slice(1).map((r) => routeLabel(r.route)).join(", ") : "";
  }
  function sourceText(source) {
    if (!source) return null;
    const at = source.line ? `${source.file}:${source.line}` : source.file;
    const component = source.component ? ` (${source.component})` : "";
    return source.exact ? `\`${at}\`${component}` : `inside \`${at}\`${component}`;
  }
  function issueBlock(issue, heading, extra, imageBase) {
    const lines = [heading, ""];
    lines.push(`- **Widths:** ${formatRanges(issue.ranges)} (worst at ${issue.worstAt}px)`);
    if (issue.state) lines.push(`- **Open first:** ${openInstruction(issue.state)}`);
    lines.push(`- **Element:** \`${issue.element.selector}\` (${issue.element.path})`);
    const source = sourceText(issue.element.source);
    if (source) lines.push(`- **Source:** ${source}`);
    if (issue.related) lines.push(`- **Related element:** \`${issue.related.selector}\``);
    lines.push(`- **HTML:** \`${issue.element.html.replace(/`/g, "'")}\``);
    if (Object.keys(issue.evidence).length) lines.push(`- **Evidence:** ${evidenceText(issue)}`);
    const styles = Object.entries(issue.styles);
    if (styles.length)
      lines.push(`- **Computed styles:** ${styles.map(([k, v]) => `${k}: ${v}`).join("; ")}`);
    if (issue.suggestion) lines.push(`- **Likely fix:** ${issue.suggestion}`);
    lines.push(...extra);
    if (imageBase !== null && issue.screenshot) {
      lines.push("", `![${issue.title}](${imageBase}${issue.screenshot})`);
    }
    lines.push("");
    return lines;
  }
  function renderPrompt(result, options = {}) {
    const severities = new Set(options.severities ?? ["error", "warning"]);
    const only = options.fingerprints ? new Set(options.fingerprints) : null;
    const groups = groupIssues(result).filter(
      (g) => severities.has(g.issue.severity) && (!only || only.has(g.fingerprint))
    );
    const { minWidth, maxWidth } = result.settings;
    const lines = [
      "# Fix these responsive layout issues",
      "",
      `Each issue below was measured in a real browser by resizing the page from ${minWidth}px to ${maxWidth}px. Widths are viewport widths in CSS pixels and are exact.`,
      "",
      "Rules:",
      "- Fix the cause in the source code (styles, markup or component), not by hiding the symptom with overflow: hidden.",
      "- Keep the layout the same at widths that are not listed.",
      "- Shared components may be the cause of issues listed on several pages; fix them once."
    ];
    if (options.verifyCommand) {
      lines.push(
        `- When you are done, run \`${options.verifyCommand}\` and keep going until it reports no remaining issues and no new ones. It compares with the scan these issues came from, so it also catches anything the fix broke at other widths or on other pages.`,
        '- Once a page verifies clean, run `npx @seybel/breakhound checkpoint <route> -m "<what you changed>"` to commit that fix on its own, so it can be undone later with `npx @seybel/breakhound undo <route>`.'
      );
    }
    lines.push("");
    if (!groups.length) {
      lines.push("No issues to fix.");
      return lines.join("\n");
    }
    groups.sort((a, b) => SEVERITY_ORDER[a.issue.severity] - SEVERITY_ORDER[b.issue.severity]).forEach((g, i) => {
      const pages = alsoOn(g);
      lines.push(
        ...issueBlock(
          g.issue,
          `## ${i + 1}. [${g.issue.severity}] ${g.issue.title}`,
          [
            `- **Page:** ${routeLabel(g.route)} (${g.route.url})`,
            ...pages ? [`- **Also on:** ${pages}`] : []
          ],
          null
        )
      );
    });
    return lines.join("\n");
  }

  // packages/extension/src/agent.ts
  async function call(port, path, body, options = {}) {
    const signals = [AbortSignal.timeout(options.timeoutMs ?? 5e3)];
    if (options.signal) signals.push(options.signal);
    const res = await fetch(`http://127.0.0.1:${port}/breakhound/${path}`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(body),
      signal: AbortSignal.any(signals)
    });
    const reply = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(reply.error ?? `breakhound answered ${res.status}`);
    return reply;
  }
  async function findServers() {
    const found = await Promise.all(
      BRIDGE_PORTS.map(async (port) => {
        try {
          const hello = await call(
            port,
            "hello",
            {},
            { timeoutMs: 1500 }
          );
          return hello.name === "breakhound" ? { ...hello, port } : null;
        } catch {
          return null;
        }
      })
    );
    return found.filter((s) => s !== null);
  }
  function byProject(servers) {
    const seen = /* @__PURE__ */ new Map();
    for (const s of servers) if (!seen.has(s.root)) seen.set(s.root, s);
    return [...seen.values()];
  }
  async function serving(servers, url) {
    const answers = await Promise.all(
      servers.map(
        (s) => call(s.port, "match", { url }, { timeoutMs: 4e3 }).then((r) => r.matches).catch(() => false)
      )
    );
    return servers.filter((_, i) => answers[i]);
  }
  function sendScan(server, result) {
    return call(server.port, "scan", { result }, { timeoutMs: 3e4 });
  }
  async function nextCheck(server, origin, signal) {
    const reply = await call(
      server.port,
      "checks",
      { origin },
      { timeoutMs: 35e3, signal }
    );
    return reply.check;
  }
  function checkProgress(server, id, done, message) {
    call(server.port, "checks/progress", { id, done, message }).catch(() => {
    });
  }
  function checkDone(server, id, outcome) {
    return call(server.port, "checks/done", { id, ...outcome }, { timeoutMs: 3e4 });
  }

  // packages/extension/src/cdp.ts
  var Cancelled = class extends Error {
    constructor() {
      super("Stopped");
    }
  };
  var CHECK_EVERY_MS = 2e3;
  var pause = (ms) => new Promise((r) => setTimeout(() => r("waiting"), ms));
  async function tabHidden(cdp) {
    const asked = cdp.send("Runtime.evaluate", {
      expression: "document.visibilityState",
      returnByValue: true
    }).then((r) => r.result?.value === "hidden").catch(() => null);
    return Promise.race([asked, pause(1e3).then(() => null)]);
  }
  async function evaluate(cdp, fn, arg, timeoutMs = 2e4) {
    const expression = typeof fn === "string" ? fn : `(${fn.toString()})(${arg === void 0 ? "" : JSON.stringify(arg)})`;
    const sent = cdp.send("Runtime.evaluate", {
      expression,
      awaitPromise: true,
      returnByValue: true
    });
    sent.catch(() => {
    });
    let silentFor = 0;
    let hidden = false;
    try {
      for (; ; ) {
        const step = Math.min(CHECK_EVERY_MS, timeoutMs);
        const reply = await Promise.race([sent, pause(step)]);
        if (reply !== "waiting") {
          if (reply.exceptionDetails) {
            const d = reply.exceptionDetails;
            throw new Error(d.exception?.description?.split("\n")[0] ?? d.text ?? "The page threw");
          }
          return reply.result?.value;
        }
        const nowHidden = await tabHidden(cdp);
        if (nowHidden) {
          if (!hidden) cdp.onHidden?.(true);
          hidden = true;
          silentFor = 0;
          continue;
        }
        if (hidden && nowHidden === false) {
          hidden = false;
          cdp.onHidden?.(false);
        }
        silentFor += step;
        if (silentFor >= timeoutMs) {
          throw new Error(
            "The page stopped responding: it was busy for too long, paused in the debugger, or showing a dialog."
          );
        }
      }
    } finally {
      if (hidden) cdp.onHidden?.(false);
    }
  }
  function tabPage(cdp, options = {}) {
    return {
      async setViewportSize({ width, height }) {
        if (options.cancelled?.()) throw new Cancelled();
        options.onResize?.(width);
        await setWidth(cdp, width, height, options.fit);
      },
      evaluate: ((fn, arg) => evaluate(cdp, fn, arg))
    };
  }
  function fitScale(width, fit) {
    return fit && width > fit.width ? fit.width / width : 1;
  }
  async function setWidth(cdp, width, height, fit) {
    const scale = fitScale(width, fit);
    const h2 = height || (fit && scale < 1 ? Math.round(fit.height / scale) : 0);
    await cdp.send("Emulation.setDeviceMetricsOverride", {
      width,
      height: h2,
      deviceScaleFactor: 0,
      mobile: false,
      screenWidth: width,
      screenHeight: h2 || fit?.height || 0,
      dontSetVisibleSize: true,
      ...scale < 1 ? { scale } : {}
    });
  }

  // packages/extension/src/scan.ts
  var TAB_DEFAULTS = {
    minWidth: 320,
    maxWidth: 1920,
    step: 16,
    height: 900,
    maxSettleMs: 1e3
  };
  var RELOAD_TIMEOUT_MS = 6e4;
  var FREEZE_ATTR = "data-breakhound-freeze";
  function routeOf(href) {
    const url = new URL(href);
    return url.hash.startsWith("#/") ? `${url.pathname}${url.hash.split("?")[0]}` : url.pathname;
  }
  var pause2 = (ms) => new Promise((r) => setTimeout(r, ms));
  async function addTracking(cdp, analyzerScript) {
    await cdp.send("Page.enable");
    const ids = [];
    for (const source of [RESIZE_PROBE, analyzerScript]) {
      const { identifier } = await cdp.send(
        "Page.addScriptToEvaluateOnNewDocument",
        { source }
      );
      ids.push(identifier);
    }
    return ids;
  }
  async function removeTracking(cdp, ids) {
    for (const identifier of ids) {
      await cdp.send("Page.removeScriptToEvaluateOnNewDocument", { identifier }).catch(() => {
      });
    }
  }
  async function loadPage(cdp, url) {
    const here = await evaluate(cdp, () => location.href);
    const sameDocument = url !== null && new URL(url).hash.startsWith("#/") && new URL(url).href.split("#")[0] === here.split("#")[0];
    if (sameDocument) {
      await evaluate(
        cdp,
        (to) => {
          location.href = to;
        },
        url
      );
    } else {
      await evaluate(cdp, () => {
        window.__breakhound_old = true;
      });
      if (url === null) await cdp.send("Page.reload", { ignoreCache: false });
      else await cdp.send("Page.navigate", { url });
      const deadline = Date.now() + RELOAD_TIMEOUT_MS;
      for (; ; ) {
        const loaded = await evaluate(
          cdp,
          () => !window.__breakhound_old && document.readyState === "complete",
          void 0,
          5e3
        ).catch(() => false);
        if (loaded) break;
        if (Date.now() > deadline) throw new Error("The page took over a minute to load.");
        await pause2(100);
      }
    }
    await pause2(500);
    await evaluate(
      cdp,
      () => Promise.race([document.fonts.ready, new Promise((r) => setTimeout(r, 3e3))]).then(
        () => void 0
      )
    );
  }
  async function reloadTracked(cdp, analyzerScript) {
    const ids = await addTracking(cdp, analyzerScript);
    await loadPage(cdp, null);
    return ids;
  }
  async function freeze(cdp) {
    await evaluate(
      cdp,
      ({ css, attr }) => {
        if (document.querySelector(`style[${attr}]`)) return;
        const style = document.createElement("style");
        style.setAttribute(attr, "");
        style.textContent = css;
        document.head.appendChild(style);
      },
      { css: FREEZE_CSS, attr: FREEZE_ATTR }
    );
    await cdp.send("Emulation.setEmulatedMedia", {
      features: [{ name: "prefers-reduced-motion", value: "reduce" }]
    });
  }
  async function restore(cdp, scroll) {
    await cdp.send("Emulation.clearDeviceMetricsOverride").catch(() => {
    });
    await cdp.send("Emulation.setEmulatedMedia", { features: [] }).catch(() => {
    });
    await evaluate(
      cdp,
      ({ attr, x: x2, y }) => {
        for (const el of document.querySelectorAll(`style[${attr}]`)) el.remove();
        window.__breakhound?.clearHighlights();
        window.scrollTo(x2, y);
      },
      { attr: FREEZE_ATTR, ...scroll }
    ).catch(() => {
    });
  }
  async function scanTab(cdp, options) {
    const opts = { ...TAB_DEFAULTS, ...options };
    const started = Date.now();
    const scripts = opts.reload ? await reloadTracked(cdp, opts.analyzerScript) : [];
    await evaluate(cdp, opts.analyzerScript);
    const where = await evaluate(cdp, () => ({
      href: location.href,
      x: window.scrollX,
      y: window.scrollY,
      width: window.innerWidth,
      height: window.innerHeight,
      hasContent: window.__breakhound?.hasContent() ?? false
    }));
    const route = opts.route ?? routeOf(where.href);
    const base = {
      url: where.href,
      finalUrl: where.href,
      route,
      pageErrors: [],
      warnings: []
    };
    if (!where.hasContent) {
      return {
        ...base,
        status: "empty",
        error: "The page has nothing on it to measure.",
        breakpoints: { observed: [], declared: [], unexplained: [] },
        issues: [],
        measurements: 0,
        durationMs: Date.now() - started
      };
    }
    let measured = 0;
    const page = tabPage(cdp, {
      fit: { width: where.width, height: where.height },
      onResize: (width) => opts.onProgress?.({ width, measured: ++measured }),
      ...opts.cancelled ? { cancelled: opts.cancelled } : {}
    });
    try {
      await freeze(cdp);
      const sweeper = new Sweeper(page, {
        minWidth: opts.minWidth,
        maxWidth: opts.maxWidth,
        height: opts.height,
        maxSettleMs: opts.maxSettleMs,
        analyze: {},
        // Someone is watching the tab: grow it steadily instead of jumping around.
        order: "ascending",
        ...opts.onMeasure ? { onMeasure: opts.onMeasure } : {}
      });
      await sweeper.run(coarseWidths(opts.minWidth, opts.maxWidth, opts.step));
      const widths = [...sweeper.results.keys()].sort((a, b) => a - b);
      const issues = await confirmNarrowIssues(buildIssues(route, widths, sweeper.results), sweeper);
      const declared = await evaluate(
        cdp,
        () => window.__breakhound?.declaredBreakpoints() ?? []
      );
      return {
        ...base,
        status: "scanned",
        warnings: sweeper.unstable ? [
          "The layout kept changing on its own (an auto-playing carousel or live content?), so some width ranges are approximate."
        ] : [],
        breakpoints: buildBreakpoints([sweeper.results], declared, opts.minWidth, opts.maxWidth),
        issues,
        measurements: widths.length,
        durationMs: Date.now() - started
      };
    } finally {
      await restore(cdp, where);
      await removeTracking(cdp, scripts);
    }
  }

  // packages/extension/src/session.ts
  function attachError(error) {
    const message = error instanceof Error ? error.message : String(error);
    if (/already attached/i.test(message)) {
      return new Error(
        "Something else is already controlling this tab: breakhound open in another view (DevTools or the side panel), another extension, or a test runner. Close it and try again."
      );
    }
    if (/chrome:\/\/|chrome-extension:\/\/|webstore|Cannot access/i.test(message)) {
      return new Error(
        "Chrome doesn't let extensions measure this page. Open your site in the tab and try again."
      );
    }
    if (/file:\/\//i.test(message)) {
      return new Error(
        'To scan a file:// page, turn on "Allow access to file URLs" for breakhound in chrome://extensions.'
      );
    }
    return new Error(message);
  }
  var LEFTOVERS = "[data-breakhound-overlay], style[data-breakhound-freeze]";
  var CHECK_IN = `(() => {
  const w = window;
  w.__breakhoundSeen = Date.now();
  if (w.__breakhoundGuard) return;
  let missed = 0;
  w.__breakhoundGuard = setInterval(() => {
    if (Date.now() - w.__breakhoundSeen < 2500) { missed = 0; return; }
    // Twice in a row, so a page that was busy, which delays the check-in too, isn't mistaken for one left alone.
    if (++missed < 2) return;
    clearInterval(w.__breakhoundGuard);
    w.__breakhoundGuard = 0;
    for (const el of document.querySelectorAll(${JSON.stringify(LEFTOVERS)})) el.remove();
  }, 1000);
})()`;
  var TabSession = class {
    constructor(tabId2) {
      this.tabId = tabId2;
      chrome.debugger.onDetach.addListener((source, reason) => {
        if (source.tabId !== tabId2) return;
        this.attached = false;
        clearInterval(this.checkIns);
        this.onDetach?.(reason);
      });
    }
    tabId;
    attached = false;
    checkIns;
    /** Called when Chrome or the developer ends the session (the bar's Cancel, the tab closing). */
    onDetach = null;
    onHidden = null;
    get isAttached() {
      return this.attached;
    }
    async attach() {
      if (this.attached) return;
      try {
        await chrome.debugger.attach({ tabId: this.tabId }, "1.3");
      } catch (error) {
        throw attachError(error);
      }
      this.attached = true;
      const checkIn = () => this.send("Runtime.evaluate", { expression: CHECK_IN }).catch(() => {
      });
      void checkIn();
      this.checkIns = setInterval(checkIn, 1e3);
    }
    async detach() {
      if (!this.attached) return;
      this.attached = false;
      clearInterval(this.checkIns);
      await chrome.debugger.detach({ tabId: this.tabId }).catch(() => {
      });
    }
    send(method, params2) {
      return chrome.debugger.sendCommand({ tabId: this.tabId }, method, params2);
    }
  };

  // packages/routes/src/pattern.ts
  var PARAM_SOURCE = "[^/]+";
  function staticSegment(value) {
    return { kind: "static", value };
  }
  function param(name, optional = false) {
    return {
      kind: "param",
      label: optional ? `[[${name}]]` : `[${name}]`,
      source: PARAM_SOURCE,
      optional
    };
  }
  function rest(name, optional) {
    return { kind: "rest", label: optional ? `[[...${name}]]` : `[...${name}]`, optional };
  }
  function escapeRegExp(text) {
    return text.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }
  function mixed(parts) {
    if (parts.every((p) => typeof p === "string")) return staticSegment(parts.join(""));
    if (parts.length === 1 && typeof parts[0] === "object") return param(parts[0].name);
    return {
      kind: "param",
      label: parts.map((p) => typeof p === "string" ? p : `[${p.name}]`).join(""),
      source: parts.map((p) => typeof p === "string" ? escapeRegExp(p) : PARAM_SOURCE).join(""),
      optional: false
    };
  }
  function createPattern(segments) {
    const clean = segments.filter((s) => !(s.kind === "static" && s.value === ""));
    const path = `/${clean.map((s) => s.kind === "static" ? s.value : s.label).join("/")}`;
    return {
      path,
      segments: clean,
      dynamic: clean.some((s) => s.kind !== "static" && !s.optional)
    };
  }
  function staticUrlPath(pattern) {
    if (pattern.dynamic) return null;
    const parts = pattern.segments.flatMap((s) => s.kind === "static" ? [s.value] : []);
    return `/${parts.join("/")}`;
  }
  function segmentSource(s) {
    if (s.kind === "static") return `/${escapeRegExp(s.value)}`;
    if (s.kind === "param") return s.optional ? `(?:/${s.source})?` : `/${s.source}`;
    return s.optional ? "(?:/.+)?" : "/.+";
  }
  var matchers = /* @__PURE__ */ new WeakMap();
  function matchesPattern(pattern, pathname) {
    let re = matchers.get(pattern);
    if (!re) {
      re = new RegExp(`^${pattern.segments.map(segmentSource).join("") || "/"}/?$`, "i");
      matchers.set(pattern, re);
    }
    let path = pathname;
    try {
      path = decodeURI(pathname);
    } catch {
    }
    return re.test(path);
  }
  function segmentRank(s) {
    if (!s) return 4;
    if (s.kind === "static") return 5;
    if (s.kind === "param") return s.optional ? 2 : 3;
    return s.optional ? 0 : 1;
  }
  var MAX_RANKED_SEGMENTS = 12;
  function specificity(pattern) {
    let score = 0;
    for (let i = 0; i < MAX_RANKED_SEGMENTS; i++)
      score = score * 6 + segmentRank(pattern.segments[i]);
    return score;
  }

  // packages/routes/src/syntax.ts
  function isRootCatchAll(pattern) {
    return pattern.segments.length > 0 && pattern.segments.every((s) => s.kind === "rest");
  }
  function finish(segments) {
    const pattern = createPattern(segments);
    return isRootCatchAll(pattern) ? null : pattern;
  }
  function fromReactRouterPath(path) {
    const segments = path.split("/").filter(Boolean).map((seg) => {
      if (seg === "*") return rest("rest", true);
      const m = seg.match(/^:([\w-]+)(\?)?$/);
      if (m?.[1]) return param(m[1], Boolean(m[2]));
      if (seg.endsWith("?")) return param(seg.slice(0, -1), true);
      return staticSegment(seg);
    });
    return finish(segments);
  }
  function fromVueRouterPath(path) {
    const segments = [];
    for (const seg of path.split("/").filter(Boolean)) {
      const tokens = [...seg.matchAll(/:([\w]+)(\((?:[^()]|\([^()]*\))*\))?([?*+])?/g)];
      if (!tokens.length) {
        segments.push(staticSegment(seg));
        continue;
      }
      if (tokens.length === 1 && tokens[0]?.[0] === seg) {
        const [, name = "param", regex = "", modifier] = tokens[0];
        const repeat = modifier === "*" || modifier === "+" || /\.\*|\.\+/.test(regex);
        const optional = modifier === "?" || modifier === "*" || /\.\*/.test(regex) && modifier !== "+";
        segments.push(repeat ? rest(name, optional) : param(name, optional));
        continue;
      }
      const parts = [];
      let last = 0;
      for (const t of tokens) {
        if (t.index > last) parts.push(seg.slice(last, t.index));
        parts.push({ name: t[1] });
        last = t.index + t[0].length;
      }
      if (last < seg.length) parts.push(seg.slice(last));
      segments.push(mixed(parts));
    }
    return finish(segments);
  }
  function fromTanstackPath(path) {
    const segments = path.split("/").filter(Boolean).map((seg) => {
      if (seg === "$") return rest("splat", true);
      let m = seg.match(/^\{-\$([\w]+)\}$/);
      if (m?.[1]) return param(m[1], true);
      m = seg.match(/^\$([\w]+)$/);
      if (m?.[1]) return param(m[1]);
      const parts = [];
      let last = 0;
      for (const t of seg.matchAll(/\{\$([\w]+)\}/g)) {
        if (t.index > last) parts.push(seg.slice(last, t.index));
        parts.push({ name: t[1] });
        last = t.index + t[0].length;
      }
      if (last < seg.length) parts.push(seg.slice(last));
      return mixed(parts);
    });
    return finish(segments);
  }

  // packages/routes/src/crawl.ts
  var RUNTIME_NAMES = {
    vue: "the Vue router",
    "react-router": "the React Router tree",
    remix: "the route manifest",
    tanstack: "the TanStack router"
  };
  function runtimeRoutes(found) {
    if (!found.router || !found.paths.length) return null;
    const convert = found.router === "vue" ? fromVueRouterPath : found.router === "tanstack" ? fromTanstackPath : fromReactRouterPath;
    const routes = /* @__PURE__ */ new Map();
    for (const p of found.paths) {
      const pattern = convert(p);
      if (pattern && !routes.has(pattern.path)) routes.set(pattern.path, pattern);
    }
    return routes.size ? { from: RUNTIME_NAMES[found.router], routes: [...routes.values()] } : null;
  }
  function routeFor(pathname, patterns) {
    let best = null;
    for (const p of patterns) {
      if (matchesPattern(p, pathname) && (!best || specificity(p) > specificity(best))) best = p;
    }
    return best;
  }
  var NOT_A_PAGE = /\.(pdf|zip|png|jpe?g|gif|webp|avif|svg|ico|mp4|webm|mp3|xml|txt|json|css|js|mjs|map|csv|xlsx?|docx?)$/i;
  var UNSAFE = /(^|\/)(log-?out|sign-?out|logoff|delete|remove|destroy|unsubscribe)(\/|$)|^\/api\//i;
  function isCrawlable(pathname) {
    return !NOT_A_PAGE.test(pathname) && !UNSAFE.test(pathname);
  }
  var Crawler = class {
    constructor(limit, wanted = () => true, perParentLimit = 3) {
      this.limit = limit;
      this.wanted = wanted;
      this.perParentLimit = perParentLimit;
    }
    limit;
    wanted;
    perParentLimit;
    taken = /* @__PURE__ */ new Set();
    perParent = /* @__PURE__ */ new Map();
    get count() {
      return this.taken.size;
    }
    /** Marks a path as already planned. */
    claim(pathname) {
      this.taken.add(normalize(pathname));
    }
    /** The links worth visiting, in order. */
    add(links) {
      const out = [];
      for (const raw of links) {
        const path = normalize(raw);
        if (this.taken.has(path) || !isCrawlable(path) || !this.wanted(path)) continue;
        if (this.taken.size >= this.limit) continue;
        const parent = path.replace(/\/[^/]*$/, "") || "/";
        const n = this.perParent.get(parent) ?? 0;
        if (parent !== "/" && n >= this.perParentLimit) continue;
        this.perParent.set(parent, n + 1);
        this.taken.add(path);
        out.push(path);
      }
      return out;
    }
  };
  function normalize(pathname) {
    return pathname.length > 1 ? pathname.replace(/\/+$/, "") : pathname;
  }

  // packages/routes/src/queue.ts
  function namesIn(label2) {
    return [...label2.matchAll(/\[\[?(?:\.\.\.)?([^\]]+)\]\]?/g)].map((m) => m[1]);
  }
  function isPlainParam(s) {
    return s.kind === "param" && !s.optional && namesIn(s.label).length === 1 && s.label.startsWith("[") && s.label.endsWith("]");
  }
  function prefixOf(segments, i) {
    return `/${segments.slice(0, i + 1).map((s) => s.kind === "static" ? s.value : s.label).join("/")}`;
  }
  function trimSlash(path) {
    return path.length > 1 ? path.replace(/\/+$/, "") : path;
  }
  var RouteQueue = class {
    constructor(baseUrl, samples, crawler, hashRouting = false, params2 = {}) {
      this.baseUrl = baseUrl;
      this.samples = samples;
      this.crawler = crawler;
      this.hashRouting = hashRouting;
      this.params = params2;
      this.basePath = baseUrl ? new URL(baseUrl).pathname.replace(/\/+$/, "") : "";
    }
    baseUrl;
    samples;
    crawler;
    hashRouting;
    params;
    jobs = [];
    /** App paths already scanned or planned, so redirects to them aren't scanned twice. */
    planned = /* @__PURE__ */ new Set();
    /** Dynamic routes still waiting for a link that fits them. */
    waiting = /* @__PURE__ */ new Map();
    /** For routes left waiting at the end: the parameters nothing gave a value. */
    missing = /* @__PURE__ */ new Map();
    /**
     * Values parameters took in real URLs, under the route they belong to: `/users/[username]` →
     * `jane`. Routes below it reuse them, since a child of a real page is real too.
     */
    seen = /* @__PURE__ */ new Map();
    patterns = /* @__PURE__ */ new Map();
    order = 0;
    /** Where the app is mounted on its server, e.g. "/docs"; "" at the root. */
    basePath;
    /** The full URL for an app path (or a full URL, as given). */
    urlFor(path) {
      if (/^https?:\/\//i.test(path)) return path;
      const base = (this.baseUrl ?? "").replace(/\/+$/, "");
      const clean = path.startsWith("/") ? path : `/${path}`;
      return this.hashRouting && !clean.includes("#") ? `${base}/#${clean}` : `${base}${clean}`;
    }
    /** The app path for a path on the server, or null when it's outside the app. */
    appPath(pathname) {
      const path = trimSlash(pathname);
      if (!this.basePath) return path;
      if (path === this.basePath) return "/";
      return path.startsWith(`${this.basePath}/`) ? path.slice(this.basePath.length) : null;
    }
    /** The key a full URL is planned under: its app path, with the hash route when there is one. */
    keyOf(url) {
      const u = new URL(url);
      const path = this.appPath(u.pathname) ?? trimSlash(u.pathname);
      if (!u.hash.startsWith("#/")) return path;
      const hash = trimSlash(u.hash.slice(1).split("?")[0]);
      if (this.hashRouting) return hash;
      return `${path === "/" ? "" : path}/#${hash}`;
    }
    /** The app path a link from a page points at, or null when it's outside the app. */
    linkPath(link) {
      const [pathname = "/", hash] = link.split("#");
      if (this.hashRouting) return hash?.startsWith("/") ? trimSlash(hash) : null;
      return hash === void 0 ? this.appPath(pathname) : null;
    }
    add(target, linksOnly = false) {
      const key = target.url.startsWith("http") ? this.keyOf(target.url) : target.url;
      if (this.planned.has(key)) return;
      this.planned.add(key);
      this.crawler?.claim(key);
      this.jobs.push({ ...target, order: this.order++, ...linksOnly ? { linksOnly } : {} });
    }
    /** The home page when following links but include or exclude leaves it out. */
    addStart(path) {
      this.add({ url: this.urlFor(path), route: path }, true);
    }
    addPattern(pattern) {
      if (this.patterns.has(pattern.path) || !this.baseUrl) return;
      this.patterns.set(pattern.path, pattern);
      const path = staticUrlPath(pattern);
      if (path !== null) {
        this.add({ url: this.urlFor(path), route: pattern.path });
        return;
      }
      const sample = this.samples[pattern.path];
      if (sample) {
        const samplePath = /^https?:\/\//i.test(sample) ? this.appPath(new URL(sample).pathname) : sample;
        if (samplePath !== null) this.learn(pattern, samplePath);
        this.add({ url: this.urlFor(sample), route: pattern.path });
      } else this.waiting.set(pattern.path, pattern);
    }
    /** Remembers the values a real URL gives a route's parameters. */
    learn(pattern, path) {
      if (pattern.segments.some((s) => s.kind === "rest" || s.kind === "param" && s.optional))
        return;
      const parts = path.split(/[?#]/)[0].split("/").filter(Boolean);
      if (parts.length !== pattern.segments.length) return;
      pattern.segments.forEach((s, i) => {
        if (isPlainParam(s)) {
          const key = prefixOf(pattern.segments, i);
          if (!this.seen.has(key)) this.seen.set(key, parts[i]);
        }
      });
    }
    /**
     * A URL for a dynamic route from values already known: a parent route's real URL, then the
     * config's params by name. Null, with the names still needed, when something is missing.
     */
    build(pattern) {
      const parts = [];
      const missing = [];
      pattern.segments.forEach((s, i) => {
        if (s.kind === "static") {
          parts.push(s.value);
          return;
        }
        const inherited = isPlainParam(s) ? this.seen.get(prefixOf(pattern.segments, i)) : void 0;
        if (inherited !== void 0) {
          parts.push(inherited);
          return;
        }
        const names = namesIn(s.label);
        const absent = names.filter((n) => this.params[n] === void 0);
        if (absent.length) {
          if (!s.optional) missing.push(...absent);
          return;
        }
        let value = s.label;
        for (const n of names)
          value = value.replace(/\[\[?(?:\.\.\.)?[^\]]+\]\]?/, () => this.params[n]);
        parts.push(value.replace(/^\/+|\/+$/g, ""));
      });
      return missing.length ? { missing: [...new Set(missing)] } : { path: `/${parts.join("/")}` };
    }
    /**
     * Gives the routes no link fitted a URL from known values, once the links have had their
     * chance. Returns how many were added; the rest stay waiting, with what they're missing.
     */
    fillWaiting() {
      let added = 0;
      for (const [key, pattern] of this.waiting) {
        const built = this.build(pattern);
        if ("missing" in built) {
          this.missing.set(key, built.missing);
          continue;
        }
        this.waiting.delete(key);
        this.missing.delete(key);
        this.add({ url: this.urlFor(built.path), route: pattern.path });
        added++;
      }
      return added;
    }
    /** Links from a scanned page: samples for dynamic routes, and new pages when crawling. */
    addLinks(found) {
      if (!this.baseUrl) return;
      const links = found.map((link) => this.linkPath(link)).filter((p) => p !== null && isCrawlable(p));
      if (this.patterns.size) {
        for (const link of links) {
          const route = routeFor(link, this.patterns.values());
          if (!route?.dynamic) continue;
          this.learn(route, link);
          if (this.waiting.has(route.path)) {
            this.waiting.delete(route.path);
            this.add({ url: this.urlFor(link), route: route.path });
          }
        }
      }
      if (this.crawler) {
        for (const path of this.crawler.add(links)) this.add({ url: this.urlFor(path), route: path });
      }
    }
    /** A redirect to a page that's scanned anyway isn't worth scanning twice. */
    redirectTarget(requested, final) {
      if (new URL(final).origin !== new URL(requested).origin) return null;
      const to = this.keyOf(final);
      if (to === this.keyOf(requested)) return null;
      if (this.planned.has(to)) return to;
      this.planned.add(to);
      return null;
    }
  };

  // packages/routes/src/runtime.ts
  function readRuntimeRoutes() {
    const w = window;
    const paths = /* @__PURE__ */ new Set();
    const join = (base, path) => path.startsWith("/") ? path : `${base.replace(/\/?\*$/, "").replace(/\/+$/, "")}/${path}`;
    const manifest = w.__reactRouterManifest?.routes ?? w.__remixManifest?.routes;
    if (manifest && typeof manifest === "object") {
      const fullPath = (id, depth = 0) => {
        const r = manifest[id];
        if (!r || depth > 50) return "";
        const parent = r.parentId ? fullPath(r.parentId, depth + 1) : "";
        return r.path ? join(parent, r.path) : parent;
      };
      for (const id of Object.keys(manifest)) {
        const r = manifest[id];
        if (id === "root" || !r.path && !r.index) continue;
        paths.add(fullPath(id) || "/");
      }
      if (paths.size) return { router: "remix", paths: [...paths] };
    }
    const all = document.querySelectorAll("*");
    for (const el of all) {
      const app = el.__vue_app__;
      const router = app?.config?.globalProperties?.$router;
      if (router?.getRoutes) {
        for (const r of router.getRoutes())
          if (!r.redirect && typeof r.path === "string") paths.add(r.path);
        return { router: "vue", paths: [...paths] };
      }
      const vm = el.__vue__?.$root;
      if (vm?.$router) {
        const records = vm.$router.getRoutes?.() ?? [];
        for (const r of records) if (!r.redirect && typeof r.path === "string") paths.add(r.path);
        if (paths.size) return { router: "vue", paths: [...paths] };
      }
    }
    const roots = [];
    for (const el of all) {
      for (const key of Object.keys(el)) {
        if (key.startsWith("__reactContainer$")) {
          const fiber = el[key];
          roots.push(fiber?.stateNode?.current ?? fiber);
        }
      }
      const legacy = el._reactRootContainer;
      if (legacy) roots.push(legacy._internalRoot?.current ?? legacy.current);
    }
    if (!roots.length) return { router: null, paths: [] };
    let kind = null;
    const indexPath = (base) => base.replace(/\/?\*$/, "") || "/";
    const isRouteElement = (e) => e && typeof e === "object" && e.props && (typeof e.props.path === "string" || e.props.index === true) && ("element" in e.props || "Component" in e.props || "component" in e.props || "children" in e.props || "lazy" in e.props);
    const toList = (c) => Array.isArray(c) ? c.flat(Infinity) : c ? [c] : [];
    const walkElements = (children, base) => {
      for (const e of toList(children)) {
        if (!isRouteElement(e)) {
          if (e?.props?.children && !e.props.path) walkElements(e.props.children, base);
          continue;
        }
        const full = typeof e.props.path === "string" ? join(base, e.props.path) : base;
        if (typeof e.props.path === "string") paths.add(full);
        else if (e.props.index) paths.add(indexPath(base));
        walkElements(e.props.children, full);
      }
    };
    const walkObjects = (routes, base, depth = 0) => {
      if (!Array.isArray(routes) || depth > 30) return;
      for (const r of routes) {
        if (!r || typeof r !== "object") continue;
        const full = typeof r.path === "string" ? join(base, r.path) : base;
        if (typeof r.path === "string") paths.add(full);
        else if (r.index) paths.add(indexPath(base));
        walkObjects(r.children, full, depth + 1);
      }
    };
    const baseOf = (fiber) => {
      for (let f = fiber.return; f; f = f.return) {
        const matches = f.memoizedProps?.value?.matches ?? f.memoizedProps?.routeContext?.matches;
        if (Array.isArray(matches) && matches.length) {
          let base = "";
          for (const m of matches)
            if (typeof m.route?.path === "string") base = join(base, m.route.path);
          return base;
        }
      }
      return "";
    };
    let visited = 0;
    for (const root of roots) {
      const stack = [root];
      while (stack.length && visited < 2e5) {
        const fiber = stack.pop();
        visited++;
        const props = fiber.memoizedProps;
        if (props && typeof props === "object") {
          const router = props.router;
          if (router?.routesByPath && typeof router.routesByPath === "object") {
            kind = "tanstack";
            for (const p of Object.keys(router.routesByPath)) paths.add(p);
          } else if (Array.isArray(router?.routes)) {
            kind = "react-router";
            walkObjects(router.routes, "");
          } else if (toList(props.children).some(isRouteElement)) {
            kind = "react-router";
            walkElements(props.children, baseOf(fiber));
          }
          const matches = props.routeContext?.matches ?? props.value?.matches;
          if (Array.isArray(matches)) {
            let base = "";
            for (const m of matches) {
              if (typeof m?.route?.path === "string") base = join(base, m.route.path);
              if (Array.isArray(m?.route?.children)) {
                kind ??= "react-router";
                walkObjects(m.route.children, base);
              }
            }
          }
        }
        if (fiber.sibling) stack.push(fiber.sibling);
        if (fiber.child) stack.push(fiber.child);
      }
    }
    return { router: kind, paths: [...paths] };
  }
  function readLinks() {
    const out = /* @__PURE__ */ new Set();
    for (const a of document.querySelectorAll("a[href]")) {
      const href = a.href;
      if (!href) continue;
      let url;
      try {
        url = new URL(href, location.href);
      } catch {
        continue;
      }
      if (url.origin !== location.origin) continue;
      if (a.hasAttribute("download")) continue;
      out.add(url.pathname);
      if (url.hash.startsWith("#/")) out.add(`${url.pathname}${url.hash.split("?")[0]}`);
    }
    return [...out];
  }

  // packages/extension/src/site.ts
  var SITE_MAX_PAGES = 25;
  function failedPage(job, error) {
    if (error instanceof Cancelled) throw error;
    const message = error instanceof Error ? error.message : String(error);
    if (/detached|target closed|No tab with given id/i.test(message)) throw error;
    return {
      url: job.url,
      finalUrl: job.url,
      route: job.route,
      status: "error",
      error: message,
      pageErrors: [],
      warnings: [],
      breakpoints: { observed: [], declared: [], unexplained: [] },
      issues: [],
      measurements: 0,
      durationMs: 0
    };
  }
  async function scanPages(cdp, pages, options) {
    const start = await evaluate(cdp, () => location.href);
    const routes = [];
    const scripts = await addTracking(cdp, options.analyzerScript);
    try {
      for (const [index, job] of pages.entries()) {
        if (options.cancelled?.()) throw new Cancelled();
        options.onPage?.({ index, planned: pages.length, url: job.url, route: job.route });
        let result;
        try {
          await loadPage(cdp, job.url);
          result = await scanTab(cdp, {
            ...options,
            route: job.route,
            onProgress: options.onProgress,
            onMeasure: options.onMeasure
          });
        } catch (error) {
          result = failedPage(job, error);
        }
        routes.push(result);
        options.onResult?.(result);
      }
    } finally {
      await removeTracking(cdp, scripts);
      await loadPage(cdp, start).catch(() => {
      });
    }
    return routes;
  }
  async function scanSite(cdp, options) {
    const max = options.maxPages ?? SITE_MAX_PAGES;
    const start = await evaluate(cdp, () => location.href);
    const origin = new URL(start).origin;
    const hashRouting = new URL(start).hash.startsWith("#/");
    const found = runtimeRoutes(
      await evaluate(cdp, readRuntimeRoutes).catch(() => ({
        router: null,
        paths: []
      }))
    );
    const queue = new RouteQueue(origin, {}, found ? null : new Crawler(max), hashRouting);
    const routeOfPath = (path) => found ? routeFor(path, found.routes)?.path ?? path : path;
    const startRoute = routeOfPath(routeOf(start));
    queue.add({ url: start, route: startRoute });
    queue.add({ url: `${origin}${hashRouting ? "/#/" : "/"}`, route: routeOfPath("/") });
    for (const pattern of found?.routes ?? []) queue.addPattern(pattern);
    if (found) {
      const at = new URL(start);
      queue.addLinks([hashRouting ? `${at.pathname}${at.hash.split("?")[0]}` : at.pathname]);
    }
    const routes = [];
    const scripts = await addTracking(cdp, options.analyzerScript);
    try {
      for (let i = 0; routes.length < max; i++) {
        if (i >= queue.jobs.length && !queue.fillWaiting()) break;
        if (options.cancelled?.()) throw new Cancelled();
        const job = queue.jobs[i];
        if (!job) continue;
        options.onPage?.({
          index: routes.length,
          planned: Math.min(max, queue.jobs.length - i + routes.length),
          url: job.url,
          route: job.route
        });
        try {
          await loadPage(cdp, job.url);
          const final = await evaluate(cdp, () => location.href);
          if (new URL(final).origin !== origin || queue.redirectTarget(job.url, final)) continue;
          const result = await scanTab(cdp, {
            ...options,
            route: job.route,
            onProgress: options.onProgress,
            onMeasure: options.onMeasure
          });
          routes.push(result);
          options.onResult?.(result);
          queue.addLinks(await evaluate(cdp, readLinks).catch(() => []));
        } catch (error) {
          const failed = failedPage(job, error);
          routes.push(failed);
          options.onResult?.(failed);
        }
      }
    } finally {
      await removeTracking(cdp, scripts);
      await loadPage(cdp, start).catch(() => {
      });
    }
    return { routes, from: found?.from ?? "links on your pages" };
  }

  // packages/extension/src/panel.ts
  var inDevtools = typeof chrome.devtools?.inspectedWindow?.tabId === "number";
  var params = new URLSearchParams(location.search);
  var tabId = inDevtools ? chrome.devtools.inspectedWindow.tabId : Number(params.get("tab"));
  var scanOnOpen = !inDevtools && params.has("scan");
  var session = new TabSession(tabId);
  var dark = inDevtools ? chrome.devtools.panels.themeName === "dark" : matchMedia("(prefers-color-scheme: dark)").matches;
  if (dark) document.documentElement.dataset.theme = "dark";
  var $ = (id) => document.getElementById(id);
  var ui = {
    scan: $("scan"),
    stop: $("stop"),
    min: $("min"),
    max: $("max"),
    presets: $("presets"),
    reload: $("reload"),
    reloadSwitch: $("reload-switch"),
    modePage: $("mode-page"),
    modeSite: $("mode-site"),
    pages: $("pages"),
    rulerPage: $("ruler-page"),
    status: $("status"),
    copyAll: $("copy-all"),
    send: $("send"),
    agent: $("agent"),
    agentMenu: $("agent-menu"),
    noticeAction: $("notice-action"),
    notice: $("notice"),
    noticeText: $("notice-text"),
    noticeClose: $("notice-close"),
    intro: $("intro"),
    introScan: $("intro-scan"),
    results: $("results"),
    stats: $("stats"),
    viewing: $("viewing"),
    viewingText: $("viewing-text"),
    viewingReset: $("viewing-reset"),
    timeline: $("timeline"),
    devices: $("devices"),
    zones: $("zones"),
    axis: $("axis"),
    lanes: $("lanes"),
    hover: $("hover"),
    playhead: $("playhead"),
    filters: $("filters"),
    split: $("split"),
    issues: $("issues"),
    detail: $("detail")
  };
  var state = {
    phase: "idle",
    mode: "page",
    stopping: false,
    pages: [],
    current: 0,
    scanning: null,
    from: null,
    result: null,
    range: { min: TAB_DEFAULTS.minWidth, max: TAB_DEFAULTS.maxWidth },
    startedAt: /* @__PURE__ */ new Date(),
    live: /* @__PURE__ */ new Map(),
    scanAt: null,
    paused: false,
    checking: false,
    measured: 0,
    selected: null,
    filter: "all",
    viewing: null,
    natural: null,
    wide: false
  };
  var SEVERITIES = ["error", "warning", "info"];
  var SEVERITY_NAMES = {
    error: "Error",
    warning: "Warning",
    info: "Info"
  };
  function h(tag, props = {}, ...children) {
    const el = document.createElement(tag);
    for (const [key, value] of Object.entries(props)) {
      if (value === void 0) continue;
      if (key === "class") el.className = value;
      else el.setAttribute(key, value);
    }
    for (const c of children) if (c) el.append(c);
    return el;
  }
  var ICONS = {
    stop: '<rect x="4" y="4" width="8" height="8" rx="1.6" fill="currentColor"/>',
    copy: '<rect x="5.5" y="5.5" width="8" height="8" rx="1.6" fill="none" stroke="currentColor" stroke-width="1.4"/><path d="M10.5 3.6V3a1.5 1.5 0 0 0-1.5-1.5H4A1.5 1.5 0 0 0 2.5 3v5A1.5 1.5 0 0 0 4 9.5h.6" fill="none" stroke="currentColor" stroke-width="1.4"/>',
    check: '<path d="M3 8.6l3.2 3.1L13 4.6" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/>',
    target: '<circle cx="8" cy="8" r="5.3" fill="none" stroke="currentColor" stroke-width="1.4"/><circle cx="8" cy="8" r="1.8" fill="currentColor"/>',
    inspect: '<path d="M3 2.6l9.4 3.9-4 1.5-1.6 4z" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"/><path d="M9 9l3.6 3.6" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/>',
    reset: '<path d="M3.2 8a4.8 4.8 0 1 0 1.5-3.5M3 2.6v2.6h2.6" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/>',
    close: '<path d="M4.5 4.5l7 7M11.5 4.5l-7 7" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>',
    send: '<path d="M2.4 7.4l11.1-5-4.9 11.2-1.7-4.6z" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"/><path d="M6.9 9l6.6-6.6" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/>',
    sweep: '<path d="M2.5 3.5v9M13.5 3.5v9" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/><path d="M5.5 8h5M8.8 6l1.9 2-1.9 2" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>'
  };
  function icon(name) {
    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.setAttribute("viewBox", "0 0 16 16");
    svg.setAttribute("class", "icon");
    svg.setAttribute("aria-hidden", "true");
    svg.innerHTML = ICONS[name];
    return svg;
  }
  function label(el, name, text) {
    el.replaceChildren(icon(name), text);
  }
  function button(name, text, onClick) {
    const b = h("button", { class: "btn", type: "button" });
    label(b, name, text);
    b.addEventListener("click", (e) => {
      e.stopPropagation();
      onClick(b);
    });
    return b;
  }
  var noticeAction = null;
  function notify(message, kind = "error", action) {
    ui.notice.hidden = !message;
    ui.notice.classList.toggle("error", kind === "error");
    ui.noticeText.textContent = message ?? "";
    noticeAction = action?.run ?? null;
    ui.noticeAction.hidden = !action;
    if (action) label(ui.noticeAction, "copy", action.label);
  }
  var SETTINGS_KEY = "breakhound.settings";
  function loadSettings() {
    let saved = {};
    try {
      saved = JSON.parse(localStorage.getItem(SETTINGS_KEY) ?? "{}");
    } catch {
    }
    ui.min.value = String(saved.min ?? TAB_DEFAULTS.minWidth);
    ui.max.value = String(saved.max ?? TAB_DEFAULTS.maxWidth);
    ui.reload.checked = saved.reload ?? false;
    state.mode = saved.mode === "site" ? "site" : "page";
  }
  function saveSettings() {
    try {
      localStorage.setItem(
        SETTINGS_KEY,
        JSON.stringify({
          min: ui.min.valueAsNumber,
          max: ui.max.valueAsNumber,
          reload: ui.reload.checked,
          mode: state.mode
        })
      );
    } catch {
    }
  }
  var DEVICE_WIDTHS = [
    {
      name: "Mobile",
      min: TAB_DEFAULTS.minWidth,
      max: 599,
      about: "Phones held upright"
    },
    {
      name: "Tablet",
      min: 600,
      max: 1023,
      about: "Tablets, and phones turned sideways"
    },
    {
      name: "Desktop",
      min: 1024,
      max: TAB_DEFAULTS.maxWidth,
      about: "Laptops and desktops, and tablets turned sideways"
    }
  ];
  var LAST_DEVICE = DEVICE_WIDTHS.length - 1;
  var allWidths = h(
    "button",
    {
      type: "button",
      title: `Every width, ${TAB_DEFAULTS.minWidth} to ${TAB_DEFAULTS.maxWidth}px`
    },
    "All"
  );
  var deviceButtons = DEVICE_WIDTHS.map((d, i) => {
    const next = DEVICE_WIDTHS[i + 1] ?? DEVICE_WIDTHS[i - 1];
    return h(
      "button",
      {
        type: "button",
        title: `${d.about}, ${d.min} to ${d.max}px. Pick ${next?.name} as well to check both.`
      },
      d.name
    );
  });
  ui.presets.replaceChildren(allWidths, ...deviceButtons);
  function pickedDevices() {
    const from = DEVICE_WIDTHS.findIndex((d) => d.min === Math.round(ui.min.valueAsNumber));
    const to = DEVICE_WIDTHS.findIndex((d) => d.max === Math.round(ui.max.valueAsNumber));
    return from >= 0 && to >= from ? [from, to] : null;
  }
  function setWidths(from, to) {
    ui.min.value = String(DEVICE_WIDTHS[from]?.min);
    ui.max.value = String(DEVICE_WIDTHS[to]?.max);
    saveSettings();
    renderPresets();
  }
  function pickDevice(k) {
    const run = pickedDevices();
    let [from, to] = [k, k];
    if (run && !(run[0] === 0 && run[1] === LAST_DEVICE)) {
      const [a, b] = run;
      if (k < a || k > b) [from, to] = [Math.min(a, k), Math.max(b, k)];
      else if (a === b) [from, to] = [0, LAST_DEVICE];
      else if (k === a) [from, to] = [a + 1, b];
      else if (k === b) [from, to] = [a, b - 1];
    }
    setWidths(from, to);
  }
  function renderPresets() {
    const run = pickedDevices();
    const all = run?.[0] === 0 && run[1] === LAST_DEVICE;
    allWidths.setAttribute("aria-pressed", String(all));
    deviceButtons.forEach((b, i) => {
      b.setAttribute("aria-pressed", String(!all && !!run && i >= run[0] && i <= run[1]));
    });
  }
  allWidths.addEventListener("click", () => setWidths(0, LAST_DEVICE));
  deviceButtons.forEach((b, i) => {
    b.addEventListener("click", () => pickDevice(i));
  });
  for (const input of [ui.min, ui.max]) input.addEventListener("input", renderPresets);
  function readRange() {
    const min = Math.round(ui.min.valueAsNumber);
    const max = Math.round(ui.max.valueAsNumber);
    if (!Number.isFinite(min) || !Number.isFinite(max) || min < 200 || max > 3840 || max - min < 16) {
      return null;
    }
    return { min, max };
  }
  async function copyText(text) {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch {
      const area = h("textarea", { style: "position:fixed;opacity:0" });
      area.value = text;
      document.body.append(area);
      area.select();
      const ok = document.execCommand("copy");
      area.remove();
      return ok;
    }
  }
  async function copyWith(b, text) {
    const before = [...b.childNodes];
    const ok = await copyText(text);
    if (b.classList.contains("icon-btn")) b.replaceChildren(icon(ok ? "check" : "close"));
    else label(b, ok ? "check" : "close", ok ? "Copied" : "Could not copy");
    b.classList.add("done");
    setTimeout(() => {
      b.replaceChildren(...before);
      b.classList.remove("done");
    }, 1400);
  }
  function scanResult() {
    const routes = state.pages.map((p) => p.route);
    const route = state.result ?? routes[0];
    return createScanResult(routes, {
      version: "1.0.5",
      startedAt: state.startedAt,
      minWidth: state.range.min,
      maxWidth: state.range.max,
      step: TAB_DEFAULTS.step,
      baseUrl: new URL(route.url).origin
    });
  }
  function prompt(fingerprints) {
    return renderPrompt(scanResult(), {
      ...fingerprints ? { fingerprints, severities: SEVERITIES } : {}
    });
  }
  var AGENTS_KEY = "breakhound.agents";
  var SETUP_COMMAND = "npx @seybel/breakhound mcp install";
  var agent = {
    /** The project's breakhound server the panel listens to, for checks of the agent's fixes. */
    server: null,
    online: false,
    sending: false,
    listening: null
  };
  function rememberedRoot(origin) {
    try {
      const roots = JSON.parse(localStorage.getItem(AGENTS_KEY) ?? "{}");
      return roots[origin] ?? null;
    } catch {
      return null;
    }
  }
  function remember(origin, root) {
    try {
      const roots = JSON.parse(localStorage.getItem(AGENTS_KEY) ?? "{}");
      roots[origin] = root;
      localStorage.setItem(AGENTS_KEY, JSON.stringify(roots));
    } catch {
    }
  }
  async function tabUrl() {
    try {
      const targets = await chrome.debugger.getTargets();
      return targets.find((t) => t.tabId === tabId)?.url ?? null;
    } catch {
      return null;
    }
  }
  function originOf(url) {
    if (!url || !/^https?:/.test(url)) return null;
    return new URL(url).origin;
  }
  function shortPath(path) {
    const parts = path.split(/[\\/]/).filter(Boolean);
    return parts.length > 2 ? `\u2026/${parts.slice(-2).join("/")}` : path;
  }
  function renderAgent() {
    const server = agent.server;
    ui.agent.hidden = !server;
    if (!server) return;
    ui.agent.replaceChildren(
      h("span", { class: "agent-dot", "aria-hidden": "true" }),
      server.project
    );
    ui.agent.classList.toggle("offline", !agent.online);
    ui.agent.title = agent.online ? `Your coding agent in ${server.root} is connected. It checks its fixes in this tab, so keep this panel open while it works. Click to change project.` : `Lost touch with the agent in ${server.root}. breakhound keeps looking for it.`;
  }
  function hideMenu() {
    ui.agentMenu.hidden = true;
  }
  function pickProject(servers, onPick) {
    ui.agentMenu.replaceChildren(
      h("p", { class: "menu-title" }, "Which project is this page from?"),
      ...servers.map((s) => {
        const b = h(
          "button",
          { type: "button", role: "menuitem", title: s.root },
          h("strong", {}, s.project),
          h("span", { class: "menu-path" }, shortPath(s.root))
        );
        b.addEventListener("click", () => {
          hideMenu();
          onPick(s);
        });
        return b;
      })
    );
    ui.agentMenu.hidden = false;
    ui.agentMenu.querySelector("button")?.focus();
  }
  function listen(server) {
    agent.listening?.abort();
    const stop = new AbortController();
    Object.assign(agent, { listening: stop, server, online: true });
    renderAgent();
    void (async () => {
      let current = server;
      while (!stop.signal.aborted) {
        const origin = originOf(await tabUrl());
        try {
          if (!origin) {
            await pause3(3e3);
            continue;
          }
          const check = await nextCheck(current, origin, stop.signal);
          if (!agent.online) {
            agent.online = true;
            renderAgent();
          }
          if (check) await runCheck(current, check);
        } catch {
          if (stop.signal.aborted) return;
          agent.online = false;
          renderAgent();
          await pause3(4e3);
          const again = (await findServers()).find((s) => s.root === server.root);
          if (again) {
            current = again;
            Object.assign(agent, { server: again, online: true });
            renderAgent();
          }
        }
      }
    })();
  }
  async function runCheck(server, check) {
    while (state.phase === "scanning") await pause3(500);
    notify(null);
    const outcome = await scan({ check, server });
    await checkDone(server, check.id, outcome).catch(() => {
    });
    if ("routes" in outcome) {
      const left = createScanResult(outcome.routes, {
        version: "1.0.5",
        startedAt: /* @__PURE__ */ new Date(),
        minWidth: check.widths.minWidth,
        maxWidth: check.widths.maxWidth,
        step: TAB_DEFAULTS.step
      }).summary.uniqueIssues;
      const pages = outcome.routes.length === 1 ? "the page" : `${outcome.routes.length} pages`;
      notify(
        `Checked your agent's fixes on ${pages}: ${left ? `${left} ${left === 1 ? "issue" : "issues"} still there` : "nothing left to fix"}. Your agent has the details.`,
        "note"
      );
    }
  }
  async function deliver(server, result) {
    const sent = await sendScan(server, result);
    remember(new URL(result.project.baseUrl ?? "").origin, server.root);
    listen(server);
    notify(
      `Sent ${sent.issues} ${sent.issues === 1 ? "issue" : "issues"} to your agent in ${server.project}. Ask it to "fix the breakhound issues" (in Claude Code, /mcp__breakhound__fix). Keep this panel open: your agent checks its fixes here, in this tab.`,
      "note",
      { label: "Copy request", run: (b) => void copyWith(b, "Fix the breakhound issues") }
    );
  }
  async function sendToAgent() {
    if (!state.pages.length) return;
    const result = scanResult();
    const origin = result.project.baseUrl ?? "";
    agent.sending = true;
    renderToolbar();
    try {
      const servers = byProject(await findServers());
      if (!servers.length) {
        notify(
          `No coding agent is connected to breakhound yet. In your project, run ${SETUP_COMMAND} once, then restart your agent (Claude Code, Cursor, Codex\u2026). Until then, Copy prompt works with any agent.`,
          "note",
          { label: "Copy command", run: (b) => void copyWith(b, SETUP_COMMAND) }
        );
        return;
      }
      const remembered = rememberedRoot(origin);
      let target = servers.find((s) => s.root === remembered) ?? null;
      if (!target) {
        const url = state.pages[0]?.route.url ?? origin;
        const own = await serving(servers, url);
        if (own.length === 1) target = own[0] ?? null;
      }
      if (target) {
        await deliver(target, result);
        return;
      }
      pickProject(servers, (server) => {
        void deliver(server, result).catch(
          (error) => notify(`Couldn't send to your agent: ${error instanceof Error ? error.message : error}`)
        );
      });
    } catch (error) {
      notify(`Couldn't send to your agent: ${error instanceof Error ? error.message : error}`);
    } finally {
      agent.sending = false;
      renderToolbar();
    }
  }
  async function reconnect() {
    const url = await tabUrl();
    const origin = originOf(url);
    if (!url || !origin) return;
    const servers = byProject(await findServers());
    if (!servers.length) return;
    const remembered = rememberedRoot(origin);
    const server = servers.find((s) => s.root === remembered) ?? await serving(servers, url).then((own) => own.length === 1 ? own[0] : void 0);
    if (server) listen(server);
  }
  function worstOf(result) {
    for (const s of SEVERITIES) if (result.findings.some((f) => f.severity === s)) return s;
    return null;
  }
  var frame = 0;
  function scheduleLive() {
    if (frame) return;
    frame = requestAnimationFrame(() => {
      frame = 0;
      drawZones();
      renderStats();
      renderPlayhead();
    });
  }
  function showPage(index) {
    const page = state.pages[index];
    if (!page) return;
    state.current = index;
    state.result = page.route;
    state.live = page.live;
    state.selected = null;
    if (state.filter === "here") state.filter = "all";
  }
  function firstWorthSeeing(pages) {
    let best = 0;
    let score = -1;
    pages.forEach((p, i) => {
      const issues = p.route.issues;
      const s = issues.filter((x2) => x2.severity === "error").length * 1e3 + issues.length;
      if (s > score) {
        score = s;
        best = i;
      }
    });
    return best;
  }
  async function scan(check) {
    const range = check ? { min: check.check.widths.minWidth, max: check.check.widths.maxWidth } : readRange();
    if (!range) {
      notify(
        "Pick widths between 200 and 3840px, with the widest at least 16px wider than the narrowest."
      );
      return { error: "No widths" };
    }
    if (!check) saveSettings();
    notify(null);
    await resetView();
    const previous = {
      pages: state.pages,
      current: state.current,
      result: state.result,
      range: state.range,
      live: state.live,
      startedAt: state.startedAt,
      from: state.from
    };
    const site = !check && state.mode === "site";
    const startedAt = /* @__PURE__ */ new Date();
    const pages = [];
    let failure = "Stopped in the browser.";
    Object.assign(state, {
      checking: !!check,
      phase: "scanning",
      startedAt,
      stopping: false,
      pages,
      current: 0,
      scanning: null,
      from: null,
      result: null,
      range,
      live: /* @__PURE__ */ new Map(),
      scanAt: range.min,
      measured: 0,
      selected: null,
      filter: "all"
    });
    render();
    const tick = setInterval(scheduleLive, 1e3);
    const common = {
      analyzerScript: '"use strict";\n(() => {\n  // ../analyzers/src/dom.ts\n  var UNCLIPPED = {\n    left: -Infinity,\n    right: Infinity,\n    top: -Infinity,\n    bottom: Infinity,\n    width: Infinity,\n    height: Infinity\n  };\n  function intersectBox(a, b) {\n    const left = Math.max(a.left, b.left);\n    const right = Math.min(a.right, b.right);\n    const top = Math.max(a.top, b.top);\n    const bottom = Math.min(a.bottom, b.bottom);\n    if (right <= left || bottom <= top) return null;\n    return { left, right, top, bottom, width: right - left, height: bottom - top };\n  }\n  function clipFor(rect, style, outer) {\n    const x = style.overflowX !== "visible";\n    const y = style.overflowY !== "visible";\n    if (!x && !y) return outer;\n    const own = {\n      left: x ? rect.left : -Infinity,\n      right: x ? rect.right : Infinity,\n      top: y ? rect.top : -Infinity,\n      bottom: y ? rect.bottom : Infinity,\n      width: x ? rect.width : Infinity,\n      height: y ? rect.height : Infinity\n    };\n    return intersectBox(own, outer) ?? { ...rect, right: rect.left, width: 0 };\n  }\n  var SKIP_TAGS = /* @__PURE__ */ new Set([\n    "SCRIPT",\n    "STYLE",\n    "TEMPLATE",\n    "NOSCRIPT",\n    "LINK",\n    "META",\n    "HEAD",\n    "TITLE",\n    "BR",\n    "WBR",\n    "SOURCE",\n    "TRACK",\n    "OPTION",\n    "OPTGROUP",\n    "DATALIST"\n  ]);\n  var DEV_OVERLAYS = [\n    "nextjs-portal",\n    "[data-nextjs-toast]",\n    "[data-nextjs-dev-tools-button]",\n    "#__next-build-watcher",\n    "#__next-prerender-indicator",\n    "#nuxt-devtools-container",\n    "#vue-inspector-container",\n    "#__vue-devtools-container__",\n    "vite-error-overlay",\n    "vite-plugin-checker-error-overlay",\n    "astro-dev-toolbar",\n    "astro-dev-overlay",\n    "#webpack-dev-server-client-overlay",\n    "#react-refresh-overlay",\n    ".tsqd-parent-container",\n    ".TanStackRouterDevtools",\n    "#svelte-inspector-host",\n    "vercel-live-feedback"\n  ].join(",");\n  var LEAF_TAGS = /* @__PURE__ */ new Set([\n    "svg",\n    "SVG",\n    "MATH",\n    "math",\n    "SELECT",\n    "TEXTAREA",\n    "IFRAME",\n    "VIDEO",\n    "CANVAS"\n  ]);\n  function renderedChildren(el) {\n    if (el.shadowRoot) return Array.from(el.shadowRoot.children);\n    if (el instanceof HTMLSlotElement) {\n      const assigned = el.assignedElements({ flatten: true });\n      if (assigned.length) return assigned;\n    }\n    return Array.from(el.children);\n  }\n  function composedParent(el) {\n    if (el.assignedSlot) return el.assignedSlot;\n    if (el.parentElement) return el.parentElement;\n    const root = el.parentNode;\n    return root instanceof ShadowRoot ? root.host : null;\n  }\n  function closestComposed(el, selector) {\n    for (let p = el; p; p = composedParent(p)) {\n      if (p.matches(selector)) return p;\n    }\n    return null;\n  }\n  function shadowRoots() {\n    const out = [];\n    const walk = (root) => {\n      for (const el of root.querySelectorAll("*")) {\n        if (el.shadowRoot) {\n          out.push(el.shadowRoot);\n          walk(el.shadowRoot);\n        }\n      }\n    };\n    walk(document);\n    return out;\n  }\n  function toBox(r) {\n    return {\n      left: r.left + window.scrollX,\n      right: r.right + window.scrollX,\n      top: r.top + window.scrollY,\n      bottom: r.bottom + window.scrollY,\n      width: r.width,\n      height: r.height\n    };\n  }\n  function clipsX(style) {\n    return style.overflowX !== "visible";\n  }\n  function isRendered(el, style) {\n    if (style.display === "none" || style.visibility === "hidden" || style.visibility === "collapse") {\n      return false;\n    }\n    if (typeof el.checkVisibility === "function") {\n      return el.checkVisibility({ opacityProperty: true, visibilityProperty: true });\n    }\n    return Number.parseFloat(style.opacity) > 0;\n  }\n  function isVisuallyHidden(rec) {\n    const { style, rect } = rec;\n    if (rect.width <= 1 || rect.height <= 1) {\n      if (style.overflow !== "visible" || style.position === "absolute") return true;\n    }\n    if (style.clip && style.clip !== "auto" && /rect\\(\\s*0/.test(style.clip)) return true;\n    if (style.clipPath && /inset\\(\\s*50%/.test(style.clipPath)) return true;\n    return false;\n  }\n  var ORNAMENT_OPACITY = 0.3;\n  function isOrnament(rec) {\n    if (rec.el.closest(\'[aria-hidden="true"]\')) return true;\n    let opacity = 1;\n    for (let p = rec; p; p = p.parent) {\n      opacity *= Number.parseFloat(p.style.opacity) || 0;\n      if (opacity < ORNAMENT_OPACITY) return true;\n    }\n    return false;\n  }\n  var BREAKS_ANYWHERE = /[\\u0e00-\\u0eff\\u1000-\\u109f\\u1780-\\u17ff\\u3040-\\u30ff\\u3400-\\u4dbf\\u4e00-\\u9fff\\uac00-\\ud7af\\uf900-\\ufaff]/g;\n  function breaksAnywhere(text) {\n    const chars = text.replace(/\\s/g, "").length;\n    return chars > 0 && (text.match(BREAKS_ANYWHERE)?.length ?? 0) * 2 >= chars;\n  }\n  var MAX_FRAGMENTS = 64;\n  function measureOwnText(el) {\n    let left = Infinity;\n    let right = -Infinity;\n    let top = Infinity;\n    let bottom = -Infinity;\n    const lineTops = [];\n    const pieces = [];\n    const range = document.createRange();\n    let text = "";\n    for (const node of el.childNodes) {\n      if (node.nodeType !== Node.TEXT_NODE || !node.textContent?.trim()) continue;\n      text += ` ${node.textContent}`;\n      range.selectNodeContents(node);\n      for (const r of range.getClientRects()) {\n        if (r.width === 0 || r.height === 0) continue;\n        left = Math.min(left, r.left);\n        right = Math.max(right, r.right);\n        top = Math.min(top, r.top);\n        bottom = Math.max(bottom, r.bottom);\n        pieces.push(r);\n        if (!lineTops.some((t) => Math.abs(t - r.top) < r.height / 2)) lineTops.push(r.top);\n      }\n    }\n    text = text.replace(/\\s+/g, " ").trim();\n    if (left === Infinity) return { rect: null, fragments: [], lines: 0, text };\n    const sx = window.scrollX;\n    const sy = window.scrollY;\n    const fragments = pieces.length <= MAX_FRAGMENTS ? pieces.map((r) => ({\n      left: r.left + sx,\n      right: r.right + sx,\n      top: r.top + sy,\n      bottom: r.bottom + sy,\n      width: r.width,\n      height: r.height\n    })) : [];\n    return {\n      fragments,\n      rect: {\n        left: left + sx,\n        right: right + sx,\n        top: top + sy,\n        bottom: bottom + sy,\n        width: right - left,\n        height: bottom - top\n      },\n      lines: lineTops.length,\n      text\n    };\n  }\n  function snapshot() {\n    const html = document.documentElement;\n    const body = document.body;\n    const htmlStyle = getComputedStyle(html);\n    const bodyStyle = body ? getComputedStyle(body) : htmlStyle;\n    const viewportWidth = html.clientWidth;\n    const scrollWidth = Math.max(html.scrollWidth, body?.scrollWidth ?? 0);\n    const rootClipsX = clipsX(htmlStyle) || clipsX(bodyStyle);\n    const records = [];\n    const byElement = /* @__PURE__ */ new Map();\n    const visit = (el, parent, depth) => {\n      if (SKIP_TAGS.has(el.tagName) || el.matches(DEV_OVERLAYS)) return;\n      const style = getComputedStyle(el);\n      if (!isRendered(el, style)) return;\n      if (style.display === "contents") {\n        for (const child of renderedChildren(el)) visit(child, parent, depth);\n        return;\n      }\n      const own = LEAF_TAGS.has(el.tagName) ? { rect: null, fragments: [], lines: 0, text: "" } : measureOwnText(el);\n      let outOfFlow = parent?.outOfFlow ?? null;\n      if (style.position === "fixed") outOfFlow = "fixed";\n      else if (style.position === "absolute" && outOfFlow !== "fixed") outOfFlow = "absolute";\n      const positioned = style.position === "fixed" || style.position === "absolute";\n      const rect = toBox(el.getBoundingClientRect());\n      const clip = style.position === "fixed" ? UNCLIPPED : parent?.innerClip ?? UNCLIPPED;\n      const innerClip = el === document.body || el === html ? clip : clipFor(rect, style, clip);\n      const rec = {\n        el,\n        parent,\n        style,\n        rect,\n        // Text hidden by the element\'s own overflow (ellipsis, line-clamp) is not painted.\n        textRect: own.rect && style.overflowX === "visible" && style.overflowY === "visible" ? own.rect : own.rect && intersectBox(own.rect, innerClip),\n        textFragments: own.fragments,\n        rawTextRect: own.rect,\n        text: own.text,\n        textLines: own.lines,\n        clipAncestor: parent && parent.el !== body && parent.el !== html && clipsX(parent.style) ? parent : parent?.clipAncestor ?? null,\n        outOfFlow,\n        oofRoot: null,\n        clip,\n        innerClip,\n        depth\n      };\n      rec.oofRoot = positioned ? rec : parent?.oofRoot ?? null;\n      records.push(rec);\n      byElement.set(el, rec);\n      if (LEAF_TAGS.has(el.tagName)) return;\n      for (const child of renderedChildren(el)) visit(child, rec, depth + 1);\n    };\n    if (body) {\n      for (const child of renderedChildren(body)) visit(child, null, 1);\n    }\n    return {\n      viewportWidth,\n      viewportHeight: html.clientHeight,\n      rootClipsX,\n      rootScrollsX: !rootClipsX && scrollWidth > viewportWidth,\n      rtl: bodyStyle.direction === "rtl",\n      scrollWidth,\n      records,\n      byElement\n    };\n  }\n  function isDeliberateOffset(rec) {\n    const s = rec.style;\n    if ((Number.parseFloat(s.marginLeft) || 0) < 0) return true;\n    if ((Number.parseFloat(s.marginRight) || 0) < 0) return true;\n    if ((Number.parseFloat(s.marginTop) || 0) < 0) return true;\n    if ((Number.parseFloat(s.marginBottom) || 0) < 0) return true;\n    if (s.transform && s.transform !== "none") return true;\n    if (s.position === "relative" && (s.top !== "auto" && s.top !== "0px" || s.left !== "auto" && s.left !== "0px")) {\n      return true;\n    }\n    return false;\n  }\n  function contentBox(rec) {\n    const s = rec.style;\n    const bl = Number.parseFloat(s.borderLeftWidth) || 0;\n    const br = Number.parseFloat(s.borderRightWidth) || 0;\n    const pl = Number.parseFloat(s.paddingLeft) || 0;\n    const pr = Number.parseFloat(s.paddingRight) || 0;\n    const left = rec.rect.left + bl + pl;\n    const right = rec.rect.right - br - pr;\n    return { ...rec.rect, left, right, width: right - left };\n  }\n  function paintedRight(rec) {\n    return Math.max(rec.rect.right, rec.textRect?.right ?? -Infinity);\n  }\n  function paintedLeft(rec) {\n    return Math.min(rec.rect.left, rec.textRect?.left ?? Infinity);\n  }\n  function isInline(style) {\n    return style.display === "inline";\n  }\n  function fontSize(rec) {\n    return Number.parseFloat(rec.style.fontSize) || 16;\n  }\n  var TOUCH_MAX_WIDTH = 767;\n  function px(n) {\n    return Math.round(n);\n  }\n\n  // ../analyzers/src/source.ts\n  var SOURCE_ATTR = "data-bh-src";\n  function fromAttribute(value, exact) {\n    const m = value.match(/^(.+?)(?::(\\d+))?(?::(\\d+))?$/);\n    if (!m?.[1]) return null;\n    return {\n      file: m[1],\n      ...m[2] ? { line: Number(m[2]) } : {},\n      ...m[3] ? { column: Number(m[3]) } : {},\n      exact\n    };\n  }\n  var NOT_APP_CODE = /node_modules|\\/\\.vite\\/deps\\/|\\/@vite\\/|\\/@react-refresh|\\/_next\\/static\\/chunks\\/|react-dom|jsx-dev-runtime|react-stack/;\n  function fileFromStack(stack) {\n    for (const line of stack.split("\\n")) {\n      const m = line.match(/((?:https?|file):\\/\\/[^\\s)]+|webpack-internal:\\/\\/\\/[^\\s)]+):\\d+:\\d+/);\n      const url = m?.[1];\n      if (!url || NOT_APP_CODE.test(url)) continue;\n      if (url.startsWith("webpack-internal:")) {\n        const path = url.match(/\\/\\.\\/(.+)$/)?.[1];\n        if (path) return path.split("?")[0] ?? null;\n        continue;\n      }\n      try {\n        const u = new URL(url);\n        return u.protocol === "file:" ? decodeURIComponent(u.pathname) : u.pathname;\n      } catch {\n      }\n    }\n    return null;\n  }\n  function componentName(type) {\n    if (!type) return void 0;\n    if (typeof type === "function") return type.displayName || type.name || void 0;\n    return type.displayName || componentName(type.type) || componentName(type.render);\n  }\n  function reactSource(el) {\n    const key = Object.keys(el).find((k) => k.startsWith("__reactFiber$"));\n    const fiber = key ? el[key] : null;\n    if (!fiber) return null;\n    const owner = fiber._debugOwner;\n    const component = componentName(owner?.type);\n    const debug = fiber._debugSource;\n    if (debug?.fileName && !NOT_APP_CODE.test(debug.fileName)) {\n      return {\n        file: debug.fileName,\n        ...debug.lineNumber ? { line: debug.lineNumber } : {},\n        ...debug.columnNumber ? { column: debug.columnNumber } : {},\n        ...component ? { component } : {},\n        exact: true\n      };\n    }\n    const stack = fiber._debugStack;\n    const text = typeof stack === "string" ? stack : stack?.stack;\n    const file = typeof text === "string" ? fileFromStack(text) : null;\n    return file ? { file, ...component ? { component } : {}, exact: false } : null;\n  }\n  function vueSource(el) {\n    for (let instance = el.__vueParentComponent; instance; instance = instance.parent) {\n      const file = instance.type?.__file;\n      if (typeof file === "string" && !NOT_APP_CODE.test(file)) {\n        const component = instance.type.__name || instance.type.name;\n        return { file, ...component ? { component } : {}, exact: false };\n      }\n    }\n    return null;\n  }\n  function sourceOf(el) {\n    try {\n      const own = el.getAttribute(SOURCE_ATTR);\n      if (own) return fromAttribute(own, true);\n      const found = reactSource(el) ?? vueSource(el);\n      if (found) return found;\n      const above = el.parentElement?.closest(`[${SOURCE_ATTR}]`);\n      const value = above?.getAttribute(SOURCE_ATTR);\n      return value ? fromAttribute(value, false) : null;\n    } catch {\n      return null;\n    }\n  }\n\n  // ../analyzers/src/selector.ts\n  var cache = /* @__PURE__ */ new WeakMap();\n  var owners = /* @__PURE__ */ new WeakMap();\n  function elementOf(info) {\n    return owners.get(info);\n  }\n  function isStableId(id) {\n    if (!id || /[:\xAB\xBB]/.test(id)) return false;\n    if (/^(radix|headlessui|react-aria|mui|chakra|ember)[-_]/i.test(id)) return false;\n    if (/\\d{3,}/.test(id)) return false;\n    return /^[A-Za-z][\\w-]*$/.test(id);\n  }\n  function usefulClasses(el) {\n    const out = [];\n    for (const c of el.classList) {\n      if (/[:[\\]/!@.%#()]/.test(c)) continue;\n      if (/^(css|sc|jsx|emotion|svelte|astro|styled)-[\\w-]*\\d/i.test(c)) continue;\n      if (/^_?[a-zA-Z]+_[a-zA-Z0-9]+__[\\w-]{4,}$/.test(c)) continue;\n      if (/^[a-z]{1,3}[A-Z0-9]\\w{4,}$/.test(c) && /\\d/.test(c)) continue;\n      out.push(c);\n    }\n    return out.sort((a, b) => score(b) - score(a)).slice(0, 2);\n  }\n  function score(c) {\n    let s = c.length;\n    if (/^(flex|grid|block|inline|hidden|p[trblxy]?-|m[trblxy]?-|w-|h-|text-|bg-|gap-)/.test(c))\n      s -= 20;\n    return s;\n  }\n  function cssEscape(s) {\n    return CSS.escape(s);\n  }\n  function segment(el, withClasses, withNth) {\n    let s = el.tagName.toLowerCase();\n    if (withClasses)\n      s += usefulClasses(el).map((c) => `.${cssEscape(c)}`).join("");\n    if (withNth) {\n      const siblings = el.parentElement?.children ?? el.parentNode?.children;\n      const same = Array.from(siblings ?? []).filter((c) => c.tagName === el.tagName);\n      if (same.length > 1) s += `:nth-of-type(${same.indexOf(el) + 1})`;\n    }\n    return s;\n  }\n  function isUnique(selector, el, root) {\n    try {\n      const found = root.querySelectorAll(selector);\n      return found.length === 1 && found[0] === el;\n    } catch {\n      return false;\n    }\n  }\n  var SHADOW_SEPARATOR = " >>> ";\n  function selectorWithin(el, root) {\n    if (el.id && isStableId(el.id) && isUnique(`#${cssEscape(el.id)}`, el, root))\n      return `#${cssEscape(el.id)}`;\n    const parts = [];\n    let current = el;\n    while (current && current !== document.documentElement) {\n      if (current !== el && current.id && isStableId(current.id)) {\n        parts.unshift(`#${cssEscape(current.id)}`);\n        const candidate = parts.join(" > ");\n        if (isUnique(candidate, el, root)) return candidate;\n        parts.shift();\n      }\n      for (const [cls, nth] of [\n        [true, false],\n        [true, true]\n      ]) {\n        const candidate = [segment(current, cls, nth), ...parts].join(" > ");\n        if (isUnique(candidate, el, root)) return candidate;\n      }\n      parts.unshift(segment(current, true, true));\n      current = current.parentElement;\n    }\n    return parts.join(" > ");\n  }\n  function selectorFor(el) {\n    const root = el.getRootNode();\n    if (root instanceof ShadowRoot) {\n      return `${selectorFor(root.host)}${SHADOW_SEPARATOR}${selectorWithin(el, root)}`;\n    }\n    return selectorWithin(el, document);\n  }\n  var selectors = /* @__PURE__ */ new WeakMap();\n  function cachedSelector(el) {\n    let s = selectors.get(el);\n    if (s === void 0) {\n      s = selectorFor(el);\n      selectors.set(el, s);\n    }\n    return s;\n  }\n  function lineage(el, max = 16) {\n    const out = [];\n    for (let p = composedParent(el); p && p !== document.body && out.length < max; p = composedParent(p)) {\n      out.push(cachedSelector(p));\n    }\n    return out;\n  }\n  function resolveSelector(selector) {\n    let root = document;\n    let found = null;\n    for (const part of selector.split(SHADOW_SEPARATOR)) {\n      if (!root) return null;\n      try {\n        found = root.querySelector(part);\n      } catch {\n        return null;\n      }\n      root = found?.shadowRoot ?? null;\n    }\n    return found;\n  }\n  function readablePath(el) {\n    const parts = [];\n    let current = el;\n    while (current && current !== document.body && parts.length < 4) {\n      const cls = usefulClasses(current)[0];\n      parts.unshift(current.tagName.toLowerCase() + (cls ? `.${cls}` : ""));\n      current = composedParent(current);\n    }\n    return parts.join(" > ");\n  }\n  function openingTag(el) {\n    const tag = el.tagName.toLowerCase();\n    let out = `<${tag}`;\n    for (const attr of el.attributes) {\n      if (attr.name === SOURCE_ATTR) continue;\n      const value = attr.value.length > 60 ? `${attr.value.slice(0, 60)}...` : attr.value;\n      out += value ? ` ${attr.name}="${value.replace(/"/g, "&quot;")}"` : ` ${attr.name}`;\n    }\n    out += ">";\n    return out.length > 200 ? `${out.slice(0, 197)}...>` : out;\n  }\n  function findByText(wanted) {\n    const needle = wanted.replace(/\\s+/g, " ").trim().toLowerCase();\n    if (needle.length < 3 || !document.body) return null;\n    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);\n    for (let node = walker.nextNode(); node; node = walker.nextNode()) {\n      const el = node.parentElement;\n      if (!el || el.closest("script, style, noscript")) continue;\n      const r = el.getBoundingClientRect();\n      if (r.width < 1 || r.height < 1) continue;\n      for (let p = el; p && p !== document.body; p = p.parentElement) {\n        const text = (p.textContent ?? "").replace(/\\s+/g, " ").toLowerCase();\n        if (text.includes(needle)) return describe(p);\n        if (text.length > needle.length * 4) break;\n      }\n    }\n    return null;\n  }\n  function describe(el) {\n    const cached = cache.get(el);\n    if (cached) return cached;\n    const text = (el.textContent ?? "").replace(/\\s+/g, " ").trim();\n    const info = {\n      selector: cachedSelector(el),\n      path: readablePath(el),\n      html: openingTag(el),\n      text: text ? text.length > 80 ? `${text.slice(0, 77)}...` : text : null,\n      source: sourceOf(el)\n    };\n    cache.set(el, info);\n    owners.set(info, el);\n    return info;\n  }\n\n  // ../analyzers/src/detectors/page-overflow.ts\n  var TOLERANCE = 0.5;\n  var SIDEWAYS_CONTENT = /* @__PURE__ */ new Set(["TABLE", "PRE", "CODE"]);\n  var PAGE_CONTENT = "h1,h2,h3,h4,form,input,textarea,select,main,article";\n  function wrapperEdge(snap, rec) {\n    const container = rec.clipAncestor;\n    if (!container) return { kind: "root" };\n    const vw = snap.viewportWidth;\n    if (container.rect.left > 1 || container.rect.right < vw - 1) return null;\n    const cs = container.style;\n    if (cs.scrollSnapType && cs.scrollSnapType !== "none") return null;\n    const holdsPage = container.rect.height >= snap.viewportHeight / 2 || container.el.querySelector(PAGE_CONTENT) !== null;\n    if (!holdsPage) return null;\n    for (let p = rec; p && p !== container; p = p.parent) {\n      if (SIDEWAYS_CONTENT.has(p.el.tagName)) return null;\n      if (p.style.transform && p.style.transform !== "none") return null;\n    }\n    return {\n      kind: "wrapper",\n      container,\n      scrolls: cs.overflowX === "auto" || cs.overflowX === "scroll"\n    };\n  }\n  function sticksOut(snap, rec) {\n    if (isVisuallyHidden(rec)) return null;\n    const right = paintedRight(rec);\n    const left = paintedLeft(rec);\n    if (right <= snap.viewportWidth + TOLERANCE && left >= -TOLERANCE) return null;\n    if (rec.outOfFlow === "fixed") {\n      return rec.clipAncestor ? null : { rec, right, left, edge: { kind: "screen" } };\n    }\n    const edge = wrapperEdge(snap, rec);\n    return edge ? { rec, right, left, edge } : null;\n  }\n  function pageOverflow(snap) {\n    const hits = /* @__PURE__ */ new Map();\n    for (const rec of snap.records) {\n      const hit = sticksOut(snap, rec);\n      if (hit) hits.set(rec, hit);\n    }\n    const findings = [];\n    for (const hit of hits.values()) {\n      const { rec, edge } = hit;\n      let p = rec.parent;\n      let covered = false;\n      while (p) {\n        if (hits.has(p)) {\n          covered = true;\n          break;\n        }\n        p = p.parent;\n      }\n      if (covered) continue;\n      const vw = snap.viewportWidth;\n      const clipped = edge.kind === "root" ? snap.rootClipsX : edge.kind === "screen" || !edge.scrolls;\n      const fullyOffscreen = hit.left >= vw || hit.right <= 0;\n      if (clipped && fullyOffscreen) continue;\n      const overflowRight = Math.max(0, hit.right - vw);\n      const overflowLeft = Math.max(0, -hit.left);\n      const side = overflowRight >= overflowLeft ? "right" : "left";\n      const amount = px(Math.max(overflowRight, overflowLeft));\n      if (amount < 1) continue;\n      const endSide = snap.rtl ? "left" : "right";\n      const scrolls = side === endSide && (edge.kind === "root" ? snap.rootScrollsX : edge.kind === "wrapper" && edge.scrolls);\n      if (!scrolls && rec.outOfFlow && isDecorative(rec.el)) continue;\n      if (!scrolls && isOrnament(rec)) continue;\n      const textOnly = rec.rect.right <= vw + TOLERANCE && rec.rect.left >= -TOLERANCE;\n      let title;\n      if (!scrolls) title = `Content cut off at the ${side} edge by ${amount}px`;\n      else if (edge.kind === "root")\n        title = `Page scrolls horizontally (${amount}px wider than the viewport)`;\n      else title = `Content scrolls sideways inside a full-width container (${amount}px too wide)`;\n      findings.push({\n        suggestion: shrinkSuggestion(rec, textOnly),\n        detector: "page-overflow",\n        severity: scrolls ? "error" : "warning",\n        title,\n        element: describe(rec.el),\n        lineage: lineage(rec.el),\n        ...edge.kind === "wrapper" ? { related: describe(edge.container.el) } : {},\n        evidence: {\n          overflowPx: amount,\n          side,\n          viewportWidth: vw,\n          elementWidth: px(rec.rect.width),\n          causedByText: textOnly,\n          clippedBy: edge.kind === "root" ? snap.rootClipsX ? "page" : "none" : edge.kind === "screen" ? "screen" : "wrapper"\n        },\n        styles: pick(rec.style, [\n          "width",\n          "min-width",\n          "max-width",\n          "white-space",\n          "overflow-wrap",\n          "word-break",\n          "flex-shrink",\n          "position",\n          "margin-left",\n          "margin-right",\n          "transform"\n        ])\n      });\n    }\n    return findings;\n  }\n  function longestWord(text) {\n    let longest = "";\n    for (const raw of text.split(/\\s+/)) {\n      const word = raw.replace(/^[^\\p{L}\\p{N}]+|[^\\p{L}\\p{N}]+$/gu, "");\n      if (word.length > longest.length) longest = word;\n    }\n    return longest;\n  }\n  function shrinkSuggestion(rec, textOnly) {\n    const s = rec.style;\n    if (textOnly) {\n      if (s.whiteSpace === "nowrap" || s.whiteSpace === "pre") {\n        return `white-space: ${s.whiteSpace} keeps this text on one line. Allow it to wrap on small screens.`;\n      }\n      const word = longestWord(rec.text);\n      if (word && /^[\\p{L}\\p{M}\'\u2019-]+$/u.test(word)) {\n        const size = Number.parseFloat(s.fontSize);\n        return size >= 24 ? `The word "${word}" is wider than the screen at ${Math.round(size)}px. Scale the text down on small screens, for example font-size: clamp(1.75rem, 4vw + 1rem, ${Math.round(size / 16 * 100) / 100}rem).` : `The word "${word}" is too long to fit here. Add hyphens: auto (with a lang attribute on the page) or overflow-wrap: break-word.`;\n      }\n      return "Long unbreakable text (a URL, email or code). Add overflow-wrap: anywhere to its container.";\n    }\n    const minWidth = Number.parseFloat(s.minWidth);\n    if (minWidth > 0) {\n      return `min-width: ${s.minWidth} stops it from shrinking. Lower it or drop it on small screens.`;\n    }\n    if (s.flexShrink === "0") {\n      return "flex-shrink: 0 stops it from shrinking. Let it shrink, or wrap the row.";\n    }\n    if (s.whiteSpace === "nowrap") {\n      return "white-space: nowrap keeps its content on one line. Allow wrapping on small screens.";\n    }\n    const parent = rec.parent?.style.display ?? "";\n    if (parent.includes("flex") || parent.includes("grid")) {\n      return "It is a flex/grid item that will not shrink below its content. Add min-width: 0 to it, or replace its fixed width with max-width: 100%.";\n    }\n    return "It is wider than the screen here. Replace any fixed width with max-width: 100% or a fluid width.";\n  }\n  var CONTENT_SELECTOR = "img,video,canvas,iframe,input,button,select,textarea,a[href]";\n  function isDecorative(el) {\n    if (el.matches(CONTENT_SELECTOR)) return false;\n    if (el.textContent?.trim()) return false;\n    if (el.querySelector(CONTENT_SELECTOR)) return false;\n    if (el.shadowRoot) return false;\n    for (const child of el.querySelectorAll("*")) if (child.shadowRoot) return false;\n    return true;\n  }\n  var DEFAULT_VALUES = {\n    "flex-shrink": "1",\n    position: "static",\n    "object-fit": "fill",\n    overflow: "visible",\n    "flex-basis": "auto",\n    transform: "none"\n  };\n  function pick(style, props) {\n    const out = {};\n    for (const prop of props) {\n      const v = style.getPropertyValue(prop);\n      if (!v || v === "none" || v === "normal" || v === "auto" || v === "0px") continue;\n      if (DEFAULT_VALUES[prop] === v) continue;\n      out[prop] = v;\n    }\n    return out;\n  }\n\n  // ../analyzers/src/detectors/containment.ts\n  var TOLERANCE2 = 1;\n  var VERTICAL_TOLERANCE = 2;\n  var MEDIA = /* @__PURE__ */ new Set(["IMG", "VIDEO", "IFRAME", "CANVAS", "EMBED", "OBJECT", "svg", "PICTURE"]);\n  function alpha(color) {\n    if (!color || color === "transparent") return 0;\n    const m = color.match(/rgba?\\(([^)]+)\\)/);\n    if (!m?.[1]) return 1;\n    const parts = m[1].split(/[\\s,/]+/).filter(Boolean);\n    return parts.length >= 4 ? Number.parseFloat(parts[3] ?? "1") : 1;\n  }\n  function effectiveBackground(rec) {\n    let p = rec;\n    while (p) {\n      if (alpha(p.style.backgroundColor) > 0) return p.style.backgroundColor;\n      p = p.parent;\n    }\n    const body = getComputedStyle(document.body).backgroundColor;\n    if (alpha(body) > 0) return body;\n    return getComputedStyle(document.documentElement).backgroundColor;\n  }\n  function isBounded(rec) {\n    const s = rec.style;\n    if (clipsX(s) || isInline(s) || rec.rect.width < 24 || rec.rect.height < 16) return false;\n    const border = Number.parseFloat(s.borderLeftWidth) > 0 && alpha(s.borderLeftColor) > 0 || Number.parseFloat(s.borderRightWidth) > 0 && alpha(s.borderRightColor) > 0;\n    if (border) return true;\n    if (s.boxShadow && s.boxShadow !== "none") return true;\n    if (s.backgroundImage && s.backgroundImage !== "none") return true;\n    const bg = s.backgroundColor;\n    return alpha(bg) > 0 && bg !== effectiveBackground(rec.parent);\n  }\n  function sameContext(a, b) {\n    return a.oofRoot === b.oofRoot && a.clipAncestor === b.clipAncestor;\n  }\n  function overflowAmount(child, box) {\n    return Math.max(paintedRight(child) - box.right, box.left - paintedLeft(child), 0);\n  }\n  function overflowBelow(child, container) {\n    if (isInline(child.style)) return 0;\n    return Math.max(child.rect.bottom - container.rect.bottom, 0);\n  }\n  function offsetOnPurpose(rec, container) {\n    for (let p = rec; p && p !== container; p = p.parent) {\n      if (isDeliberateOffset(p) || p.style.float !== "none") return true;\n    }\n    return false;\n  }\n  function contentOverflow(snap) {\n    const bounded = /* @__PURE__ */ new Set();\n    for (const rec of snap.records) if (isBounded(rec)) bounded.add(rec);\n    const findings = [];\n    const escapes = /* @__PURE__ */ new Map();\n    for (const rec of snap.records) {\n      if (isVisuallyHidden(rec) || rec.outOfFlow === "fixed") continue;\n      let container = rec.parent;\n      while (container && !bounded.has(container)) container = container.parent;\n      if (!container || !sameContext(rec, container)) continue;\n      const sideways = overflowAmount(rec, container.rect);\n      if (sideways > TOLERANCE2) {\n        const side = paintedRight(rec) - container.rect.right >= sideways - 0.01 ? "right" : "left";\n        escapes.set(rec, { container, side, amount: sideways });\n        continue;\n      }\n      const below = overflowBelow(rec, container);\n      if (below > VERTICAL_TOLERANCE && !offsetOnPurpose(rec, container)) {\n        escapes.set(rec, { container, side: "bottom", amount: below });\n      }\n    }\n    for (const [rec, { container, side, amount: raw }] of escapes) {\n      if (rec.parent && escapes.get(rec.parent)?.container === container) continue;\n      const amount = px(raw);\n      if (side === "bottom") {\n        findings.push({\n          detector: "content-overflow",\n          severity: "error",\n          title: `Content spills ${amount}px out of the bottom of its container`,\n          element: describe(rec.el),\n          related: describe(container.el),\n          evidence: {\n            overflowPx: amount,\n            side,\n            containerHeight: px(container.rect.height),\n            elementHeight: px(rec.rect.height)\n          },\n          styles: pick(container.style, ["height", "max-height", "min-height"]),\n          suggestion: `The container is ${px(container.rect.height)}px tall and its content needs more room at this width. Use min-height instead of a fixed height.`\n        });\n        continue;\n      }\n      const textOnly = rec.rect.right <= container.rect.right + TOLERANCE2 && rec.rect.left >= container.rect.left - TOLERANCE2;\n      findings.push({\n        suggestion: shrinkSuggestion(rec, textOnly),\n        detector: "content-overflow",\n        severity: "error",\n        title: textOnly ? `Text spills ${amount}px outside its container` : `Content spills ${amount}px outside its container`,\n        element: describe(rec.el),\n        lineage: lineage(rec.el),\n        related: describe(container.el),\n        evidence: {\n          overflowPx: amount,\n          side,\n          containerWidth: px(container.rect.width),\n          elementWidth: px(rec.rect.width),\n          causedByText: textOnly\n        },\n        styles: pick(rec.style, [\n          "width",\n          "min-width",\n          "white-space",\n          "overflow-wrap",\n          "word-break",\n          "flex-shrink",\n          "flex-basis"\n        ])\n      });\n    }\n    return findings;\n  }\n  function isMedia(el) {\n    return MEDIA.has(el.tagName);\n  }\n  function mediaOverflow(snap) {\n    const findings = [];\n    for (const rec of snap.records) {\n      if (!isMedia(rec.el) || rec.outOfFlow) continue;\n      if (rec.el.tagName === "PICTURE") continue;\n      let container = rec.parent;\n      while (container && (isInline(container.style) || container.el.tagName === "PICTURE")) {\n        container = container.parent;\n      }\n      if (!container || container.clipAncestor !== rec.clipAncestor || clipsX(container.style))\n        continue;\n      const ml = Number.parseFloat(rec.style.marginLeft) || 0;\n      const mr = Number.parseFloat(rec.style.marginRight) || 0;\n      if (ml < 0 || mr < 0) continue;\n      const box = contentBox(container);\n      const excess = rec.rect.width - box.width;\n      if (excess <= TOLERANCE2 || rec.rect.right <= box.right + TOLERANCE2) continue;\n      findings.push({\n        detector: "media-overflow",\n        severity: "error",\n        title: `${label(rec.el)} is ${px(excess)}px wider than its container`,\n        element: describe(rec.el),\n        lineage: lineage(rec.el),\n        related: describe(container.el),\n        evidence: {\n          overflowPx: px(excess),\n          mediaWidth: px(rec.rect.width),\n          containerWidth: px(box.width)\n        },\n        styles: pick(rec.style, ["width", "min-width", "max-width", "height", "object-fit"]),\n        suggestion: "Add max-width: 100% and height: auto so it scales down with its container."\n      });\n    }\n    return findings;\n  }\n  function label(el) {\n    switch (el.tagName) {\n      case "IMG":\n        return "Image";\n      case "VIDEO":\n        return "Video";\n      case "IFRAME":\n      case "EMBED":\n      case "OBJECT":\n        return "Embed";\n      case "CANVAS":\n        return "Canvas";\n      default:\n        return "Graphic";\n    }\n  }\n\n  // ../analyzers/src/detectors/elements.ts\n  var MAX_DISTORTION = 0.05;\n  var MIN_TARGET = 24;\n  var TARGETS = \'a[href], button, input:not([type="hidden"]), select, textarea, summary, [role="button"], [role="link"], [role="tab"], [role="menuitem"], [role="checkbox"], [role="switch"], [tabindex]:not([tabindex="-1"])\';\n  function distortedMedia(snap) {\n    const findings = [];\n    for (const rec of snap.records) {\n      if (rec.el.tagName !== "IMG" || isVisuallyHidden(rec)) continue;\n      const img = rec.el;\n      if (!img.complete || !img.naturalWidth || !img.naturalHeight) continue;\n      if (/\\.svg(\\?|#|$)|^data:image\\/svg/i.test(img.currentSrc || img.src)) continue;\n      if (rec.style.objectFit && rec.style.objectFit !== "fill") continue;\n      const s = rec.style;\n      const w = rec.rect.width - (Number.parseFloat(s.paddingLeft) || 0) - (Number.parseFloat(s.paddingRight) || 0) - (Number.parseFloat(s.borderLeftWidth) || 0) - (Number.parseFloat(s.borderRightWidth) || 0);\n      const h = rec.rect.height - (Number.parseFloat(s.paddingTop) || 0) - (Number.parseFloat(s.paddingBottom) || 0) - (Number.parseFloat(s.borderTopWidth) || 0) - (Number.parseFloat(s.borderBottomWidth) || 0);\n      if (w < 16 || h < 16) continue;\n      const natural = img.naturalWidth / img.naturalHeight;\n      const rendered = w / h;\n      const distortion = Math.abs(rendered / natural - 1);\n      if (distortion <= MAX_DISTORTION) continue;\n      findings.push({\n        detector: "distorted-media",\n        severity: "warning",\n        title: `Image is ${rendered > natural ? "stretched" : "squashed"} ${Math.round(distortion * 100)}% out of proportion`,\n        element: describe(rec.el),\n        evidence: {\n          renderedRatio: Math.round(rendered * 100) / 100,\n          naturalRatio: Math.round(natural * 100) / 100,\n          renderedWidth: px(w),\n          renderedHeight: px(h)\n        },\n        styles: pick(rec.style, ["width", "height", "max-width", "object-fit", "aspect-ratio"]),\n        suggestion: "Keep width and height proportional (height: auto), or crop with object-fit: cover."\n      });\n    }\n    return findings;\n  }\n  function center(b) {\n    return { x: (b.left + b.right) / 2, y: (b.top + b.bottom) / 2 };\n  }\n  function distanceToBox(p, b) {\n    const dx = Math.max(b.left - p.x, 0, p.x - b.right);\n    const dy = Math.max(b.top - p.y, 0, p.y - b.bottom);\n    return Math.hypot(dx, dy);\n  }\n  function isInlineTextLink(rec) {\n    if (rec.el.tagName !== "A" || !rec.style.display.startsWith("inline")) return false;\n    const parent = rec.el.parentElement;\n    if (!parent) return false;\n    const own = rec.el.textContent?.trim().length ?? 0;\n    const around = parent.textContent?.trim().length ?? 0;\n    return around > own + 10;\n  }\n  function hasLabel(el) {\n    if (!(el instanceof HTMLInputElement)) return false;\n    if (el.type !== "checkbox" && el.type !== "radio") return false;\n    return (el.labels?.length ?? 0) > 0;\n  }\n  function smallTapTargets(snap) {\n    if (snap.viewportWidth > TOUCH_MAX_WIDTH) return [];\n    const targets = [];\n    for (const rec of snap.records) {\n      if (!rec.el.matches(TARGETS) || isVisuallyHidden(rec)) continue;\n      if (rec.el.matches(\'[disabled], [aria-disabled="true"]\')) continue;\n      if (rec.rect.width === 0 || rec.rect.height === 0) continue;\n      let nested = false;\n      for (let p = rec.parent; p; p = p.parent) {\n        if (p.el.matches(TARGETS)) {\n          nested = true;\n          break;\n        }\n      }\n      if (!nested) targets.push(rec);\n    }\n    const failing = [];\n    for (const rec of targets) {\n      const { width, height } = rec.rect;\n      if (width >= MIN_TARGET && height >= MIN_TARGET) continue;\n      if (isInlineTextLink(rec) || hasLabel(rec.el)) continue;\n      const c = center(rec.rect);\n      const crowded = targets.some((other) => {\n        if (other === rec) return false;\n        if (distanceToBox(c, other.rect) < MIN_TARGET / 2) return true;\n        const small = other.rect.width < MIN_TARGET || other.rect.height < MIN_TARGET;\n        const oc = center(other.rect);\n        return small && Math.hypot(oc.x - c.x, oc.y - c.y) < MIN_TARGET;\n      });\n      if (crowded) failing.push(rec);\n    }\n    const siblings = /* @__PURE__ */ new Map();\n    for (const rec of targets) siblings.set(rec.parent, (siblings.get(rec.parent) ?? 0) + 1);\n    const byParent = /* @__PURE__ */ new Map();\n    for (const rec of failing) {\n      const list = byParent.get(rec.parent);\n      if (list) list.push(rec);\n      else byParent.set(rec.parent, [rec]);\n    }\n    const findings = [];\n    for (const [parent, list] of byParent) {\n      const first = list[0];\n      if (!first) continue;\n      const grouped = parent !== null && (siblings.get(parent) ?? 0) > 1;\n      const minW = Math.min(...list.map((r) => r.rect.width));\n      const minH = Math.min(...list.map((r) => r.rect.height));\n      findings.push({\n        detector: "small-tap-target",\n        severity: "warning",\n        title: list.length > 1 ? `${list.length} tap targets are ${px(minW)}\\xD7${px(minH)}px and crowd each other` : `Tap target is ${px(first.rect.width)}\\xD7${px(first.rect.height)}px and too close to its neighbours`,\n        element: describe(grouped ? parent.el : first.el),\n        ...grouped ? { related: describe(first.el) } : {},\n        evidence: { width: px(minW), height: px(minH), minimum: MIN_TARGET, targets: list.length },\n        styles: pick(first.style, ["width", "height", "padding", "font-size"]),\n        suggestion: "Make each target at least 24\\xD724px (44\\xD744px is better for touch), or add space between them."\n      });\n    }\n    return findings;\n  }\n  function viewportMeta() {\n    const meta = document.querySelector(\'meta[name="viewport" i]\');\n    const content = meta?.getAttribute("content")?.replace(/\\s+/g, "") ?? "";\n    if (/width=device-width/i.test(content)) return [];\n    const head = document.head ?? document.documentElement;\n    return [\n      {\n        detector: "viewport-meta",\n        severity: "error",\n        title: meta ? "Viewport meta tag does not use width=device-width" : "Missing the responsive viewport meta tag",\n        element: describe(meta ?? head),\n        evidence: { content: content || "missing" },\n        styles: {},\n        suggestion: \'Add <meta name="viewport" content="width=device-width, initial-scale=1"> to <head>. Without it phones render the page at desktop width and shrink it.\'\n      }\n    ];\n  }\n\n  // ../analyzers/src/detectors/overlap.ts\n  var MIN_OVERLAP = 4;\n  var BAND_PX = 200;\n  var MIN_TEXT_LINE_SHARE = 0.3;\n  var REPLACED = /* @__PURE__ */ new Set([\n    "IMG",\n    "VIDEO",\n    "CANVAS",\n    "IFRAME",\n    "svg",\n    "INPUT",\n    "SELECT",\n    "TEXTAREA",\n    "BUTTON"\n  ]);\n  function itemBox(rec) {\n    const raw = REPLACED.has(rec.el.tagName) ? rec.rect : rec.textRect;\n    if (!raw || raw.width <= 0 || raw.height <= 0) return null;\n    return intersectBox(raw, rec.clip);\n  }\n  function ancestors(rec) {\n    const chain = [];\n    let p = rec;\n    while (p) {\n      chain.push(p);\n      p = p.parent;\n    }\n    return chain;\n  }\n  function isExplicitlyPlacedGridItem(rec) {\n    const s = rec.style;\n    return s.gridRowStart !== "auto" || s.gridColumnStart !== "auto";\n  }\n  function branches(a, b) {\n    const chainA = ancestors(a).reverse();\n    const chainB = ancestors(b).reverse();\n    let i = 0;\n    while (i < chainA.length && i < chainB.length && chainA[i] === chainB[i]) i++;\n    const branchA = chainA[i];\n    const branchB = chainB[i];\n    if (!branchA || !branchB) return null;\n    const lca = i > 0 ? chainA[i - 1] ?? null : null;\n    for (const rec of chainA.slice(i)) if (isDeliberateOffset(rec)) return null;\n    for (const rec of chainB.slice(i)) if (isDeliberateOffset(rec)) return null;\n    if (lca?.style.display.includes("grid")) {\n      if (isExplicitlyPlacedGridItem(branchA) && isExplicitlyPlacedGridItem(branchB)) return null;\n    }\n    return { lca, a: branchA, b: branchB };\n  }\n  function intersect(a, b) {\n    return {\n      w: Math.min(a.right, b.right) - Math.max(a.left, b.left),\n      h: Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top)\n    };\n  }\n  function paintedOverlap(x, y) {\n    let best = { w: 0, h: 0 };\n    for (const a of x.parts) {\n      for (const b of y.parts) {\n        const o = intersect(a, b);\n        if (o.w > 0 && o.h > 0 && o.w * o.h > best.w * best.h) best = o;\n      }\n    }\n    return best;\n  }\n  var SPILL_PX = 2;\n  function spillOf(branch, x, y) {\n    for (const item of [x, y]) {\n      if (!ancestors(item.rec).includes(branch) || item.rec === branch) continue;\n      const box = branch.rect;\n      if (item.box.bottom > box.bottom + SPILL_PX) return { box: branch, direction: "down" };\n      if (item.box.right > box.right + SPILL_PX || item.box.left < box.left - SPILL_PX) {\n        return { box: branch, direction: "across" };\n      }\n    }\n    return null;\n  }\n  function name(rec) {\n    return `\\`${describe(rec.el).selector}\\``;\n  }\n  function suggestionFor(g) {\n    if (g.spill?.direction === "down") {\n      return `The content of ${name(g.spill.box)} is taller than its box at this width and runs down over what comes next. Its height is fixed (height or max-height) and the content no longer fits once it wraps; use min-height instead, or let it grow with its content.`;\n    }\n    if (g.spill?.direction === "across") {\n      return `The content of ${name(g.spill.box)} is wider than its box at this width and runs sideways into its neighbour. Let it shrink or wrap (min-width: 0 on flex or grid items, overflow-wrap: anywhere for long words, max-width: 100% for media).`;\n    }\n    const lca = g.lca;\n    const display = lca?.style.display ?? "";\n    if (lca && display.includes("flex") && !lca.style.flexDirection.startsWith("column")) {\n      return `They sit side by side in the flex row ${name(lca)}, which runs out of room at this width. Let the row wrap (flex-wrap: wrap), let the item that should give way shrink (min-width: 0), or stack them below this width with a media query.`;\n    }\n    if (lca && display.includes("grid")) {\n      return `They share the grid ${name(lca)}, whose columns are too narrow here for what is in them. Use minmax(0, 1fr) columns so items can shrink, or switch to fewer columns below this width.`;\n    }\n    return "These two areas stop making room for each other at this width. Stack them earlier with a media query, or let the narrower one shrink (min-width: 0).";\n  }\n  function overlap(snap) {\n    const items = [];\n    for (const rec of snap.records) {\n      if (rec.outOfFlow || isVisuallyHidden(rec)) continue;\n      const box = itemBox(rec);\n      if (!box || box.width < 1 || box.height < 1) continue;\n      const isText = !REPLACED.has(rec.el.tagName);\n      const parts = isText ? rec.textFragments.map((f) => intersectBox(f, rec.clip)).filter((f) => !!f && f.width > 0 && f.height > 0) : [];\n      items.push({\n        rec,\n        box,\n        parts: parts.length ? parts : [box],\n        lineHeight: isText ? box.height / Math.max(1, rec.textLines) : 0\n      });\n    }\n    const groups = /* @__PURE__ */ new Map();\n    const index = /* @__PURE__ */ new Map();\n    for (const [i, r] of snap.records.entries()) index.set(r, i);\n    const bands = /* @__PURE__ */ new Map();\n    for (const item of items) {\n      const last = Math.floor(item.box.bottom / BAND_PX);\n      for (let b = Math.floor(item.box.top / BAND_PX); b <= last; b++) {\n        const list = bands.get(b);\n        if (list) list.push(item);\n        else bands.set(b, [item]);\n      }\n    }\n    for (const [band, list] of bands) {\n      list.sort((x, y) => x.box.left - y.box.left);\n      for (let i = 0; i < list.length; i++) {\n        const x = list[i];\n        for (let j = i + 1; j < list.length; j++) {\n          const y = list[j];\n          if (y.box.left >= x.box.right - MIN_OVERLAP) break;\n          if (Math.floor(Math.max(x.box.top, y.box.top) / BAND_PX) !== band) continue;\n          const rough = intersect(x.box, y.box);\n          if (rough.w < MIN_OVERLAP || rough.h < MIN_OVERLAP) continue;\n          const { w, h } = paintedOverlap(x, y);\n          const minH = Math.max(\n            MIN_OVERLAP,\n            MIN_TEXT_LINE_SHARE * Math.max(x.lineHeight, y.lineHeight)\n          );\n          if (w < MIN_OVERLAP || h < minH) continue;\n          const split = branches(x.rec, y.rec);\n          if (!split) continue;\n          const [first, second] = (index.get(split.a) ?? 0) < (index.get(split.b) ?? 0) ? [split.a, split.b] : [split.b, split.a];\n          const key = `${index.get(first)}:${index.get(second)}`;\n          const spill = spillOf(first, x, y) ?? spillOf(second, x, y);\n          const g = groups.get(key);\n          if (g) {\n            g.w = Math.max(g.w, w);\n            g.h = Math.max(g.h, h);\n            g.pairs++;\n            g.spill ??= spill;\n          } else {\n            groups.set(key, { a: first, b: second, lca: split.lca, w, h, pairs: 1, spill });\n          }\n        }\n      }\n    }\n    const findings = [];\n    for (const g of groups.values()) {\n      findings.push({\n        detector: "overlap",\n        severity: "error",\n        title: `Overlaps another element (${px(g.w)}\\xD7${px(g.h)}px)`,\n        element: describe(g.a.el),\n        related: describe(g.b.el),\n        evidence: { overlapWidth: px(g.w), overlapHeight: px(g.h), overlappingPairs: g.pairs },\n        suggestion: suggestionFor(g),\n        styles: pick(g.a.style, [\n          "display",\n          "position",\n          "width",\n          "min-width",\n          "flex-shrink",\n          "grid-template-columns"\n        ])\n      });\n    }\n    return findings;\n  }\n\n  // ../analyzers/src/detectors/text.ts\n  var CUT_TOLERANCE = 1;\n  var MIN_GUTTER = 4;\n  var MIN_TINY_FONT = 12;\n  var MAX_TINY_FINDINGS = 8;\n  var MIN_LARGE_FONT = 28;\n  var MIN_LARGE_CHARS_PER_LINE = 12;\n  var MAX_LARGE_FINDINGS = 8;\n  function scrollsOn(style, axis) {\n    const v = axis === "x" ? style.overflowX : style.overflowY;\n    return v === "auto" || v === "scroll";\n  }\n  function clipsOn(style, axis) {\n    return (axis === "x" ? style.overflowX : style.overflowY) !== "visible";\n  }\n  function truncatesOnPurpose(rec, axis) {\n    const s = rec.style;\n    if (axis === "x") return s.textOverflow === "ellipsis" || s.textOverflow === "clip";\n    return !!s.webkitLineClamp && s.webkitLineClamp !== "none";\n  }\n  function findClipper(rec, raw, axis) {\n    for (let p = rec; p; p = p.parent) {\n      if (!clipsOn(p.style, axis)) continue;\n      const cut = axis === "x" ? raw.left < p.rect.left - CUT_TOLERANCE || raw.right > p.rect.right + CUT_TOLERANCE : raw.top < p.rect.top - CUT_TOLERANCE || raw.bottom > p.rect.bottom + CUT_TOLERANCE;\n      if (cut) return p;\n    }\n    return null;\n  }\n  function clippersWithVisibleText(snap) {\n    const out = /* @__PURE__ */ new Set();\n    for (const rec of snap.records) {\n      if (!rec.textRect) continue;\n      for (let p = rec.parent; p; p = p.parent) {\n        if (out.has(p)) break;\n        if (clipsOn(p.style, "y")) out.add(p);\n      }\n    }\n    return out;\n  }\n  function clippedText(snap) {\n    const byClipper = /* @__PURE__ */ new Map();\n    const vw = snap.viewportWidth;\n    let showing = null;\n    for (const rec of snap.records) {\n      const raw = rec.rawTextRect;\n      if (!raw || rec.outOfFlow === "fixed" || isVisuallyHidden(rec) || isOrnament(rec)) continue;\n      const visible = intersectBox(raw, rec.innerClip);\n      let axis;\n      let clipper;\n      let cut;\n      if (visible) {\n        const cutX = raw.width - visible.width;\n        const cutY = raw.height - visible.height;\n        axis = cutY > CUT_TOLERANCE ? "y" : cutX > CUT_TOLERANCE ? "x" : null;\n        if (!axis) continue;\n        clipper = findClipper(rec, raw, axis);\n        cut = axis === "x" ? cutX : cutY;\n      } else {\n        axis = "y";\n        clipper = findClipper(rec, raw, "y");\n        if (!clipper || raw.top < clipper.rect.bottom - CUT_TOLERANCE) continue;\n        showing ??= clippersWithVisibleText(snap);\n        if (!showing.has(clipper)) continue;\n        cut = raw.bottom - clipper.rect.bottom;\n      }\n      if (!clipper || scrollsOn(clipper.style, axis) || clipper.rect.height < 2) continue;\n      if (axis === "x" && clipper.rect.left <= 1 && clipper.rect.right >= vw - 1) continue;\n      let deliberate = false;\n      for (let p = rec; p; p = p.parent) {\n        if (truncatesOnPurpose(p, axis) || p.style.transform && p.style.transform !== "none") {\n          deliberate = true;\n          break;\n        }\n        if (p === clipper) break;\n      }\n      if (deliberate) continue;\n      const prev = byClipper.get(clipper);\n      if (prev) {\n        prev.count++;\n        if (cut > prev.cut) Object.assign(prev, { rec, axis, cut });\n      } else {\n        byClipper.set(clipper, { rec, axis, cut, count: 1 });\n      }\n    }\n    const findings = [];\n    for (const [clipper, { rec, axis, cut, count }] of byClipper) {\n      const fixedSize = axis === "y" ? clipper.style.height : clipper.style.width;\n      findings.push({\n        detector: "clipped-text",\n        severity: "warning",\n        title: `Container cuts off its text (${px(cut)}px hidden ${axis === "y" ? "below" : "to the side"})`,\n        element: describe(clipper.el),\n        related: describe(rec.el),\n        evidence: { hiddenPx: px(cut), axis, clippedTextElements: count },\n        styles: pick(clipper.style, [\n          "height",\n          "max-height",\n          "width",\n          "max-width",\n          "overflow",\n          "white-space"\n        ]),\n        suggestion: axis === "y" ? `The container clips its content at ${fixedSize}. Let it grow (min-height instead of height), or truncate on purpose with line-clamp.` : "The container is too narrow for this text. Let the text wrap, or truncate on purpose with text-overflow: ellipsis."\n      });\n    }\n    return findings;\n  }\n  function lineText(rec) {\n    for (const child of rec.el.children) {\n      const display = getComputedStyle(child).display;\n      if (display !== "none" && !display.startsWith("inline")) return rec.text;\n    }\n    const el = rec.el;\n    return (el.innerText ?? el.textContent ?? "").replace(/\\s+/g, " ").trim();\n  }\n  function squishedText(snap) {\n    const findings = [];\n    for (const rec of snap.records) {\n      if (!rec.textRect || rec.textLines < 3 || isVisuallyHidden(rec) || isInline(rec.style))\n        continue;\n      const text = lineText(rec);\n      const chars = text.replace(/\\s/g, "").length;\n      if (chars < 8) continue;\n      if (rec.rect.width >= 10 * fontSize(rec)) continue;\n      const words = text.split(" ").filter(Boolean).length;\n      const perLine = chars / rec.textLines;\n      if ((rec.textLines <= words || breaksAnywhere(text)) && perLine >= 3) continue;\n      findings.push({\n        detector: "squished-text",\n        severity: "warning",\n        title: `Text squeezed to about ${Math.max(1, Math.round(perLine))} characters per line`,\n        element: describe(rec.el),\n        evidence: {\n          lines: rec.textLines,\n          charsPerLine: Math.round(perLine * 10) / 10,\n          width: px(rec.rect.width)\n        },\n        styles: pick(rec.style, ["width", "min-width", "flex-basis", "word-break", "overflow-wrap"]),\n        suggestion: "This column gets too narrow at this width. Give it a min-width, or stack the layout earlier."\n      });\n    }\n    return findings;\n  }\n  function browserDefault(rec) {\n    const control = rec.el.closest("button, input, select, textarea");\n    if (!control) return false;\n    const around = control.parentElement;\n    return !!around && fontSize(rec) < Number.parseFloat(getComputedStyle(around).fontSize);\n  }\n  function tinyText(snap) {\n    if (snap.viewportWidth > TOUCH_MAX_WIDTH) return [];\n    const byParent = /* @__PURE__ */ new Map();\n    for (const rec of snap.records) {\n      if (!rec.textRect || rec.text.length < 3 || isVisuallyHidden(rec) || isOrnament(rec)) continue;\n      const size = fontSize(rec);\n      if (size >= MIN_TINY_FONT) continue;\n      const g = byParent.get(rec.parent);\n      if (g) {\n        g.count++;\n        if (size < g.size) Object.assign(g, { rec, size });\n      } else {\n        byParent.set(rec.parent, { rec, size, count: 1 });\n      }\n    }\n    const findings = [];\n    for (const [parent, g] of byParent) {\n      if (findings.length >= MAX_TINY_FINDINGS) break;\n      const grouped = g.count > 1 && parent !== null;\n      const size = Math.round(g.size * 10) / 10;\n      findings.push({\n        detector: "tiny-text",\n        severity: "info",\n        title: g.count > 1 ? `${g.count} pieces of text are ${size}px on small screens` : `Text is ${size}px on small screens`,\n        element: describe(grouped ? parent.el : g.rec.el),\n        ...grouped ? { related: describe(g.rec.el) } : {},\n        evidence: { fontSizePx: size, textElements: g.count },\n        styles: pick(g.rec.style, ["font-size", "line-height"]),\n        suggestion: browserDefault(g.rec) ? "Form controls don\'t take the page\'s font unless told to, and Safari\'s default is 11px. Add font: inherit to button, input, select and textarea." : "Use at least 12px (16px for body text) on small screens."\n      });\n    }\n    return findings;\n  }\n  function forcedLines(el, style) {\n    let lines = 1;\n    const keepsNewlines = /^(pre|pre-wrap|pre-line|break-spaces)$/.test(style.whiteSpace);\n    for (const node of el.childNodes) {\n      if (node.nodeName === "BR") lines++;\n      else if (keepsNewlines && node.nodeType === Node.TEXT_NODE) {\n        lines += (node.textContent?.trim().match(/\\n/g) ?? []).length;\n      }\n    }\n    return lines;\n  }\n  function oversizedText(snap) {\n    const vw = snap.viewportWidth;\n    if (vw > TOUCH_MAX_WIDTH) return [];\n    const findings = [];\n    for (const rec of snap.records) {\n      if (findings.length >= MAX_LARGE_FINDINGS) break;\n      if (!rec.textRect || rec.textLines < 3 || isVisuallyHidden(rec)) continue;\n      const size = fontSize(rec);\n      if (size < MIN_LARGE_FONT) continue;\n      const words = rec.text.split(" ").filter(Boolean).length;\n      if (words < 2) continue;\n      const chars = rec.text.replace(/\\s/g, "").length;\n      const perLine = chars / rec.textLines;\n      if (perLine >= MIN_LARGE_CHARS_PER_LINE) continue;\n      if (rec.textLines > words && rec.rect.width < 10 * size) continue;\n      if (rec.style.writingMode && !rec.style.writingMode.startsWith("horizontal")) continue;\n      if (rec.outOfFlow || isOrnament(rec)) continue;\n      if (rec.textLines - forcedLines(rec.el, rec.style) < 2) continue;\n      let block = rec;\n      while (!isBlock(block) && block.parent) block = block.parent;\n      const room = block.parent ? contentBox(block.parent).width : vw;\n      if (block.rect.width < room * 0.9 || block.rect.width < vw * 0.6) continue;\n      const rem = Math.round(size / 16 * 100) / 100;\n      findings.push({\n        detector: "oversized-text",\n        severity: "warning",\n        title: `Text is too big for the screen (${px(size)}px, ${rec.textLines} lines of a word or two)`,\n        element: describe(rec.el),\n        evidence: {\n          fontSizePx: px(size),\n          lines: rec.textLines,\n          charsPerLine: Math.round(perLine * 10) / 10,\n          screenShare: Math.round(rec.textRect.height / snap.viewportHeight * 100) / 100\n        },\n        styles: pick(rec.style, ["font-size", "line-height", "letter-spacing"]),\n        suggestion: `Scale it down on small screens, for example font-size: clamp(1.75rem, 4vw + 1rem, ${rem}rem), or a smaller size below 640px.`\n      });\n    }\n    return findings;\n  }\n  function isBlock(rec) {\n    return !rec.style.display.startsWith("inline") && rec.style.display !== "contents";\n  }\n  function edgeGutter(snap) {\n    const vw = snap.viewportWidth;\n    if (vw > TOUCH_MAX_WIDTH) return [];\n    const groups = /* @__PURE__ */ new Map();\n    for (const rec of snap.records) {\n      const t = rec.textRect;\n      if (!t || rec.outOfFlow === "fixed" || isVisuallyHidden(rec) || rec.text.length < 2) continue;\n      if (isOrnament(rec)) continue;\n      if (t.left < -0.5 || t.right > vw + 0.5) continue;\n      let moves = false;\n      let overflows = rec.rect.right > vw + 0.5 || rec.rect.left < -0.5;\n      for (let p = rec.parent; p && !moves && !overflows; p = p.parent) {\n        if (scrollsOn(p.style, "x") || p.style.transform && p.style.transform !== "none") {\n          moves = true;\n        }\n        if (p.rect.right > vw + 0.5 || p.rect.left < -0.5) overflows = true;\n      }\n      if (moves || overflows) continue;\n      let container = rec;\n      while (!isBlock(container) && container.parent) container = container.parent;\n      const box = contentBox(container);\n      const leftGap = box.left;\n      const rightGap = vw - box.right;\n      let side = null;\n      if (leftGap < MIN_GUTTER && t.left < MIN_GUTTER + 0.5) side = "left";\n      else if (rightGap < MIN_GUTTER && (rec.textLines >= 2 || t.right > vw - MIN_GUTTER))\n        side = "right";\n      if (!side) continue;\n      const gap = side === "left" ? leftGap : rightGap;\n      const g = groups.get(container);\n      if (g) {\n        g.count++;\n        if (gap < g.gap) Object.assign(g, { gap, side, rec });\n      } else {\n        groups.set(container, { side, gap, count: 1, rec });\n      }\n    }\n    const findings = [];\n    for (const [container, g] of groups) {\n      findings.push({\n        detector: "edge-gutter",\n        severity: "warning",\n        title: `Text touches the ${g.side} edge of the screen (${Math.max(0, px(g.gap))}px gap)`,\n        element: describe(container.el),\n        evidence: { gapPx: Math.max(0, px(g.gap)), side: g.side, textElements: g.count },\n        styles: pick(container.style, [\n          "padding-left",\n          "padding-right",\n          "margin-left",\n          "margin-right",\n          "width"\n        ]),\n        suggestion: "Add horizontal padding (around 16px) to this container on small screens."\n      });\n    }\n    return findings;\n  }\n\n  // ../analyzers/src/detectors/wrap.ts\n  var NAV_CONTEXT = \'nav, header, [role="navigation"], [role="tablist"], [role="menubar"], [role="banner"]\';\n  var LABEL = \'button, [role="button"], [role="tab"], [role="menuitem"]\';\n  var MAX_LABEL_CHARS = 40;\n  function isRowContainer(rec) {\n    const s = rec.style;\n    if (s.display === "flex" || s.display === "inline-flex") {\n      return s.flexDirection.startsWith("row") && s.flexWrap !== "nowrap";\n    }\n    return false;\n  }\n  function inlineChildren(rec, byElement) {\n    const out = [];\n    for (const child of renderedChildren(rec.el)) {\n      const c = byElement.get(child);\n      if (!c || c.outOfFlow || isVisuallyHidden(c)) continue;\n      out.push(c);\n    }\n    return out;\n  }\n  function allInlineLevel(children) {\n    return children.length > 0 && children.every(\n      (c) => c.style.display.startsWith("inline") && c.style.display !== "inline-table"\n    );\n  }\n  function countRows(children) {\n    const tops = [];\n    for (const c of children) {\n      const half = Math.max(4, c.rect.height / 2);\n      if (!tops.some((t) => Math.abs(t - c.rect.top) < half)) tops.push(c.rect.top);\n    }\n    return tops.length;\n  }\n  function textLinesDeep(el) {\n    const tops = [];\n    const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);\n    const range = document.createRange();\n    for (let node = walker.nextNode(); node; node = walker.nextNode()) {\n      if (!node.textContent?.trim()) continue;\n      const box = node.parentElement?.getBoundingClientRect();\n      if (box && (box.width <= 1 || box.height <= 1)) continue;\n      range.selectNodeContents(node);\n      for (const r of range.getClientRects()) {\n        if (r.width === 0 || r.height === 0) continue;\n        if (!tops.some((t) => Math.abs(t.top - r.top) < Math.max(t.height, r.height) / 2)) {\n          tops.push({ top: r.top, height: r.height });\n        }\n      }\n    }\n    return tops.length;\n  }\n  function wrapStats(snap) {\n    const stats = [];\n    for (const rec of snap.records) {\n      if (isVisuallyHidden(rec)) continue;\n      const children = inlineChildren(rec, snap.byElement);\n      if (children.length >= 2 && (isRowContainer(rec) || allInlineLevel(children))) {\n        if (closestComposed(rec.el, NAV_CONTEXT)) {\n          stats.push({\n            element: describe(rec.el),\n            kind: "row",\n            lines: countRows(children),\n            items: children.length\n          });\n        }\n      }\n      const isLabel = rec.el.matches(LABEL) || rec.el.matches("a[href]") && closestComposed(rec.el, NAV_CONTEXT) !== null;\n      if (isLabel) {\n        const text = rec.el.textContent?.replace(/\\s+/g, " ").trim() ?? "";\n        if (text && text.length <= MAX_LABEL_CHARS && text.includes(" ")) {\n          stats.push({\n            element: describe(rec.el),\n            kind: "label",\n            lines: textLinesDeep(rec.el),\n            items: 1\n          });\n        }\n      }\n    }\n    return stats;\n  }\n\n  // ../analyzers/src/fingerprint.ts\n  var LANDMARKS = /* @__PURE__ */ new Set([\n    "HEADER",\n    "NAV",\n    "MAIN",\n    "ASIDE",\n    "FOOTER",\n    "SECTION",\n    "ARTICLE",\n    "FORM"\n  ]);\n  var MAX_DEPTH = 5;\n  var MAX_ELEMENTS = 400;\n  function isStructural(rec, depth) {\n    if (depth <= 3) return true;\n    if (LANDMARKS.has(rec.el.tagName)) return true;\n    const d = rec.style.display;\n    return depth <= MAX_DEPTH && (d.includes("flex") || d.includes("grid"));\n  }\n  function rowsAndColumns(children) {\n    const rows = [];\n    const counts = [];\n    for (const c of children) {\n      const tol = Math.max(4, Math.min(c.rect.height / 2, 24));\n      const i = rows.findIndex((t) => Math.abs(t - c.rect.top) < tol);\n      if (i === -1) {\n        rows.push(c.rect.top);\n        counts.push(1);\n      } else {\n        counts[i] = (counts[i] ?? 0) + 1;\n      }\n    }\n    return counts.join(".");\n  }\n  function layoutSignature(snap, index) {\n    const children = /* @__PURE__ */ new Map();\n    for (const rec of snap.records) {\n      if (!rec.parent || rec.outOfFlow === "fixed") continue;\n      const list = children.get(rec.parent);\n      if (list) list.push(rec);\n      else children.set(rec.parent, [rec]);\n    }\n    const branchDepth = /* @__PURE__ */ new Map();\n    for (const rec of snap.records) {\n      const parent = rec.parent;\n      const parentDepth = parent ? branchDepth.get(parent) ?? 0 : 0;\n      const branches2 = parent ? (children.get(parent)?.length ?? 0) > 1 : true;\n      branchDepth.set(rec, parentDepth + (branches2 ? 1 : 0));\n    }\n    const parts = [];\n    for (const rec of snap.records) {\n      if (parts.length >= MAX_ELEMENTS) break;\n      if (rec.outOfFlow === "fixed" || !isStructural(rec, branchDepth.get(rec) ?? 0)) continue;\n      const kids = (children.get(rec) ?? []).filter(\n        (c) => !c.outOfFlow && !c.style.display.startsWith("inline")\n      );\n      const s = rec.style;\n      let mode = s.display;\n      if (mode.includes("flex")) mode += `/${s.flexDirection}`;\n      const wraps = mode.includes("flex") && s.flexWrap !== "nowrap";\n      const arrangement = kids.length > 1 && !wraps ? rowsAndColumns(kids) : String(kids.length);\n      parts.push(`${index(rec.el)}=${mode}:${arrangement}`);\n    }\n    return parts.join("|");\n  }\n  var MEDIA_EM = 16;\n  var QUERY_UNITS = "(px|em|rem)";\n  function parseContainerCondition(text) {\n    const out = [];\n    const name2 = text.match(/^\\s*(?!not\\b|style\\b|scroll-state\\b)([a-zA-Z_][\\w-]*)\\s*(?=\\(|$)/)?.[1] ?? null;\n    const add = (value, unit, after) => out.push({ name: name2, value: Number.parseFloat(value), unit, after });\n    const legacy = new RegExp(`(min|max)-(?:width|inline-size)\\\\s*:\\\\s*([\\\\d.]+)${QUERY_UNITS}`, "g");\n    for (let m = legacy.exec(text); m; m = legacy.exec(text)) {\n      add(m[2] ?? "0", m[3] ?? "px", m[1] === "max");\n    }\n    const range = new RegExp(`(?:width|inline-size)\\\\s*(>=|>|<=|<)\\\\s*([\\\\d.]+)${QUERY_UNITS}`, "g");\n    for (let m = range.exec(text); m; m = range.exec(text)) {\n      add(m[2] ?? "0", m[3] ?? "px", m[1] === "<=" || m[1] === ">");\n    }\n    const reversed = new RegExp(\n      `([\\\\d.]+)${QUERY_UNITS}\\\\s*(>=|>|<=|<)\\\\s*(?:width|inline-size)`,\n      "g"\n    );\n    for (let m = reversed.exec(text); m; m = reversed.exec(text)) {\n      add(m[1] ?? "0", m[2] ?? "px", m[3] === "<" || m[3] === ">=");\n    }\n    return out;\n  }\n  var queryCache = null;\n  function containerQueries() {\n    if (typeof CSSContainerRule === "undefined") return [];\n    const roots = [document, ...shadowRoots()];\n    const sheets = roots.flatMap((r) => [...r.styleSheets, ...r.adoptedStyleSheets ?? []]);\n    const key = sheets.map((s) => {\n      try {\n        return s.cssRules.length;\n      } catch {\n        return -1;\n      }\n    }).join(",");\n    if (queryCache?.key === key) return queryCache.queries;\n    const queries = [];\n    const seen = /* @__PURE__ */ new Set();\n    const walk = (rules) => {\n      for (const rule of rules) {\n        if (rule instanceof CSSContainerRule) {\n          for (const q of parseContainerCondition(rule.conditionText)) {\n            const id = `${q.name}|${q.value}${q.unit}|${q.after}`;\n            if (!seen.has(id)) {\n              seen.add(id);\n              queries.push(q);\n            }\n          }\n        }\n        if (rule instanceof CSSImportRule) {\n          try {\n            if (rule.styleSheet) walk(rule.styleSheet.cssRules);\n          } catch {\n          }\n        } else if ("cssRules" in rule && rule.cssRules) {\n          walk(rule.cssRules);\n        }\n      }\n    };\n    for (const sheet of sheets) {\n      try {\n        walk(sheet.cssRules);\n      } catch {\n      }\n    }\n    queryCache = { key, queries };\n    return queries;\n  }\n  var MAX_CONTAINER_BITS = 256;\n  function containerSignature(snap) {\n    const queries = containerQueries();\n    if (!queries.length) return void 0;\n    const rootFont = Number.parseFloat(getComputedStyle(document.documentElement).fontSize) || 16;\n    let bits = "";\n    for (const rec of snap.records) {\n      const s = rec.style;\n      if (!s.containerType || s.containerType === "normal") continue;\n      const names = s.containerName.split(/\\s+/);\n      const size = rec.rect.width - (Number.parseFloat(s.paddingLeft) || 0) - (Number.parseFloat(s.paddingRight) || 0) - (Number.parseFloat(s.borderLeftWidth) || 0) - (Number.parseFloat(s.borderRightWidth) || 0);\n      for (const q of queries) {\n        if (q.name && !names.includes(q.name)) continue;\n        const unit = q.unit === "px" ? 1 : q.unit === "em" ? Number.parseFloat(s.fontSize) || 16 : rootFont;\n        const threshold = q.value * unit;\n        bits += (q.after ? size > threshold : size >= threshold) ? "1" : "0";\n        if (bits.length >= MAX_CONTAINER_BITS) return bits;\n      }\n    }\n    return bits || void 0;\n  }\n  function declaredBreakpoints() {\n    const found = /* @__PURE__ */ new Set();\n    const toPx = (value, unit) => Number.parseFloat(value) * (unit === "px" ? 1 : MEDIA_EM);\n    const after = (w) => Math.floor(w) + 1;\n    const read = (text) => {\n      const legacy = /(min|max)-width\\s*:\\s*([\\d.]+)(px|em|rem)/g;\n      for (let m = legacy.exec(text); m; m = legacy.exec(text)) {\n        const [, kind, value = "0", unit = "px"] = m;\n        const w = toPx(value, unit);\n        found.add(Math.round(kind === "max" ? after(w) : w));\n      }\n      const range = /width\\s*(>=|>|<=|<)\\s*([\\d.]+)(px|em|rem)/g;\n      for (let m = range.exec(text); m; m = range.exec(text)) {\n        const [, op, value = "0", unit = "px"] = m;\n        const w = toPx(value, unit);\n        found.add(Math.round(op === "<=" || op === ">" ? after(w) : w));\n      }\n      const reversed = /([\\d.]+)(px|em|rem)\\s*(>=|>|<=|<)\\s*width/g;\n      for (let m = reversed.exec(text); m; m = reversed.exec(text)) {\n        const [, value = "0", unit = "px", op] = m;\n        const w = toPx(value, unit);\n        found.add(Math.round(op === "<" || op === ">=" ? after(w) : w));\n      }\n    };\n    const walk = (rules) => {\n      for (const rule of rules) {\n        if (typeof CSSContainerRule !== "undefined" && rule instanceof CSSContainerRule) {\n          continue;\n        }\n        if (rule instanceof CSSMediaRule) read(rule.conditionText ?? rule.media.mediaText);\n        else if (rule instanceof CSSImportRule) {\n          read(rule.media.mediaText);\n          readSheet(rule.styleSheet);\n          continue;\n        }\n        if ("cssRules" in rule && rule.cssRules)\n          walk(rule.cssRules);\n      }\n    };\n    const readSheet = (sheet) => {\n      if (!sheet) return;\n      read(sheet.media.mediaText);\n      try {\n        walk(sheet.cssRules);\n      } catch {\n      }\n    };\n    const roots = [document, ...shadowRoots()];\n    for (const root of roots) {\n      for (const sheet of root.styleSheets) readSheet(sheet);\n      for (const sheet of root.adoptedStyleSheets ?? []) readSheet(sheet);\n    }\n    return [...found].filter((w) => w > 0).sort((a, b) => a - b);\n  }\n\n  // ../analyzers/src/states.ts\n  var CANDIDATES = [\n    \'[role="tab"]\',\n    "[aria-expanded]",\n    "[aria-haspopup]",\n    "[popovertarget]",\n    "[commandfor]",\n    "[data-bs-toggle]",\n    "[data-toggle]",\n    "details > summary",\n    "button",\n    \'[role="button"]\'\n  ].join(",");\n  var MENU_CLASS = /(hamburger|burger|navbar-toggler|nav-?toggle|toggle-?nav|menu-?(toggle|button|btn|icon|trigger)|toggle-?menu|mobile-?(menu|nav)-?(toggle|button|btn|trigger)?|drawer-?toggle|sidebar-?toggle|offcanvas-?toggle)/i;\n  var MENU_LABEL = /^(?:(?:open|toggle|show)\\s+)?(?:the\\s+)?(?:(?:main|site|mobile|primary)\\s+)?(?:menu|navigation|nav|sidebar)(?:\\s+menu)?$|^[\u2630\u2261]$/i;\n  var MAX_TOGGLES = 40;\n  function nameOf(el) {\n    const aria = el.getAttribute("aria-label")?.trim();\n    if (aria) return aria;\n    const by = el.getAttribute("aria-labelledby");\n    if (by) {\n      const text2 = by.split(/\\s+/).map((id) => document.getElementById(id)?.textContent ?? "").join(" ").replace(/\\s+/g, " ").trim();\n      if (text2) return text2;\n    }\n    const text = (el.textContent ?? "").replace(/\\s+/g, " ").trim();\n    if (text) return text;\n    return el.getAttribute("title")?.trim() ?? "";\n  }\n  function shortLabel(el, kind) {\n    const name2 = nameOf(el);\n    if (!/[\\p{L}\\p{N}]/u.test(name2)) return kind;\n    return name2.length > 40 ? `${name2.slice(0, 37)}...` : name2;\n  }\n  function targetOf(el, attr) {\n    const id = el.getAttribute(attr);\n    if (!id) return null;\n    return el.getRootNode().getElementById?.(id) ?? null;\n  }\n  function bootstrapKind(value) {\n    switch (value) {\n      case "modal":\n        return "dialog";\n      case "offcanvas":\n      case "dropdown":\n        return "menu";\n      case "collapse":\n        return "disclosure";\n      default:\n        return null;\n    }\n  }\n  function looksLikeMenu(el) {\n    const names = [\n      typeof el.className === "string" ? el.className : "",\n      el.id,\n      el.getAttribute("data-testid") ?? ""\n    ].join(" ");\n    return MENU_CLASS.test(names) || MENU_LABEL.test(nameOf(el));\n  }\n  function kindOf(el) {\n    if (el.matches("details > summary")) {\n      const details = el.parentElement;\n      return details.open || details.querySelector(":scope > summary") !== el ? null : "details";\n    }\n    if (el.matches(\'input, select, textarea, [role="combobox"], [contenteditable]\')) return null;\n    if (el.getAttribute("role") === "tab")\n      return el.getAttribute("aria-selected") === "true" ? null : "tab";\n    if (el.hasAttribute("popovertarget")) {\n      return el.getAttribute("popovertargetaction") === "hide" ? null : "popover";\n    }\n    if (el.hasAttribute("commandfor")) {\n      const command = el.getAttribute("command");\n      if (command === "show-modal") return "dialog";\n      if (command === "toggle-popover" || command === "show-popover") return "popover";\n      return null;\n    }\n    const expanded = el.getAttribute("aria-expanded");\n    if (expanded === "true") return null;\n    const popup = el.getAttribute("aria-haspopup");\n    if (popup === "dialog") return "dialog";\n    if (popup && popup !== "false") return "menu";\n    const bootstrap = bootstrapKind(\n      el.getAttribute("data-bs-toggle") ?? el.getAttribute("data-toggle")\n    );\n    if (bootstrap) return bootstrap;\n    if (expanded === "false") return looksLikeMenu(el) ? "menu" : "disclosure";\n    if (el.matches(\'button, [role="button"]\') && looksLikeMenu(el)) return "menu";\n    return null;\n  }\n  function safeToClick(el) {\n    if (el.matches(\':disabled, [aria-disabled="true"]\')) return false;\n    if (el instanceof HTMLButtonElement && el.type === "submit" && el.form) return false;\n    const href = el instanceof HTMLAnchorElement ? el.getAttribute("href") : null;\n    return !href || href.startsWith("#") || /^javascript:/i.test(href);\n  }\n  function sidewaysScroller(el) {\n    for (let p = el.parentElement; p && p !== document.body; p = p.parentElement) {\n      const { overflowX } = getComputedStyle(p);\n      if ((overflowX === "auto" || overflowX === "scroll") && p.scrollWidth > p.clientWidth) return p;\n    }\n    return null;\n  }\n  function isShown(el, scrolls = false) {\n    const r = el.getBoundingClientRect();\n    if (r.width < 1 || r.height < 1) return false;\n    if ((r.right <= 0 || r.left >= window.innerWidth) && !(scrolls && sidewaysScroller(el)))\n      return false;\n    const check = el.checkVisibility;\n    if (check && !check.call(el, { opacityProperty: true, visibilityProperty: true })) return false;\n    if (!check && getComputedStyle(el).visibility === "hidden") return false;\n    return !el.closest(\'[aria-hidden="true"], [inert]\');\n  }\n  function ignored(el, rules) {\n    const marked = closestComposed(el, "[data-breakhound-ignore]");\n    if (marked) {\n      const scope = (marked.getAttribute("data-breakhound-ignore") ?? "").split(/[\\s,]+/);\n      if (scope.every((s) => !s) || scope.includes("all") || scope.includes("states")) return true;\n    }\n    return rules.some((rule) => {\n      if (rule.detectors) return false;\n      try {\n        return Boolean(closestComposed(el, rule.selector));\n      } catch {\n        return false;\n      }\n    });\n  }\n  function groupOf(el, kind) {\n    const shape = (e) => e ? `${e.tagName}.${[...e.classList].map((c) => c.replace(/\\d+/g, "")).sort().join(".")}` : "";\n    const panel = targetOf(el, "aria-controls");\n    return `${kind}|${shape(el)}|${shape(el.parentElement)}|${panel ? shape(panel) : ""}`;\n  }\n  var PRIORITY = {\n    menu: 0,\n    dialog: 0,\n    popover: 1,\n    tab: 1,\n    disclosure: 2,\n    details: 3\n  };\n  function findToggles(rules = []) {\n    const out = [];\n    const panels = /* @__PURE__ */ new Set();\n    for (const el of document.querySelectorAll(CANDIDATES)) {\n      if (out.length >= MAX_TOGGLES) break;\n      if (el.closest(DEV_OVERLAYS)) continue;\n      const kind = kindOf(el);\n      if (!kind || !safeToClick(el) || !isShown(el, kind === "tab") || ignored(el, rules)) continue;\n      const panel = targetOf(el, "aria-controls") ?? targetOf(el, "popovertarget");\n      if (panel) {\n        if (panels.has(panel)) continue;\n        panels.add(panel);\n      }\n      const inHeader = Boolean(el.closest(\'header, nav, [role="banner"], [role="navigation"]\'));\n      out.push({\n        selector: cachedSelector(el),\n        kind,\n        label: shortLabel(el, kind),\n        // Each tab shows different content, unlike the questions of an FAQ.\n        group: kind === "tab" ? `tab|${cachedSelector(el)}` : groupOf(el, kind),\n        priority: PRIORITY[kind] * 2 + (inHeader ? 0 : 1)\n      });\n    }\n    return out;\n  }\n  var toggles = /* @__PURE__ */ new Map();\n  function toggleOf(selector) {\n    const known = toggles.get(selector);\n    if (known?.isConnected) return known;\n    const el = resolveSelector(selector);\n    if (el) toggles.set(selector, el);\n    return el;\n  }\n  function toggleState(selector) {\n    const el = toggleOf(selector);\n    if (!el) return { shown: false, open: null };\n    const shown = isShown(el, el.getAttribute("role") === "tab");\n    if (el.matches("details > summary")) {\n      return { shown, open: el.parentElement.open };\n    }\n    if (el.getAttribute("role") === "tab")\n      return { shown, open: el.getAttribute("aria-selected") === "true" };\n    const expanded = el.getAttribute("aria-expanded");\n    if (expanded === "true" || expanded === "false") return { shown, open: expanded === "true" };\n    const target = targetOf(el, "popovertarget") ?? targetOf(el, "commandfor");\n    if (target instanceof HTMLDialogElement) return { shown, open: target.open };\n    if (target?.hasAttribute("popover")) {\n      try {\n        return { shown, open: target.matches(":popover-open") };\n      } catch {\n        return { shown, open: null };\n      }\n    }\n    return { shown, open: null };\n  }\n  function setDetails(selector, open) {\n    const details = toggleOf(selector)?.parentElement;\n    if (details instanceof HTMLDetailsElement) details.open = open;\n  }\n  function clickPoint(selector) {\n    const el = toggleOf(selector);\n    if (!el) return null;\n    let r = el.getBoundingClientRect();\n    if (r.top < 0 || r.bottom > window.innerHeight) {\n      el.scrollIntoView({ block: "center", inline: "nearest" });\n      r = el.getBoundingClientRect();\n    }\n    const row = r.left < 0 || r.right > window.innerWidth ? sidewaysScroller(el) : null;\n    if (row) {\n      const box = row.getBoundingClientRect();\n      row.scrollLeft += r.left + r.width / 2 - (box.left + box.width / 2);\n      r = el.getBoundingClientRect();\n    }\n    const x = Math.min(window.innerWidth - 1, Math.max(0, r.left + r.width / 2));\n    const y = Math.min(window.innerHeight - 1, Math.max(0, r.top + r.height / 2));\n    let hit = document.elementFromPoint(x, y);\n    while (hit?.shadowRoot) {\n      const inner = hit.shadowRoot.elementFromPoint(x, y);\n      if (!inner || inner === hit) break;\n      hit = inner;\n    }\n    if (!hit) return null;\n    return hit === el || el.contains(hit) || el.getRootNode() !== document && hit.contains(el) ? { x, y } : null;\n  }\n  var before = null;\n  function markShown() {\n    before = new WeakSet([document.body]);\n    for (const el of document.body.querySelectorAll("*")) if (isShown(el)) before.add(el);\n  }\n  function newlyShown(toggle) {\n    const seen = before;\n    before = null;\n    if (!seen) return null;\n    const trigger = toggleOf(toggle);\n    let best = null;\n    for (const el of document.body.querySelectorAll("*")) {\n      if (seen.has(el) || trigger && (trigger === el || trigger.contains(el))) continue;\n      if (el.parentElement && !seen.has(el.parentElement) && isShown(el.parentElement)) continue;\n      if (!isShown(el)) continue;\n      const r = el.getBoundingClientRect();\n      const area = r.width * r.height;\n      if (!best || area > best.area) best = { el, area };\n    }\n    return best && best.area >= 2e3 ? cachedSelector(best.el) : null;\n  }\n  function selectorShown(selector) {\n    const el = resolveSelector(selector);\n    return el ? isShown(el) : false;\n  }\n\n  // ../analyzers/src/types.ts\n  var DETECTOR_IDS = [\n    "page-overflow",\n    "content-overflow",\n    "media-overflow",\n    "overlap",\n    "unexpected-wrap",\n    "clipped-text",\n    "squished-text",\n    "distorted-media",\n    "small-tap-target",\n    "tiny-text",\n    "oversized-text",\n    "edge-gutter",\n    "viewport-meta"\n  ];\n\n  // ../analyzers/src/highlight.ts\n  var OVERLAY_ATTR = "data-breakhound-overlay";\n  function find(selector) {\n    return selector ? resolveSelector(selector) : null;\n  }\n  function overlay(style) {\n    const div = document.createElement("div");\n    div.setAttribute(OVERLAY_ATTR, "");\n    Object.assign(div.style, {\n      position: "absolute",\n      zIndex: "2147483647",\n      pointerEvents: "none",\n      ...style\n    });\n    document.documentElement.appendChild(div);\n  }\n  function highlight(opts) {\n    const target = find(opts.selector);\n    if (!target) return null;\n    const boxes = [{ el: target, color: "#e11d48" }];\n    const other = find(opts.related);\n    if (other && other !== target) boxes.push({ el: other, color: "#f59e0b" });\n    const sx = window.scrollX;\n    const sy = window.scrollY;\n    const vw = document.documentElement.clientWidth;\n    let top = Number.POSITIVE_INFINITY;\n    let bottom = Number.NEGATIVE_INFINITY;\n    let right = vw;\n    for (const { el, color } of boxes) {\n      const r = el.getBoundingClientRect();\n      if (r.width === 0 && r.height === 0) continue;\n      top = Math.min(top, r.top + sy);\n      bottom = Math.max(bottom, r.bottom + sy);\n      right = Math.max(right, r.right + sx);\n      overlay({\n        left: `${r.left + sx - 2}px`,\n        top: `${r.top + sy - 2}px`,\n        width: `${r.width + 4}px`,\n        height: `${r.height + 4}px`,\n        outline: `3px solid ${color}`,\n        background: `${color}14`\n      });\n    }\n    if (!Number.isFinite(top)) return null;\n    const docHeight = document.documentElement.scrollHeight;\n    const y = Math.max(0, top - opts.pad);\n    const end = Math.min(docHeight, bottom + opts.pad, y + opts.maxHeight);\n    if (opts.showEdge) {\n      overlay({\n        left: `${vw - 1}px`,\n        top: `${y}px`,\n        width: "0",\n        height: `${end - y}px`,\n        borderLeft: "2px dashed #2563eb"\n      });\n    }\n    const scrollWidth = document.documentElement.scrollWidth;\n    return {\n      x: 0,\n      y,\n      width: Math.min(Math.max(vw, Math.ceil(right) + 16), Math.max(vw, scrollWidth)),\n      height: Math.max(1, end - y)\n    };\n  }\n  function clearHighlights() {\n    for (const el of document.querySelectorAll(`[${OVERLAY_ATTR}]`)) el.remove();\n  }\n\n  // ../analyzers/src/settle.ts\n  var frame = () => new Promise((resolve) => requestAnimationFrame(() => resolve()));\n  async function settleAfterResize(maxWaitMs) {\n    await frame();\n    await frame();\n    const probe = window.__breakhound_settle;\n    if (probe && probe.pending() > 0) {\n      const deadline = performance.now() + maxWaitMs;\n      while (probe.pending() > 0 && performance.now() < deadline) {\n        await new Promise((resolve) => setTimeout(resolve, 10));\n      }\n      await frame();\n      await frame();\n    }\n    window.scrollTo(0, 0);\n  }\n\n  // ../analyzers/src/index.ts\n  var DETECTORS = {\n    "page-overflow": pageOverflow,\n    "media-overflow": mediaOverflow,\n    "content-overflow": contentOverflow,\n    overlap,\n    "clipped-text": clippedText,\n    "squished-text": squishedText,\n    "distorted-media": distortedMedia,\n    "small-tap-target": smallTapTargets,\n    "tiny-text": tinyText,\n    "oversized-text": oversizedText,\n    "edge-gutter": edgeGutter,\n    "viewport-meta": viewportMeta\n  };\n  var IGNORE_ATTR = "data-breakhound-ignore";\n  function parseDetectors(value) {\n    const list = (value ?? "").split(/[\\s,]+/).filter(Boolean);\n    return list.length === 0 || list.includes("all") ? "all" : new Set(list);\n  }\n  function isIgnored(info, detector, rules) {\n    if (!info) return false;\n    const el = elementOf(info);\n    if (!el) return false;\n    for (let p = el; p; p = composedParent(p)) {\n      if (!p.hasAttribute(IGNORE_ATTR)) continue;\n      const scope = parseDetectors(p.getAttribute(IGNORE_ATTR));\n      if (scope === "all" || scope.has(detector)) return true;\n    }\n    for (const rule of rules) {\n      if (rule.detectors && !rule.detectors.includes(detector)) continue;\n      try {\n        if (closestComposed(el, rule.selector)) return true;\n      } catch {\n      }\n    }\n    return false;\n  }\n  function analyze(options = {}) {\n    const enabled = new Set(options.detectors ?? DETECTOR_IDS);\n    const rules = options.ignore ?? [];\n    const snap = snapshot();\n    const findings = [];\n    for (const [id, run] of Object.entries(DETECTORS)) {\n      if (!enabled.has(id)) continue;\n      for (const f of run(snap)) {\n        if (isIgnored(f.element, id, rules) || isIgnored(f.related, id, rules)) continue;\n        findings.push(f);\n      }\n    }\n    const wraps = enabled.has("unexpected-wrap") ? wrapStats(snap).filter((w) => !isIgnored(w.element, "unexpected-wrap", rules)) : [];\n    const containers = containerSignature(snap);\n    return {\n      width: snap.viewportWidth,\n      findings,\n      wraps,\n      signature: layoutSignature(snap, cachedSelector),\n      ...containers ? { containers } : {},\n      ...options.toggles ? { toggles: findToggles(rules) } : {}\n    };\n  }\n  var MEDIA_CONTENT = /* @__PURE__ */ new Set([\n    "IMG",\n    "SVG",\n    "svg",\n    "CANVAS",\n    "VIDEO",\n    "IFRAME",\n    "OBJECT",\n    "EMBED"\n  ]);\n  function hasContent() {\n    const visit = (el) => {\n      if (el.matches(DEV_OVERLAYS)) return false;\n      if (MEDIA_CONTENT.has(el.tagName)) {\n        const r = el.getBoundingClientRect();\n        return r.width > 0 && r.height > 0;\n      }\n      for (const node of el.childNodes) {\n        if (node.nodeType === Node.TEXT_NODE && node.textContent?.trim()) {\n          const range = document.createRange();\n          range.selectNodeContents(node);\n          if (range.getClientRects().length > 0) return true;\n        }\n      }\n      return renderedChildren(el).some(visit);\n    };\n    return document.body ? visit(document.body) : false;\n  }\n\n  // ../analyzers/src/inject.ts\n  var api = {\n    analyze,\n    declaredBreakpoints,\n    settleAfterResize,\n    highlight,\n    clearHighlights,\n    hasContent,\n    resolveSelector,\n    toggleState,\n    setDetails,\n    clickPoint,\n    markShown,\n    newlyShown,\n    selectorShown,\n    findByText\n  };\n  window.__breakhound = api;\n})();\n',
      minWidth: range.min,
      maxWidth: range.max,
      onProgress: ({ width, measured }) => {
        state.scanAt = width;
        state.measured = measured;
        scheduleLive();
      },
      onMeasure: (width, r) => {
        state.live.set(width, { layout: r.signature, worst: worstOf(r) });
      },
      cancelled: () => state.stopping
    };
    const onPage = ({ index, planned, route }) => {
      state.scanning = { index, planned, route };
      state.live = /* @__PURE__ */ new Map();
      state.scanAt = range.min;
      state.measured = 0;
      renderPages();
      scheduleLive();
    };
    const onResult = (route) => {
      pages.push({ route, live: state.live });
      renderPages();
    };
    let finished = false;
    try {
      await session.attach();
      if (check) {
        const { server, check: c } = check;
        await scanPages(session, c.pages, {
          ...common,
          onPage: (p) => {
            onPage(p);
            checkProgress(server, c.id, p.index, `Checking ${p.route} in the browser`);
          },
          onResult
        });
        finished = true;
      } else if (site) {
        const done = await scanSite(session, {
          ...common,
          maxPages: SITE_MAX_PAGES,
          onPage,
          onResult
        });
        state.from = done.from;
        finished = true;
      } else {
        const route = await scanTab(session, { ...common, reload: ui.reload.checked });
        pages.push({ route, live: state.live });
        finished = true;
        if (route.status !== "scanned") notify(route.error ?? "The page could not be scanned.");
      }
    } catch (error) {
      if (error instanceof Cancelled) {
        if (site && pages.length) {
          finished = true;
          notify(`Stopped after ${pages.length} ${pages.length === 1 ? "page" : "pages"}.`, "note");
        }
      } else {
        const message = error instanceof Error ? error.message : String(error);
        failure = message;
        notify(
          /detached|target closed|No tab with given id/i.test(message) ? "The scan stopped because the debugging bar was closed or the tab went away." : `The scan failed: ${message}`
        );
      }
    } finally {
      clearInterval(tick);
      await session.detach();
      navigatedAt = Date.now();
      if (finished && pages.length) {
        state.startedAt = startedAt;
        showPage(firstWorthSeeing(pages));
        if (site && !pages.some((p) => p.route.status === "scanned")) {
          notify("None of the pages could be scanned.");
        }
      } else {
        Object.assign(state, previous);
      }
      state.phase = state.pages.length ? "done" : "idle";
      state.scanning = null;
      state.scanAt = null;
      state.paused = false;
      state.checking = false;
      render();
    }
    return finished ? { routes: pages.map((p) => p.route) } : { error: failure };
  }
  var pending = null;
  var pumping = false;
  var measureAgain = false;
  var navigatedAt = 0;
  var navigating = false;
  var pause3 = (ms) => new Promise((r) => setTimeout(r, ms));
  function view(width, opts = {}) {
    const w = Math.max(state.range.min, Math.min(state.range.max, Math.round(width)));
    state.viewing = w;
    pending = {
      width: w,
      settle: opts.settle ?? true,
      focus: opts.focus ?? null,
      scroll: !!opts.scroll
    };
    renderPlayhead();
    renderViewing();
    if (!pumping) void pump();
  }
  async function pump() {
    pumping = true;
    try {
      while (pending) {
        const job = pending;
        pending = null;
        if (!session.isAttached || measureAgain) {
          if (session.isAttached) {
            await session.send("Emulation.clearDeviceMetricsOverride");
          } else {
            await session.attach();
            await pause3(200);
          }
          measureAgain = false;
          state.natural = await evaluate(session, () => ({
            width: window.innerWidth,
            height: window.innerHeight
          }));
          renderViewing();
        }
        const target = state.result?.finalUrl;
        if (target && state.result?.status === "scanned") {
          const here = await evaluate(session, () => location.href);
          if (here !== target) {
            navigating = true;
            try {
              await loadPage(session, target);
            } finally {
              navigating = false;
              navigatedAt = Date.now();
            }
          }
        }
        await setWidth(session, job.width, 0, state.natural ?? void 0);
        if (job.settle && !pending) await settle(job);
      }
    } catch (error) {
      pending = null;
      notify(error instanceof Error ? error.message : String(error));
      await session.detach();
      state.viewing = null;
      renderPlayhead();
      renderViewing();
    } finally {
      pumping = false;
    }
  }
  async function settle(job) {
    const present = await evaluate(session, () => !!window.__breakhound);
    if (!present) await evaluate(session, '"use strict";\n(() => {\n  // ../analyzers/src/dom.ts\n  var UNCLIPPED = {\n    left: -Infinity,\n    right: Infinity,\n    top: -Infinity,\n    bottom: Infinity,\n    width: Infinity,\n    height: Infinity\n  };\n  function intersectBox(a, b) {\n    const left = Math.max(a.left, b.left);\n    const right = Math.min(a.right, b.right);\n    const top = Math.max(a.top, b.top);\n    const bottom = Math.min(a.bottom, b.bottom);\n    if (right <= left || bottom <= top) return null;\n    return { left, right, top, bottom, width: right - left, height: bottom - top };\n  }\n  function clipFor(rect, style, outer) {\n    const x = style.overflowX !== "visible";\n    const y = style.overflowY !== "visible";\n    if (!x && !y) return outer;\n    const own = {\n      left: x ? rect.left : -Infinity,\n      right: x ? rect.right : Infinity,\n      top: y ? rect.top : -Infinity,\n      bottom: y ? rect.bottom : Infinity,\n      width: x ? rect.width : Infinity,\n      height: y ? rect.height : Infinity\n    };\n    return intersectBox(own, outer) ?? { ...rect, right: rect.left, width: 0 };\n  }\n  var SKIP_TAGS = /* @__PURE__ */ new Set([\n    "SCRIPT",\n    "STYLE",\n    "TEMPLATE",\n    "NOSCRIPT",\n    "LINK",\n    "META",\n    "HEAD",\n    "TITLE",\n    "BR",\n    "WBR",\n    "SOURCE",\n    "TRACK",\n    "OPTION",\n    "OPTGROUP",\n    "DATALIST"\n  ]);\n  var DEV_OVERLAYS = [\n    "nextjs-portal",\n    "[data-nextjs-toast]",\n    "[data-nextjs-dev-tools-button]",\n    "#__next-build-watcher",\n    "#__next-prerender-indicator",\n    "#nuxt-devtools-container",\n    "#vue-inspector-container",\n    "#__vue-devtools-container__",\n    "vite-error-overlay",\n    "vite-plugin-checker-error-overlay",\n    "astro-dev-toolbar",\n    "astro-dev-overlay",\n    "#webpack-dev-server-client-overlay",\n    "#react-refresh-overlay",\n    ".tsqd-parent-container",\n    ".TanStackRouterDevtools",\n    "#svelte-inspector-host",\n    "vercel-live-feedback"\n  ].join(",");\n  var LEAF_TAGS = /* @__PURE__ */ new Set([\n    "svg",\n    "SVG",\n    "MATH",\n    "math",\n    "SELECT",\n    "TEXTAREA",\n    "IFRAME",\n    "VIDEO",\n    "CANVAS"\n  ]);\n  function renderedChildren(el) {\n    if (el.shadowRoot) return Array.from(el.shadowRoot.children);\n    if (el instanceof HTMLSlotElement) {\n      const assigned = el.assignedElements({ flatten: true });\n      if (assigned.length) return assigned;\n    }\n    return Array.from(el.children);\n  }\n  function composedParent(el) {\n    if (el.assignedSlot) return el.assignedSlot;\n    if (el.parentElement) return el.parentElement;\n    const root = el.parentNode;\n    return root instanceof ShadowRoot ? root.host : null;\n  }\n  function closestComposed(el, selector) {\n    for (let p = el; p; p = composedParent(p)) {\n      if (p.matches(selector)) return p;\n    }\n    return null;\n  }\n  function shadowRoots() {\n    const out = [];\n    const walk = (root) => {\n      for (const el of root.querySelectorAll("*")) {\n        if (el.shadowRoot) {\n          out.push(el.shadowRoot);\n          walk(el.shadowRoot);\n        }\n      }\n    };\n    walk(document);\n    return out;\n  }\n  function toBox(r) {\n    return {\n      left: r.left + window.scrollX,\n      right: r.right + window.scrollX,\n      top: r.top + window.scrollY,\n      bottom: r.bottom + window.scrollY,\n      width: r.width,\n      height: r.height\n    };\n  }\n  function clipsX(style) {\n    return style.overflowX !== "visible";\n  }\n  function isRendered(el, style) {\n    if (style.display === "none" || style.visibility === "hidden" || style.visibility === "collapse") {\n      return false;\n    }\n    if (typeof el.checkVisibility === "function") {\n      return el.checkVisibility({ opacityProperty: true, visibilityProperty: true });\n    }\n    return Number.parseFloat(style.opacity) > 0;\n  }\n  function isVisuallyHidden(rec) {\n    const { style, rect } = rec;\n    if (rect.width <= 1 || rect.height <= 1) {\n      if (style.overflow !== "visible" || style.position === "absolute") return true;\n    }\n    if (style.clip && style.clip !== "auto" && /rect\\(\\s*0/.test(style.clip)) return true;\n    if (style.clipPath && /inset\\(\\s*50%/.test(style.clipPath)) return true;\n    return false;\n  }\n  var ORNAMENT_OPACITY = 0.3;\n  function isOrnament(rec) {\n    if (rec.el.closest(\'[aria-hidden="true"]\')) return true;\n    let opacity = 1;\n    for (let p = rec; p; p = p.parent) {\n      opacity *= Number.parseFloat(p.style.opacity) || 0;\n      if (opacity < ORNAMENT_OPACITY) return true;\n    }\n    return false;\n  }\n  var BREAKS_ANYWHERE = /[\\u0e00-\\u0eff\\u1000-\\u109f\\u1780-\\u17ff\\u3040-\\u30ff\\u3400-\\u4dbf\\u4e00-\\u9fff\\uac00-\\ud7af\\uf900-\\ufaff]/g;\n  function breaksAnywhere(text) {\n    const chars = text.replace(/\\s/g, "").length;\n    return chars > 0 && (text.match(BREAKS_ANYWHERE)?.length ?? 0) * 2 >= chars;\n  }\n  var MAX_FRAGMENTS = 64;\n  function measureOwnText(el) {\n    let left = Infinity;\n    let right = -Infinity;\n    let top = Infinity;\n    let bottom = -Infinity;\n    const lineTops = [];\n    const pieces = [];\n    const range = document.createRange();\n    let text = "";\n    for (const node of el.childNodes) {\n      if (node.nodeType !== Node.TEXT_NODE || !node.textContent?.trim()) continue;\n      text += ` ${node.textContent}`;\n      range.selectNodeContents(node);\n      for (const r of range.getClientRects()) {\n        if (r.width === 0 || r.height === 0) continue;\n        left = Math.min(left, r.left);\n        right = Math.max(right, r.right);\n        top = Math.min(top, r.top);\n        bottom = Math.max(bottom, r.bottom);\n        pieces.push(r);\n        if (!lineTops.some((t) => Math.abs(t - r.top) < r.height / 2)) lineTops.push(r.top);\n      }\n    }\n    text = text.replace(/\\s+/g, " ").trim();\n    if (left === Infinity) return { rect: null, fragments: [], lines: 0, text };\n    const sx = window.scrollX;\n    const sy = window.scrollY;\n    const fragments = pieces.length <= MAX_FRAGMENTS ? pieces.map((r) => ({\n      left: r.left + sx,\n      right: r.right + sx,\n      top: r.top + sy,\n      bottom: r.bottom + sy,\n      width: r.width,\n      height: r.height\n    })) : [];\n    return {\n      fragments,\n      rect: {\n        left: left + sx,\n        right: right + sx,\n        top: top + sy,\n        bottom: bottom + sy,\n        width: right - left,\n        height: bottom - top\n      },\n      lines: lineTops.length,\n      text\n    };\n  }\n  function snapshot() {\n    const html = document.documentElement;\n    const body = document.body;\n    const htmlStyle = getComputedStyle(html);\n    const bodyStyle = body ? getComputedStyle(body) : htmlStyle;\n    const viewportWidth = html.clientWidth;\n    const scrollWidth = Math.max(html.scrollWidth, body?.scrollWidth ?? 0);\n    const rootClipsX = clipsX(htmlStyle) || clipsX(bodyStyle);\n    const records = [];\n    const byElement = /* @__PURE__ */ new Map();\n    const visit = (el, parent, depth) => {\n      if (SKIP_TAGS.has(el.tagName) || el.matches(DEV_OVERLAYS)) return;\n      const style = getComputedStyle(el);\n      if (!isRendered(el, style)) return;\n      if (style.display === "contents") {\n        for (const child of renderedChildren(el)) visit(child, parent, depth);\n        return;\n      }\n      const own = LEAF_TAGS.has(el.tagName) ? { rect: null, fragments: [], lines: 0, text: "" } : measureOwnText(el);\n      let outOfFlow = parent?.outOfFlow ?? null;\n      if (style.position === "fixed") outOfFlow = "fixed";\n      else if (style.position === "absolute" && outOfFlow !== "fixed") outOfFlow = "absolute";\n      const positioned = style.position === "fixed" || style.position === "absolute";\n      const rect = toBox(el.getBoundingClientRect());\n      const clip = style.position === "fixed" ? UNCLIPPED : parent?.innerClip ?? UNCLIPPED;\n      const innerClip = el === document.body || el === html ? clip : clipFor(rect, style, clip);\n      const rec = {\n        el,\n        parent,\n        style,\n        rect,\n        // Text hidden by the element\'s own overflow (ellipsis, line-clamp) is not painted.\n        textRect: own.rect && style.overflowX === "visible" && style.overflowY === "visible" ? own.rect : own.rect && intersectBox(own.rect, innerClip),\n        textFragments: own.fragments,\n        rawTextRect: own.rect,\n        text: own.text,\n        textLines: own.lines,\n        clipAncestor: parent && parent.el !== body && parent.el !== html && clipsX(parent.style) ? parent : parent?.clipAncestor ?? null,\n        outOfFlow,\n        oofRoot: null,\n        clip,\n        innerClip,\n        depth\n      };\n      rec.oofRoot = positioned ? rec : parent?.oofRoot ?? null;\n      records.push(rec);\n      byElement.set(el, rec);\n      if (LEAF_TAGS.has(el.tagName)) return;\n      for (const child of renderedChildren(el)) visit(child, rec, depth + 1);\n    };\n    if (body) {\n      for (const child of renderedChildren(body)) visit(child, null, 1);\n    }\n    return {\n      viewportWidth,\n      viewportHeight: html.clientHeight,\n      rootClipsX,\n      rootScrollsX: !rootClipsX && scrollWidth > viewportWidth,\n      rtl: bodyStyle.direction === "rtl",\n      scrollWidth,\n      records,\n      byElement\n    };\n  }\n  function isDeliberateOffset(rec) {\n    const s = rec.style;\n    if ((Number.parseFloat(s.marginLeft) || 0) < 0) return true;\n    if ((Number.parseFloat(s.marginRight) || 0) < 0) return true;\n    if ((Number.parseFloat(s.marginTop) || 0) < 0) return true;\n    if ((Number.parseFloat(s.marginBottom) || 0) < 0) return true;\n    if (s.transform && s.transform !== "none") return true;\n    if (s.position === "relative" && (s.top !== "auto" && s.top !== "0px" || s.left !== "auto" && s.left !== "0px")) {\n      return true;\n    }\n    return false;\n  }\n  function contentBox(rec) {\n    const s = rec.style;\n    const bl = Number.parseFloat(s.borderLeftWidth) || 0;\n    const br = Number.parseFloat(s.borderRightWidth) || 0;\n    const pl = Number.parseFloat(s.paddingLeft) || 0;\n    const pr = Number.parseFloat(s.paddingRight) || 0;\n    const left = rec.rect.left + bl + pl;\n    const right = rec.rect.right - br - pr;\n    return { ...rec.rect, left, right, width: right - left };\n  }\n  function paintedRight(rec) {\n    return Math.max(rec.rect.right, rec.textRect?.right ?? -Infinity);\n  }\n  function paintedLeft(rec) {\n    return Math.min(rec.rect.left, rec.textRect?.left ?? Infinity);\n  }\n  function isInline(style) {\n    return style.display === "inline";\n  }\n  function fontSize(rec) {\n    return Number.parseFloat(rec.style.fontSize) || 16;\n  }\n  var TOUCH_MAX_WIDTH = 767;\n  function px(n) {\n    return Math.round(n);\n  }\n\n  // ../analyzers/src/source.ts\n  var SOURCE_ATTR = "data-bh-src";\n  function fromAttribute(value, exact) {\n    const m = value.match(/^(.+?)(?::(\\d+))?(?::(\\d+))?$/);\n    if (!m?.[1]) return null;\n    return {\n      file: m[1],\n      ...m[2] ? { line: Number(m[2]) } : {},\n      ...m[3] ? { column: Number(m[3]) } : {},\n      exact\n    };\n  }\n  var NOT_APP_CODE = /node_modules|\\/\\.vite\\/deps\\/|\\/@vite\\/|\\/@react-refresh|\\/_next\\/static\\/chunks\\/|react-dom|jsx-dev-runtime|react-stack/;\n  function fileFromStack(stack) {\n    for (const line of stack.split("\\n")) {\n      const m = line.match(/((?:https?|file):\\/\\/[^\\s)]+|webpack-internal:\\/\\/\\/[^\\s)]+):\\d+:\\d+/);\n      const url = m?.[1];\n      if (!url || NOT_APP_CODE.test(url)) continue;\n      if (url.startsWith("webpack-internal:")) {\n        const path = url.match(/\\/\\.\\/(.+)$/)?.[1];\n        if (path) return path.split("?")[0] ?? null;\n        continue;\n      }\n      try {\n        const u = new URL(url);\n        return u.protocol === "file:" ? decodeURIComponent(u.pathname) : u.pathname;\n      } catch {\n      }\n    }\n    return null;\n  }\n  function componentName(type) {\n    if (!type) return void 0;\n    if (typeof type === "function") return type.displayName || type.name || void 0;\n    return type.displayName || componentName(type.type) || componentName(type.render);\n  }\n  function reactSource(el) {\n    const key = Object.keys(el).find((k) => k.startsWith("__reactFiber$"));\n    const fiber = key ? el[key] : null;\n    if (!fiber) return null;\n    const owner = fiber._debugOwner;\n    const component = componentName(owner?.type);\n    const debug = fiber._debugSource;\n    if (debug?.fileName && !NOT_APP_CODE.test(debug.fileName)) {\n      return {\n        file: debug.fileName,\n        ...debug.lineNumber ? { line: debug.lineNumber } : {},\n        ...debug.columnNumber ? { column: debug.columnNumber } : {},\n        ...component ? { component } : {},\n        exact: true\n      };\n    }\n    const stack = fiber._debugStack;\n    const text = typeof stack === "string" ? stack : stack?.stack;\n    const file = typeof text === "string" ? fileFromStack(text) : null;\n    return file ? { file, ...component ? { component } : {}, exact: false } : null;\n  }\n  function vueSource(el) {\n    for (let instance = el.__vueParentComponent; instance; instance = instance.parent) {\n      const file = instance.type?.__file;\n      if (typeof file === "string" && !NOT_APP_CODE.test(file)) {\n        const component = instance.type.__name || instance.type.name;\n        return { file, ...component ? { component } : {}, exact: false };\n      }\n    }\n    return null;\n  }\n  function sourceOf(el) {\n    try {\n      const own = el.getAttribute(SOURCE_ATTR);\n      if (own) return fromAttribute(own, true);\n      const found = reactSource(el) ?? vueSource(el);\n      if (found) return found;\n      const above = el.parentElement?.closest(`[${SOURCE_ATTR}]`);\n      const value = above?.getAttribute(SOURCE_ATTR);\n      return value ? fromAttribute(value, false) : null;\n    } catch {\n      return null;\n    }\n  }\n\n  // ../analyzers/src/selector.ts\n  var cache = /* @__PURE__ */ new WeakMap();\n  var owners = /* @__PURE__ */ new WeakMap();\n  function elementOf(info) {\n    return owners.get(info);\n  }\n  function isStableId(id) {\n    if (!id || /[:\xAB\xBB]/.test(id)) return false;\n    if (/^(radix|headlessui|react-aria|mui|chakra|ember)[-_]/i.test(id)) return false;\n    if (/\\d{3,}/.test(id)) return false;\n    return /^[A-Za-z][\\w-]*$/.test(id);\n  }\n  function usefulClasses(el) {\n    const out = [];\n    for (const c of el.classList) {\n      if (/[:[\\]/!@.%#()]/.test(c)) continue;\n      if (/^(css|sc|jsx|emotion|svelte|astro|styled)-[\\w-]*\\d/i.test(c)) continue;\n      if (/^_?[a-zA-Z]+_[a-zA-Z0-9]+__[\\w-]{4,}$/.test(c)) continue;\n      if (/^[a-z]{1,3}[A-Z0-9]\\w{4,}$/.test(c) && /\\d/.test(c)) continue;\n      out.push(c);\n    }\n    return out.sort((a, b) => score(b) - score(a)).slice(0, 2);\n  }\n  function score(c) {\n    let s = c.length;\n    if (/^(flex|grid|block|inline|hidden|p[trblxy]?-|m[trblxy]?-|w-|h-|text-|bg-|gap-)/.test(c))\n      s -= 20;\n    return s;\n  }\n  function cssEscape(s) {\n    return CSS.escape(s);\n  }\n  function segment(el, withClasses, withNth) {\n    let s = el.tagName.toLowerCase();\n    if (withClasses)\n      s += usefulClasses(el).map((c) => `.${cssEscape(c)}`).join("");\n    if (withNth) {\n      const siblings = el.parentElement?.children ?? el.parentNode?.children;\n      const same = Array.from(siblings ?? []).filter((c) => c.tagName === el.tagName);\n      if (same.length > 1) s += `:nth-of-type(${same.indexOf(el) + 1})`;\n    }\n    return s;\n  }\n  function isUnique(selector, el, root) {\n    try {\n      const found = root.querySelectorAll(selector);\n      return found.length === 1 && found[0] === el;\n    } catch {\n      return false;\n    }\n  }\n  var SHADOW_SEPARATOR = " >>> ";\n  function selectorWithin(el, root) {\n    if (el.id && isStableId(el.id) && isUnique(`#${cssEscape(el.id)}`, el, root))\n      return `#${cssEscape(el.id)}`;\n    const parts = [];\n    let current = el;\n    while (current && current !== document.documentElement) {\n      if (current !== el && current.id && isStableId(current.id)) {\n        parts.unshift(`#${cssEscape(current.id)}`);\n        const candidate = parts.join(" > ");\n        if (isUnique(candidate, el, root)) return candidate;\n        parts.shift();\n      }\n      for (const [cls, nth] of [\n        [true, false],\n        [true, true]\n      ]) {\n        const candidate = [segment(current, cls, nth), ...parts].join(" > ");\n        if (isUnique(candidate, el, root)) return candidate;\n      }\n      parts.unshift(segment(current, true, true));\n      current = current.parentElement;\n    }\n    return parts.join(" > ");\n  }\n  function selectorFor(el) {\n    const root = el.getRootNode();\n    if (root instanceof ShadowRoot) {\n      return `${selectorFor(root.host)}${SHADOW_SEPARATOR}${selectorWithin(el, root)}`;\n    }\n    return selectorWithin(el, document);\n  }\n  var selectors = /* @__PURE__ */ new WeakMap();\n  function cachedSelector(el) {\n    let s = selectors.get(el);\n    if (s === void 0) {\n      s = selectorFor(el);\n      selectors.set(el, s);\n    }\n    return s;\n  }\n  function lineage(el, max = 16) {\n    const out = [];\n    for (let p = composedParent(el); p && p !== document.body && out.length < max; p = composedParent(p)) {\n      out.push(cachedSelector(p));\n    }\n    return out;\n  }\n  function resolveSelector(selector) {\n    let root = document;\n    let found = null;\n    for (const part of selector.split(SHADOW_SEPARATOR)) {\n      if (!root) return null;\n      try {\n        found = root.querySelector(part);\n      } catch {\n        return null;\n      }\n      root = found?.shadowRoot ?? null;\n    }\n    return found;\n  }\n  function readablePath(el) {\n    const parts = [];\n    let current = el;\n    while (current && current !== document.body && parts.length < 4) {\n      const cls = usefulClasses(current)[0];\n      parts.unshift(current.tagName.toLowerCase() + (cls ? `.${cls}` : ""));\n      current = composedParent(current);\n    }\n    return parts.join(" > ");\n  }\n  function openingTag(el) {\n    const tag = el.tagName.toLowerCase();\n    let out = `<${tag}`;\n    for (const attr of el.attributes) {\n      if (attr.name === SOURCE_ATTR) continue;\n      const value = attr.value.length > 60 ? `${attr.value.slice(0, 60)}...` : attr.value;\n      out += value ? ` ${attr.name}="${value.replace(/"/g, "&quot;")}"` : ` ${attr.name}`;\n    }\n    out += ">";\n    return out.length > 200 ? `${out.slice(0, 197)}...>` : out;\n  }\n  function findByText(wanted) {\n    const needle = wanted.replace(/\\s+/g, " ").trim().toLowerCase();\n    if (needle.length < 3 || !document.body) return null;\n    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);\n    for (let node = walker.nextNode(); node; node = walker.nextNode()) {\n      const el = node.parentElement;\n      if (!el || el.closest("script, style, noscript")) continue;\n      const r = el.getBoundingClientRect();\n      if (r.width < 1 || r.height < 1) continue;\n      for (let p = el; p && p !== document.body; p = p.parentElement) {\n        const text = (p.textContent ?? "").replace(/\\s+/g, " ").toLowerCase();\n        if (text.includes(needle)) return describe(p);\n        if (text.length > needle.length * 4) break;\n      }\n    }\n    return null;\n  }\n  function describe(el) {\n    const cached = cache.get(el);\n    if (cached) return cached;\n    const text = (el.textContent ?? "").replace(/\\s+/g, " ").trim();\n    const info = {\n      selector: cachedSelector(el),\n      path: readablePath(el),\n      html: openingTag(el),\n      text: text ? text.length > 80 ? `${text.slice(0, 77)}...` : text : null,\n      source: sourceOf(el)\n    };\n    cache.set(el, info);\n    owners.set(info, el);\n    return info;\n  }\n\n  // ../analyzers/src/detectors/page-overflow.ts\n  var TOLERANCE = 0.5;\n  var SIDEWAYS_CONTENT = /* @__PURE__ */ new Set(["TABLE", "PRE", "CODE"]);\n  var PAGE_CONTENT = "h1,h2,h3,h4,form,input,textarea,select,main,article";\n  function wrapperEdge(snap, rec) {\n    const container = rec.clipAncestor;\n    if (!container) return { kind: "root" };\n    const vw = snap.viewportWidth;\n    if (container.rect.left > 1 || container.rect.right < vw - 1) return null;\n    const cs = container.style;\n    if (cs.scrollSnapType && cs.scrollSnapType !== "none") return null;\n    const holdsPage = container.rect.height >= snap.viewportHeight / 2 || container.el.querySelector(PAGE_CONTENT) !== null;\n    if (!holdsPage) return null;\n    for (let p = rec; p && p !== container; p = p.parent) {\n      if (SIDEWAYS_CONTENT.has(p.el.tagName)) return null;\n      if (p.style.transform && p.style.transform !== "none") return null;\n    }\n    return {\n      kind: "wrapper",\n      container,\n      scrolls: cs.overflowX === "auto" || cs.overflowX === "scroll"\n    };\n  }\n  function sticksOut(snap, rec) {\n    if (isVisuallyHidden(rec)) return null;\n    const right = paintedRight(rec);\n    const left = paintedLeft(rec);\n    if (right <= snap.viewportWidth + TOLERANCE && left >= -TOLERANCE) return null;\n    if (rec.outOfFlow === "fixed") {\n      return rec.clipAncestor ? null : { rec, right, left, edge: { kind: "screen" } };\n    }\n    const edge = wrapperEdge(snap, rec);\n    return edge ? { rec, right, left, edge } : null;\n  }\n  function pageOverflow(snap) {\n    const hits = /* @__PURE__ */ new Map();\n    for (const rec of snap.records) {\n      const hit = sticksOut(snap, rec);\n      if (hit) hits.set(rec, hit);\n    }\n    const findings = [];\n    for (const hit of hits.values()) {\n      const { rec, edge } = hit;\n      let p = rec.parent;\n      let covered = false;\n      while (p) {\n        if (hits.has(p)) {\n          covered = true;\n          break;\n        }\n        p = p.parent;\n      }\n      if (covered) continue;\n      const vw = snap.viewportWidth;\n      const clipped = edge.kind === "root" ? snap.rootClipsX : edge.kind === "screen" || !edge.scrolls;\n      const fullyOffscreen = hit.left >= vw || hit.right <= 0;\n      if (clipped && fullyOffscreen) continue;\n      const overflowRight = Math.max(0, hit.right - vw);\n      const overflowLeft = Math.max(0, -hit.left);\n      const side = overflowRight >= overflowLeft ? "right" : "left";\n      const amount = px(Math.max(overflowRight, overflowLeft));\n      if (amount < 1) continue;\n      const endSide = snap.rtl ? "left" : "right";\n      const scrolls = side === endSide && (edge.kind === "root" ? snap.rootScrollsX : edge.kind === "wrapper" && edge.scrolls);\n      if (!scrolls && rec.outOfFlow && isDecorative(rec.el)) continue;\n      if (!scrolls && isOrnament(rec)) continue;\n      const textOnly = rec.rect.right <= vw + TOLERANCE && rec.rect.left >= -TOLERANCE;\n      let title;\n      if (!scrolls) title = `Content cut off at the ${side} edge by ${amount}px`;\n      else if (edge.kind === "root")\n        title = `Page scrolls horizontally (${amount}px wider than the viewport)`;\n      else title = `Content scrolls sideways inside a full-width container (${amount}px too wide)`;\n      findings.push({\n        suggestion: shrinkSuggestion(rec, textOnly),\n        detector: "page-overflow",\n        severity: scrolls ? "error" : "warning",\n        title,\n        element: describe(rec.el),\n        lineage: lineage(rec.el),\n        ...edge.kind === "wrapper" ? { related: describe(edge.container.el) } : {},\n        evidence: {\n          overflowPx: amount,\n          side,\n          viewportWidth: vw,\n          elementWidth: px(rec.rect.width),\n          causedByText: textOnly,\n          clippedBy: edge.kind === "root" ? snap.rootClipsX ? "page" : "none" : edge.kind === "screen" ? "screen" : "wrapper"\n        },\n        styles: pick(rec.style, [\n          "width",\n          "min-width",\n          "max-width",\n          "white-space",\n          "overflow-wrap",\n          "word-break",\n          "flex-shrink",\n          "position",\n          "margin-left",\n          "margin-right",\n          "transform"\n        ])\n      });\n    }\n    return findings;\n  }\n  function longestWord(text) {\n    let longest = "";\n    for (const raw of text.split(/\\s+/)) {\n      const word = raw.replace(/^[^\\p{L}\\p{N}]+|[^\\p{L}\\p{N}]+$/gu, "");\n      if (word.length > longest.length) longest = word;\n    }\n    return longest;\n  }\n  function shrinkSuggestion(rec, textOnly) {\n    const s = rec.style;\n    if (textOnly) {\n      if (s.whiteSpace === "nowrap" || s.whiteSpace === "pre") {\n        return `white-space: ${s.whiteSpace} keeps this text on one line. Allow it to wrap on small screens.`;\n      }\n      const word = longestWord(rec.text);\n      if (word && /^[\\p{L}\\p{M}\'\u2019-]+$/u.test(word)) {\n        const size = Number.parseFloat(s.fontSize);\n        return size >= 24 ? `The word "${word}" is wider than the screen at ${Math.round(size)}px. Scale the text down on small screens, for example font-size: clamp(1.75rem, 4vw + 1rem, ${Math.round(size / 16 * 100) / 100}rem).` : `The word "${word}" is too long to fit here. Add hyphens: auto (with a lang attribute on the page) or overflow-wrap: break-word.`;\n      }\n      return "Long unbreakable text (a URL, email or code). Add overflow-wrap: anywhere to its container.";\n    }\n    const minWidth = Number.parseFloat(s.minWidth);\n    if (minWidth > 0) {\n      return `min-width: ${s.minWidth} stops it from shrinking. Lower it or drop it on small screens.`;\n    }\n    if (s.flexShrink === "0") {\n      return "flex-shrink: 0 stops it from shrinking. Let it shrink, or wrap the row.";\n    }\n    if (s.whiteSpace === "nowrap") {\n      return "white-space: nowrap keeps its content on one line. Allow wrapping on small screens.";\n    }\n    const parent = rec.parent?.style.display ?? "";\n    if (parent.includes("flex") || parent.includes("grid")) {\n      return "It is a flex/grid item that will not shrink below its content. Add min-width: 0 to it, or replace its fixed width with max-width: 100%.";\n    }\n    return "It is wider than the screen here. Replace any fixed width with max-width: 100% or a fluid width.";\n  }\n  var CONTENT_SELECTOR = "img,video,canvas,iframe,input,button,select,textarea,a[href]";\n  function isDecorative(el) {\n    if (el.matches(CONTENT_SELECTOR)) return false;\n    if (el.textContent?.trim()) return false;\n    if (el.querySelector(CONTENT_SELECTOR)) return false;\n    if (el.shadowRoot) return false;\n    for (const child of el.querySelectorAll("*")) if (child.shadowRoot) return false;\n    return true;\n  }\n  var DEFAULT_VALUES = {\n    "flex-shrink": "1",\n    position: "static",\n    "object-fit": "fill",\n    overflow: "visible",\n    "flex-basis": "auto",\n    transform: "none"\n  };\n  function pick(style, props) {\n    const out = {};\n    for (const prop of props) {\n      const v = style.getPropertyValue(prop);\n      if (!v || v === "none" || v === "normal" || v === "auto" || v === "0px") continue;\n      if (DEFAULT_VALUES[prop] === v) continue;\n      out[prop] = v;\n    }\n    return out;\n  }\n\n  // ../analyzers/src/detectors/containment.ts\n  var TOLERANCE2 = 1;\n  var VERTICAL_TOLERANCE = 2;\n  var MEDIA = /* @__PURE__ */ new Set(["IMG", "VIDEO", "IFRAME", "CANVAS", "EMBED", "OBJECT", "svg", "PICTURE"]);\n  function alpha(color) {\n    if (!color || color === "transparent") return 0;\n    const m = color.match(/rgba?\\(([^)]+)\\)/);\n    if (!m?.[1]) return 1;\n    const parts = m[1].split(/[\\s,/]+/).filter(Boolean);\n    return parts.length >= 4 ? Number.parseFloat(parts[3] ?? "1") : 1;\n  }\n  function effectiveBackground(rec) {\n    let p = rec;\n    while (p) {\n      if (alpha(p.style.backgroundColor) > 0) return p.style.backgroundColor;\n      p = p.parent;\n    }\n    const body = getComputedStyle(document.body).backgroundColor;\n    if (alpha(body) > 0) return body;\n    return getComputedStyle(document.documentElement).backgroundColor;\n  }\n  function isBounded(rec) {\n    const s = rec.style;\n    if (clipsX(s) || isInline(s) || rec.rect.width < 24 || rec.rect.height < 16) return false;\n    const border = Number.parseFloat(s.borderLeftWidth) > 0 && alpha(s.borderLeftColor) > 0 || Number.parseFloat(s.borderRightWidth) > 0 && alpha(s.borderRightColor) > 0;\n    if (border) return true;\n    if (s.boxShadow && s.boxShadow !== "none") return true;\n    if (s.backgroundImage && s.backgroundImage !== "none") return true;\n    const bg = s.backgroundColor;\n    return alpha(bg) > 0 && bg !== effectiveBackground(rec.parent);\n  }\n  function sameContext(a, b) {\n    return a.oofRoot === b.oofRoot && a.clipAncestor === b.clipAncestor;\n  }\n  function overflowAmount(child, box) {\n    return Math.max(paintedRight(child) - box.right, box.left - paintedLeft(child), 0);\n  }\n  function overflowBelow(child, container) {\n    if (isInline(child.style)) return 0;\n    return Math.max(child.rect.bottom - container.rect.bottom, 0);\n  }\n  function offsetOnPurpose(rec, container) {\n    for (let p = rec; p && p !== container; p = p.parent) {\n      if (isDeliberateOffset(p) || p.style.float !== "none") return true;\n    }\n    return false;\n  }\n  function contentOverflow(snap) {\n    const bounded = /* @__PURE__ */ new Set();\n    for (const rec of snap.records) if (isBounded(rec)) bounded.add(rec);\n    const findings = [];\n    const escapes = /* @__PURE__ */ new Map();\n    for (const rec of snap.records) {\n      if (isVisuallyHidden(rec) || rec.outOfFlow === "fixed") continue;\n      let container = rec.parent;\n      while (container && !bounded.has(container)) container = container.parent;\n      if (!container || !sameContext(rec, container)) continue;\n      const sideways = overflowAmount(rec, container.rect);\n      if (sideways > TOLERANCE2) {\n        const side = paintedRight(rec) - container.rect.right >= sideways - 0.01 ? "right" : "left";\n        escapes.set(rec, { container, side, amount: sideways });\n        continue;\n      }\n      const below = overflowBelow(rec, container);\n      if (below > VERTICAL_TOLERANCE && !offsetOnPurpose(rec, container)) {\n        escapes.set(rec, { container, side: "bottom", amount: below });\n      }\n    }\n    for (const [rec, { container, side, amount: raw }] of escapes) {\n      if (rec.parent && escapes.get(rec.parent)?.container === container) continue;\n      const amount = px(raw);\n      if (side === "bottom") {\n        findings.push({\n          detector: "content-overflow",\n          severity: "error",\n          title: `Content spills ${amount}px out of the bottom of its container`,\n          element: describe(rec.el),\n          related: describe(container.el),\n          evidence: {\n            overflowPx: amount,\n            side,\n            containerHeight: px(container.rect.height),\n            elementHeight: px(rec.rect.height)\n          },\n          styles: pick(container.style, ["height", "max-height", "min-height"]),\n          suggestion: `The container is ${px(container.rect.height)}px tall and its content needs more room at this width. Use min-height instead of a fixed height.`\n        });\n        continue;\n      }\n      const textOnly = rec.rect.right <= container.rect.right + TOLERANCE2 && rec.rect.left >= container.rect.left - TOLERANCE2;\n      findings.push({\n        suggestion: shrinkSuggestion(rec, textOnly),\n        detector: "content-overflow",\n        severity: "error",\n        title: textOnly ? `Text spills ${amount}px outside its container` : `Content spills ${amount}px outside its container`,\n        element: describe(rec.el),\n        lineage: lineage(rec.el),\n        related: describe(container.el),\n        evidence: {\n          overflowPx: amount,\n          side,\n          containerWidth: px(container.rect.width),\n          elementWidth: px(rec.rect.width),\n          causedByText: textOnly\n        },\n        styles: pick(rec.style, [\n          "width",\n          "min-width",\n          "white-space",\n          "overflow-wrap",\n          "word-break",\n          "flex-shrink",\n          "flex-basis"\n        ])\n      });\n    }\n    return findings;\n  }\n  function isMedia(el) {\n    return MEDIA.has(el.tagName);\n  }\n  function mediaOverflow(snap) {\n    const findings = [];\n    for (const rec of snap.records) {\n      if (!isMedia(rec.el) || rec.outOfFlow) continue;\n      if (rec.el.tagName === "PICTURE") continue;\n      let container = rec.parent;\n      while (container && (isInline(container.style) || container.el.tagName === "PICTURE")) {\n        container = container.parent;\n      }\n      if (!container || container.clipAncestor !== rec.clipAncestor || clipsX(container.style))\n        continue;\n      const ml = Number.parseFloat(rec.style.marginLeft) || 0;\n      const mr = Number.parseFloat(rec.style.marginRight) || 0;\n      if (ml < 0 || mr < 0) continue;\n      const box = contentBox(container);\n      const excess = rec.rect.width - box.width;\n      if (excess <= TOLERANCE2 || rec.rect.right <= box.right + TOLERANCE2) continue;\n      findings.push({\n        detector: "media-overflow",\n        severity: "error",\n        title: `${label(rec.el)} is ${px(excess)}px wider than its container`,\n        element: describe(rec.el),\n        lineage: lineage(rec.el),\n        related: describe(container.el),\n        evidence: {\n          overflowPx: px(excess),\n          mediaWidth: px(rec.rect.width),\n          containerWidth: px(box.width)\n        },\n        styles: pick(rec.style, ["width", "min-width", "max-width", "height", "object-fit"]),\n        suggestion: "Add max-width: 100% and height: auto so it scales down with its container."\n      });\n    }\n    return findings;\n  }\n  function label(el) {\n    switch (el.tagName) {\n      case "IMG":\n        return "Image";\n      case "VIDEO":\n        return "Video";\n      case "IFRAME":\n      case "EMBED":\n      case "OBJECT":\n        return "Embed";\n      case "CANVAS":\n        return "Canvas";\n      default:\n        return "Graphic";\n    }\n  }\n\n  // ../analyzers/src/detectors/elements.ts\n  var MAX_DISTORTION = 0.05;\n  var MIN_TARGET = 24;\n  var TARGETS = \'a[href], button, input:not([type="hidden"]), select, textarea, summary, [role="button"], [role="link"], [role="tab"], [role="menuitem"], [role="checkbox"], [role="switch"], [tabindex]:not([tabindex="-1"])\';\n  function distortedMedia(snap) {\n    const findings = [];\n    for (const rec of snap.records) {\n      if (rec.el.tagName !== "IMG" || isVisuallyHidden(rec)) continue;\n      const img = rec.el;\n      if (!img.complete || !img.naturalWidth || !img.naturalHeight) continue;\n      if (/\\.svg(\\?|#|$)|^data:image\\/svg/i.test(img.currentSrc || img.src)) continue;\n      if (rec.style.objectFit && rec.style.objectFit !== "fill") continue;\n      const s = rec.style;\n      const w = rec.rect.width - (Number.parseFloat(s.paddingLeft) || 0) - (Number.parseFloat(s.paddingRight) || 0) - (Number.parseFloat(s.borderLeftWidth) || 0) - (Number.parseFloat(s.borderRightWidth) || 0);\n      const h = rec.rect.height - (Number.parseFloat(s.paddingTop) || 0) - (Number.parseFloat(s.paddingBottom) || 0) - (Number.parseFloat(s.borderTopWidth) || 0) - (Number.parseFloat(s.borderBottomWidth) || 0);\n      if (w < 16 || h < 16) continue;\n      const natural = img.naturalWidth / img.naturalHeight;\n      const rendered = w / h;\n      const distortion = Math.abs(rendered / natural - 1);\n      if (distortion <= MAX_DISTORTION) continue;\n      findings.push({\n        detector: "distorted-media",\n        severity: "warning",\n        title: `Image is ${rendered > natural ? "stretched" : "squashed"} ${Math.round(distortion * 100)}% out of proportion`,\n        element: describe(rec.el),\n        evidence: {\n          renderedRatio: Math.round(rendered * 100) / 100,\n          naturalRatio: Math.round(natural * 100) / 100,\n          renderedWidth: px(w),\n          renderedHeight: px(h)\n        },\n        styles: pick(rec.style, ["width", "height", "max-width", "object-fit", "aspect-ratio"]),\n        suggestion: "Keep width and height proportional (height: auto), or crop with object-fit: cover."\n      });\n    }\n    return findings;\n  }\n  function center(b) {\n    return { x: (b.left + b.right) / 2, y: (b.top + b.bottom) / 2 };\n  }\n  function distanceToBox(p, b) {\n    const dx = Math.max(b.left - p.x, 0, p.x - b.right);\n    const dy = Math.max(b.top - p.y, 0, p.y - b.bottom);\n    return Math.hypot(dx, dy);\n  }\n  function isInlineTextLink(rec) {\n    if (rec.el.tagName !== "A" || !rec.style.display.startsWith("inline")) return false;\n    const parent = rec.el.parentElement;\n    if (!parent) return false;\n    const own = rec.el.textContent?.trim().length ?? 0;\n    const around = parent.textContent?.trim().length ?? 0;\n    return around > own + 10;\n  }\n  function hasLabel(el) {\n    if (!(el instanceof HTMLInputElement)) return false;\n    if (el.type !== "checkbox" && el.type !== "radio") return false;\n    return (el.labels?.length ?? 0) > 0;\n  }\n  function smallTapTargets(snap) {\n    if (snap.viewportWidth > TOUCH_MAX_WIDTH) return [];\n    const targets = [];\n    for (const rec of snap.records) {\n      if (!rec.el.matches(TARGETS) || isVisuallyHidden(rec)) continue;\n      if (rec.el.matches(\'[disabled], [aria-disabled="true"]\')) continue;\n      if (rec.rect.width === 0 || rec.rect.height === 0) continue;\n      let nested = false;\n      for (let p = rec.parent; p; p = p.parent) {\n        if (p.el.matches(TARGETS)) {\n          nested = true;\n          break;\n        }\n      }\n      if (!nested) targets.push(rec);\n    }\n    const failing = [];\n    for (const rec of targets) {\n      const { width, height } = rec.rect;\n      if (width >= MIN_TARGET && height >= MIN_TARGET) continue;\n      if (isInlineTextLink(rec) || hasLabel(rec.el)) continue;\n      const c = center(rec.rect);\n      const crowded = targets.some((other) => {\n        if (other === rec) return false;\n        if (distanceToBox(c, other.rect) < MIN_TARGET / 2) return true;\n        const small = other.rect.width < MIN_TARGET || other.rect.height < MIN_TARGET;\n        const oc = center(other.rect);\n        return small && Math.hypot(oc.x - c.x, oc.y - c.y) < MIN_TARGET;\n      });\n      if (crowded) failing.push(rec);\n    }\n    const siblings = /* @__PURE__ */ new Map();\n    for (const rec of targets) siblings.set(rec.parent, (siblings.get(rec.parent) ?? 0) + 1);\n    const byParent = /* @__PURE__ */ new Map();\n    for (const rec of failing) {\n      const list = byParent.get(rec.parent);\n      if (list) list.push(rec);\n      else byParent.set(rec.parent, [rec]);\n    }\n    const findings = [];\n    for (const [parent, list] of byParent) {\n      const first = list[0];\n      if (!first) continue;\n      const grouped = parent !== null && (siblings.get(parent) ?? 0) > 1;\n      const minW = Math.min(...list.map((r) => r.rect.width));\n      const minH = Math.min(...list.map((r) => r.rect.height));\n      findings.push({\n        detector: "small-tap-target",\n        severity: "warning",\n        title: list.length > 1 ? `${list.length} tap targets are ${px(minW)}\\xD7${px(minH)}px and crowd each other` : `Tap target is ${px(first.rect.width)}\\xD7${px(first.rect.height)}px and too close to its neighbours`,\n        element: describe(grouped ? parent.el : first.el),\n        ...grouped ? { related: describe(first.el) } : {},\n        evidence: { width: px(minW), height: px(minH), minimum: MIN_TARGET, targets: list.length },\n        styles: pick(first.style, ["width", "height", "padding", "font-size"]),\n        suggestion: "Make each target at least 24\\xD724px (44\\xD744px is better for touch), or add space between them."\n      });\n    }\n    return findings;\n  }\n  function viewportMeta() {\n    const meta = document.querySelector(\'meta[name="viewport" i]\');\n    const content = meta?.getAttribute("content")?.replace(/\\s+/g, "") ?? "";\n    if (/width=device-width/i.test(content)) return [];\n    const head = document.head ?? document.documentElement;\n    return [\n      {\n        detector: "viewport-meta",\n        severity: "error",\n        title: meta ? "Viewport meta tag does not use width=device-width" : "Missing the responsive viewport meta tag",\n        element: describe(meta ?? head),\n        evidence: { content: content || "missing" },\n        styles: {},\n        suggestion: \'Add <meta name="viewport" content="width=device-width, initial-scale=1"> to <head>. Without it phones render the page at desktop width and shrink it.\'\n      }\n    ];\n  }\n\n  // ../analyzers/src/detectors/overlap.ts\n  var MIN_OVERLAP = 4;\n  var BAND_PX = 200;\n  var MIN_TEXT_LINE_SHARE = 0.3;\n  var REPLACED = /* @__PURE__ */ new Set([\n    "IMG",\n    "VIDEO",\n    "CANVAS",\n    "IFRAME",\n    "svg",\n    "INPUT",\n    "SELECT",\n    "TEXTAREA",\n    "BUTTON"\n  ]);\n  function itemBox(rec) {\n    const raw = REPLACED.has(rec.el.tagName) ? rec.rect : rec.textRect;\n    if (!raw || raw.width <= 0 || raw.height <= 0) return null;\n    return intersectBox(raw, rec.clip);\n  }\n  function ancestors(rec) {\n    const chain = [];\n    let p = rec;\n    while (p) {\n      chain.push(p);\n      p = p.parent;\n    }\n    return chain;\n  }\n  function isExplicitlyPlacedGridItem(rec) {\n    const s = rec.style;\n    return s.gridRowStart !== "auto" || s.gridColumnStart !== "auto";\n  }\n  function branches(a, b) {\n    const chainA = ancestors(a).reverse();\n    const chainB = ancestors(b).reverse();\n    let i = 0;\n    while (i < chainA.length && i < chainB.length && chainA[i] === chainB[i]) i++;\n    const branchA = chainA[i];\n    const branchB = chainB[i];\n    if (!branchA || !branchB) return null;\n    const lca = i > 0 ? chainA[i - 1] ?? null : null;\n    for (const rec of chainA.slice(i)) if (isDeliberateOffset(rec)) return null;\n    for (const rec of chainB.slice(i)) if (isDeliberateOffset(rec)) return null;\n    if (lca?.style.display.includes("grid")) {\n      if (isExplicitlyPlacedGridItem(branchA) && isExplicitlyPlacedGridItem(branchB)) return null;\n    }\n    return { lca, a: branchA, b: branchB };\n  }\n  function intersect(a, b) {\n    return {\n      w: Math.min(a.right, b.right) - Math.max(a.left, b.left),\n      h: Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top)\n    };\n  }\n  function paintedOverlap(x, y) {\n    let best = { w: 0, h: 0 };\n    for (const a of x.parts) {\n      for (const b of y.parts) {\n        const o = intersect(a, b);\n        if (o.w > 0 && o.h > 0 && o.w * o.h > best.w * best.h) best = o;\n      }\n    }\n    return best;\n  }\n  var SPILL_PX = 2;\n  function spillOf(branch, x, y) {\n    for (const item of [x, y]) {\n      if (!ancestors(item.rec).includes(branch) || item.rec === branch) continue;\n      const box = branch.rect;\n      if (item.box.bottom > box.bottom + SPILL_PX) return { box: branch, direction: "down" };\n      if (item.box.right > box.right + SPILL_PX || item.box.left < box.left - SPILL_PX) {\n        return { box: branch, direction: "across" };\n      }\n    }\n    return null;\n  }\n  function name(rec) {\n    return `\\`${describe(rec.el).selector}\\``;\n  }\n  function suggestionFor(g) {\n    if (g.spill?.direction === "down") {\n      return `The content of ${name(g.spill.box)} is taller than its box at this width and runs down over what comes next. Its height is fixed (height or max-height) and the content no longer fits once it wraps; use min-height instead, or let it grow with its content.`;\n    }\n    if (g.spill?.direction === "across") {\n      return `The content of ${name(g.spill.box)} is wider than its box at this width and runs sideways into its neighbour. Let it shrink or wrap (min-width: 0 on flex or grid items, overflow-wrap: anywhere for long words, max-width: 100% for media).`;\n    }\n    const lca = g.lca;\n    const display = lca?.style.display ?? "";\n    if (lca && display.includes("flex") && !lca.style.flexDirection.startsWith("column")) {\n      return `They sit side by side in the flex row ${name(lca)}, which runs out of room at this width. Let the row wrap (flex-wrap: wrap), let the item that should give way shrink (min-width: 0), or stack them below this width with a media query.`;\n    }\n    if (lca && display.includes("grid")) {\n      return `They share the grid ${name(lca)}, whose columns are too narrow here for what is in them. Use minmax(0, 1fr) columns so items can shrink, or switch to fewer columns below this width.`;\n    }\n    return "These two areas stop making room for each other at this width. Stack them earlier with a media query, or let the narrower one shrink (min-width: 0).";\n  }\n  function overlap(snap) {\n    const items = [];\n    for (const rec of snap.records) {\n      if (rec.outOfFlow || isVisuallyHidden(rec)) continue;\n      const box = itemBox(rec);\n      if (!box || box.width < 1 || box.height < 1) continue;\n      const isText = !REPLACED.has(rec.el.tagName);\n      const parts = isText ? rec.textFragments.map((f) => intersectBox(f, rec.clip)).filter((f) => !!f && f.width > 0 && f.height > 0) : [];\n      items.push({\n        rec,\n        box,\n        parts: parts.length ? parts : [box],\n        lineHeight: isText ? box.height / Math.max(1, rec.textLines) : 0\n      });\n    }\n    const groups = /* @__PURE__ */ new Map();\n    const index = /* @__PURE__ */ new Map();\n    for (const [i, r] of snap.records.entries()) index.set(r, i);\n    const bands = /* @__PURE__ */ new Map();\n    for (const item of items) {\n      const last = Math.floor(item.box.bottom / BAND_PX);\n      for (let b = Math.floor(item.box.top / BAND_PX); b <= last; b++) {\n        const list = bands.get(b);\n        if (list) list.push(item);\n        else bands.set(b, [item]);\n      }\n    }\n    for (const [band, list] of bands) {\n      list.sort((x, y) => x.box.left - y.box.left);\n      for (let i = 0; i < list.length; i++) {\n        const x = list[i];\n        for (let j = i + 1; j < list.length; j++) {\n          const y = list[j];\n          if (y.box.left >= x.box.right - MIN_OVERLAP) break;\n          if (Math.floor(Math.max(x.box.top, y.box.top) / BAND_PX) !== band) continue;\n          const rough = intersect(x.box, y.box);\n          if (rough.w < MIN_OVERLAP || rough.h < MIN_OVERLAP) continue;\n          const { w, h } = paintedOverlap(x, y);\n          const minH = Math.max(\n            MIN_OVERLAP,\n            MIN_TEXT_LINE_SHARE * Math.max(x.lineHeight, y.lineHeight)\n          );\n          if (w < MIN_OVERLAP || h < minH) continue;\n          const split = branches(x.rec, y.rec);\n          if (!split) continue;\n          const [first, second] = (index.get(split.a) ?? 0) < (index.get(split.b) ?? 0) ? [split.a, split.b] : [split.b, split.a];\n          const key = `${index.get(first)}:${index.get(second)}`;\n          const spill = spillOf(first, x, y) ?? spillOf(second, x, y);\n          const g = groups.get(key);\n          if (g) {\n            g.w = Math.max(g.w, w);\n            g.h = Math.max(g.h, h);\n            g.pairs++;\n            g.spill ??= spill;\n          } else {\n            groups.set(key, { a: first, b: second, lca: split.lca, w, h, pairs: 1, spill });\n          }\n        }\n      }\n    }\n    const findings = [];\n    for (const g of groups.values()) {\n      findings.push({\n        detector: "overlap",\n        severity: "error",\n        title: `Overlaps another element (${px(g.w)}\\xD7${px(g.h)}px)`,\n        element: describe(g.a.el),\n        related: describe(g.b.el),\n        evidence: { overlapWidth: px(g.w), overlapHeight: px(g.h), overlappingPairs: g.pairs },\n        suggestion: suggestionFor(g),\n        styles: pick(g.a.style, [\n          "display",\n          "position",\n          "width",\n          "min-width",\n          "flex-shrink",\n          "grid-template-columns"\n        ])\n      });\n    }\n    return findings;\n  }\n\n  // ../analyzers/src/detectors/text.ts\n  var CUT_TOLERANCE = 1;\n  var MIN_GUTTER = 4;\n  var MIN_TINY_FONT = 12;\n  var MAX_TINY_FINDINGS = 8;\n  var MIN_LARGE_FONT = 28;\n  var MIN_LARGE_CHARS_PER_LINE = 12;\n  var MAX_LARGE_FINDINGS = 8;\n  function scrollsOn(style, axis) {\n    const v = axis === "x" ? style.overflowX : style.overflowY;\n    return v === "auto" || v === "scroll";\n  }\n  function clipsOn(style, axis) {\n    return (axis === "x" ? style.overflowX : style.overflowY) !== "visible";\n  }\n  function truncatesOnPurpose(rec, axis) {\n    const s = rec.style;\n    if (axis === "x") return s.textOverflow === "ellipsis" || s.textOverflow === "clip";\n    return !!s.webkitLineClamp && s.webkitLineClamp !== "none";\n  }\n  function findClipper(rec, raw, axis) {\n    for (let p = rec; p; p = p.parent) {\n      if (!clipsOn(p.style, axis)) continue;\n      const cut = axis === "x" ? raw.left < p.rect.left - CUT_TOLERANCE || raw.right > p.rect.right + CUT_TOLERANCE : raw.top < p.rect.top - CUT_TOLERANCE || raw.bottom > p.rect.bottom + CUT_TOLERANCE;\n      if (cut) return p;\n    }\n    return null;\n  }\n  function clippersWithVisibleText(snap) {\n    const out = /* @__PURE__ */ new Set();\n    for (const rec of snap.records) {\n      if (!rec.textRect) continue;\n      for (let p = rec.parent; p; p = p.parent) {\n        if (out.has(p)) break;\n        if (clipsOn(p.style, "y")) out.add(p);\n      }\n    }\n    return out;\n  }\n  function clippedText(snap) {\n    const byClipper = /* @__PURE__ */ new Map();\n    const vw = snap.viewportWidth;\n    let showing = null;\n    for (const rec of snap.records) {\n      const raw = rec.rawTextRect;\n      if (!raw || rec.outOfFlow === "fixed" || isVisuallyHidden(rec) || isOrnament(rec)) continue;\n      const visible = intersectBox(raw, rec.innerClip);\n      let axis;\n      let clipper;\n      let cut;\n      if (visible) {\n        const cutX = raw.width - visible.width;\n        const cutY = raw.height - visible.height;\n        axis = cutY > CUT_TOLERANCE ? "y" : cutX > CUT_TOLERANCE ? "x" : null;\n        if (!axis) continue;\n        clipper = findClipper(rec, raw, axis);\n        cut = axis === "x" ? cutX : cutY;\n      } else {\n        axis = "y";\n        clipper = findClipper(rec, raw, "y");\n        if (!clipper || raw.top < clipper.rect.bottom - CUT_TOLERANCE) continue;\n        showing ??= clippersWithVisibleText(snap);\n        if (!showing.has(clipper)) continue;\n        cut = raw.bottom - clipper.rect.bottom;\n      }\n      if (!clipper || scrollsOn(clipper.style, axis) || clipper.rect.height < 2) continue;\n      if (axis === "x" && clipper.rect.left <= 1 && clipper.rect.right >= vw - 1) continue;\n      let deliberate = false;\n      for (let p = rec; p; p = p.parent) {\n        if (truncatesOnPurpose(p, axis) || p.style.transform && p.style.transform !== "none") {\n          deliberate = true;\n          break;\n        }\n        if (p === clipper) break;\n      }\n      if (deliberate) continue;\n      const prev = byClipper.get(clipper);\n      if (prev) {\n        prev.count++;\n        if (cut > prev.cut) Object.assign(prev, { rec, axis, cut });\n      } else {\n        byClipper.set(clipper, { rec, axis, cut, count: 1 });\n      }\n    }\n    const findings = [];\n    for (const [clipper, { rec, axis, cut, count }] of byClipper) {\n      const fixedSize = axis === "y" ? clipper.style.height : clipper.style.width;\n      findings.push({\n        detector: "clipped-text",\n        severity: "warning",\n        title: `Container cuts off its text (${px(cut)}px hidden ${axis === "y" ? "below" : "to the side"})`,\n        element: describe(clipper.el),\n        related: describe(rec.el),\n        evidence: { hiddenPx: px(cut), axis, clippedTextElements: count },\n        styles: pick(clipper.style, [\n          "height",\n          "max-height",\n          "width",\n          "max-width",\n          "overflow",\n          "white-space"\n        ]),\n        suggestion: axis === "y" ? `The container clips its content at ${fixedSize}. Let it grow (min-height instead of height), or truncate on purpose with line-clamp.` : "The container is too narrow for this text. Let the text wrap, or truncate on purpose with text-overflow: ellipsis."\n      });\n    }\n    return findings;\n  }\n  function lineText(rec) {\n    for (const child of rec.el.children) {\n      const display = getComputedStyle(child).display;\n      if (display !== "none" && !display.startsWith("inline")) return rec.text;\n    }\n    const el = rec.el;\n    return (el.innerText ?? el.textContent ?? "").replace(/\\s+/g, " ").trim();\n  }\n  function squishedText(snap) {\n    const findings = [];\n    for (const rec of snap.records) {\n      if (!rec.textRect || rec.textLines < 3 || isVisuallyHidden(rec) || isInline(rec.style))\n        continue;\n      const text = lineText(rec);\n      const chars = text.replace(/\\s/g, "").length;\n      if (chars < 8) continue;\n      if (rec.rect.width >= 10 * fontSize(rec)) continue;\n      const words = text.split(" ").filter(Boolean).length;\n      const perLine = chars / rec.textLines;\n      if ((rec.textLines <= words || breaksAnywhere(text)) && perLine >= 3) continue;\n      findings.push({\n        detector: "squished-text",\n        severity: "warning",\n        title: `Text squeezed to about ${Math.max(1, Math.round(perLine))} characters per line`,\n        element: describe(rec.el),\n        evidence: {\n          lines: rec.textLines,\n          charsPerLine: Math.round(perLine * 10) / 10,\n          width: px(rec.rect.width)\n        },\n        styles: pick(rec.style, ["width", "min-width", "flex-basis", "word-break", "overflow-wrap"]),\n        suggestion: "This column gets too narrow at this width. Give it a min-width, or stack the layout earlier."\n      });\n    }\n    return findings;\n  }\n  function browserDefault(rec) {\n    const control = rec.el.closest("button, input, select, textarea");\n    if (!control) return false;\n    const around = control.parentElement;\n    return !!around && fontSize(rec) < Number.parseFloat(getComputedStyle(around).fontSize);\n  }\n  function tinyText(snap) {\n    if (snap.viewportWidth > TOUCH_MAX_WIDTH) return [];\n    const byParent = /* @__PURE__ */ new Map();\n    for (const rec of snap.records) {\n      if (!rec.textRect || rec.text.length < 3 || isVisuallyHidden(rec) || isOrnament(rec)) continue;\n      const size = fontSize(rec);\n      if (size >= MIN_TINY_FONT) continue;\n      const g = byParent.get(rec.parent);\n      if (g) {\n        g.count++;\n        if (size < g.size) Object.assign(g, { rec, size });\n      } else {\n        byParent.set(rec.parent, { rec, size, count: 1 });\n      }\n    }\n    const findings = [];\n    for (const [parent, g] of byParent) {\n      if (findings.length >= MAX_TINY_FINDINGS) break;\n      const grouped = g.count > 1 && parent !== null;\n      const size = Math.round(g.size * 10) / 10;\n      findings.push({\n        detector: "tiny-text",\n        severity: "info",\n        title: g.count > 1 ? `${g.count} pieces of text are ${size}px on small screens` : `Text is ${size}px on small screens`,\n        element: describe(grouped ? parent.el : g.rec.el),\n        ...grouped ? { related: describe(g.rec.el) } : {},\n        evidence: { fontSizePx: size, textElements: g.count },\n        styles: pick(g.rec.style, ["font-size", "line-height"]),\n        suggestion: browserDefault(g.rec) ? "Form controls don\'t take the page\'s font unless told to, and Safari\'s default is 11px. Add font: inherit to button, input, select and textarea." : "Use at least 12px (16px for body text) on small screens."\n      });\n    }\n    return findings;\n  }\n  function forcedLines(el, style) {\n    let lines = 1;\n    const keepsNewlines = /^(pre|pre-wrap|pre-line|break-spaces)$/.test(style.whiteSpace);\n    for (const node of el.childNodes) {\n      if (node.nodeName === "BR") lines++;\n      else if (keepsNewlines && node.nodeType === Node.TEXT_NODE) {\n        lines += (node.textContent?.trim().match(/\\n/g) ?? []).length;\n      }\n    }\n    return lines;\n  }\n  function oversizedText(snap) {\n    const vw = snap.viewportWidth;\n    if (vw > TOUCH_MAX_WIDTH) return [];\n    const findings = [];\n    for (const rec of snap.records) {\n      if (findings.length >= MAX_LARGE_FINDINGS) break;\n      if (!rec.textRect || rec.textLines < 3 || isVisuallyHidden(rec)) continue;\n      const size = fontSize(rec);\n      if (size < MIN_LARGE_FONT) continue;\n      const words = rec.text.split(" ").filter(Boolean).length;\n      if (words < 2) continue;\n      const chars = rec.text.replace(/\\s/g, "").length;\n      const perLine = chars / rec.textLines;\n      if (perLine >= MIN_LARGE_CHARS_PER_LINE) continue;\n      if (rec.textLines > words && rec.rect.width < 10 * size) continue;\n      if (rec.style.writingMode && !rec.style.writingMode.startsWith("horizontal")) continue;\n      if (rec.outOfFlow || isOrnament(rec)) continue;\n      if (rec.textLines - forcedLines(rec.el, rec.style) < 2) continue;\n      let block = rec;\n      while (!isBlock(block) && block.parent) block = block.parent;\n      const room = block.parent ? contentBox(block.parent).width : vw;\n      if (block.rect.width < room * 0.9 || block.rect.width < vw * 0.6) continue;\n      const rem = Math.round(size / 16 * 100) / 100;\n      findings.push({\n        detector: "oversized-text",\n        severity: "warning",\n        title: `Text is too big for the screen (${px(size)}px, ${rec.textLines} lines of a word or two)`,\n        element: describe(rec.el),\n        evidence: {\n          fontSizePx: px(size),\n          lines: rec.textLines,\n          charsPerLine: Math.round(perLine * 10) / 10,\n          screenShare: Math.round(rec.textRect.height / snap.viewportHeight * 100) / 100\n        },\n        styles: pick(rec.style, ["font-size", "line-height", "letter-spacing"]),\n        suggestion: `Scale it down on small screens, for example font-size: clamp(1.75rem, 4vw + 1rem, ${rem}rem), or a smaller size below 640px.`\n      });\n    }\n    return findings;\n  }\n  function isBlock(rec) {\n    return !rec.style.display.startsWith("inline") && rec.style.display !== "contents";\n  }\n  function edgeGutter(snap) {\n    const vw = snap.viewportWidth;\n    if (vw > TOUCH_MAX_WIDTH) return [];\n    const groups = /* @__PURE__ */ new Map();\n    for (const rec of snap.records) {\n      const t = rec.textRect;\n      if (!t || rec.outOfFlow === "fixed" || isVisuallyHidden(rec) || rec.text.length < 2) continue;\n      if (isOrnament(rec)) continue;\n      if (t.left < -0.5 || t.right > vw + 0.5) continue;\n      let moves = false;\n      let overflows = rec.rect.right > vw + 0.5 || rec.rect.left < -0.5;\n      for (let p = rec.parent; p && !moves && !overflows; p = p.parent) {\n        if (scrollsOn(p.style, "x") || p.style.transform && p.style.transform !== "none") {\n          moves = true;\n        }\n        if (p.rect.right > vw + 0.5 || p.rect.left < -0.5) overflows = true;\n      }\n      if (moves || overflows) continue;\n      let container = rec;\n      while (!isBlock(container) && container.parent) container = container.parent;\n      const box = contentBox(container);\n      const leftGap = box.left;\n      const rightGap = vw - box.right;\n      let side = null;\n      if (leftGap < MIN_GUTTER && t.left < MIN_GUTTER + 0.5) side = "left";\n      else if (rightGap < MIN_GUTTER && (rec.textLines >= 2 || t.right > vw - MIN_GUTTER))\n        side = "right";\n      if (!side) continue;\n      const gap = side === "left" ? leftGap : rightGap;\n      const g = groups.get(container);\n      if (g) {\n        g.count++;\n        if (gap < g.gap) Object.assign(g, { gap, side, rec });\n      } else {\n        groups.set(container, { side, gap, count: 1, rec });\n      }\n    }\n    const findings = [];\n    for (const [container, g] of groups) {\n      findings.push({\n        detector: "edge-gutter",\n        severity: "warning",\n        title: `Text touches the ${g.side} edge of the screen (${Math.max(0, px(g.gap))}px gap)`,\n        element: describe(container.el),\n        evidence: { gapPx: Math.max(0, px(g.gap)), side: g.side, textElements: g.count },\n        styles: pick(container.style, [\n          "padding-left",\n          "padding-right",\n          "margin-left",\n          "margin-right",\n          "width"\n        ]),\n        suggestion: "Add horizontal padding (around 16px) to this container on small screens."\n      });\n    }\n    return findings;\n  }\n\n  // ../analyzers/src/detectors/wrap.ts\n  var NAV_CONTEXT = \'nav, header, [role="navigation"], [role="tablist"], [role="menubar"], [role="banner"]\';\n  var LABEL = \'button, [role="button"], [role="tab"], [role="menuitem"]\';\n  var MAX_LABEL_CHARS = 40;\n  function isRowContainer(rec) {\n    const s = rec.style;\n    if (s.display === "flex" || s.display === "inline-flex") {\n      return s.flexDirection.startsWith("row") && s.flexWrap !== "nowrap";\n    }\n    return false;\n  }\n  function inlineChildren(rec, byElement) {\n    const out = [];\n    for (const child of renderedChildren(rec.el)) {\n      const c = byElement.get(child);\n      if (!c || c.outOfFlow || isVisuallyHidden(c)) continue;\n      out.push(c);\n    }\n    return out;\n  }\n  function allInlineLevel(children) {\n    return children.length > 0 && children.every(\n      (c) => c.style.display.startsWith("inline") && c.style.display !== "inline-table"\n    );\n  }\n  function countRows(children) {\n    const tops = [];\n    for (const c of children) {\n      const half = Math.max(4, c.rect.height / 2);\n      if (!tops.some((t) => Math.abs(t - c.rect.top) < half)) tops.push(c.rect.top);\n    }\n    return tops.length;\n  }\n  function textLinesDeep(el) {\n    const tops = [];\n    const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);\n    const range = document.createRange();\n    for (let node = walker.nextNode(); node; node = walker.nextNode()) {\n      if (!node.textContent?.trim()) continue;\n      const box = node.parentElement?.getBoundingClientRect();\n      if (box && (box.width <= 1 || box.height <= 1)) continue;\n      range.selectNodeContents(node);\n      for (const r of range.getClientRects()) {\n        if (r.width === 0 || r.height === 0) continue;\n        if (!tops.some((t) => Math.abs(t.top - r.top) < Math.max(t.height, r.height) / 2)) {\n          tops.push({ top: r.top, height: r.height });\n        }\n      }\n    }\n    return tops.length;\n  }\n  function wrapStats(snap) {\n    const stats = [];\n    for (const rec of snap.records) {\n      if (isVisuallyHidden(rec)) continue;\n      const children = inlineChildren(rec, snap.byElement);\n      if (children.length >= 2 && (isRowContainer(rec) || allInlineLevel(children))) {\n        if (closestComposed(rec.el, NAV_CONTEXT)) {\n          stats.push({\n            element: describe(rec.el),\n            kind: "row",\n            lines: countRows(children),\n            items: children.length\n          });\n        }\n      }\n      const isLabel = rec.el.matches(LABEL) || rec.el.matches("a[href]") && closestComposed(rec.el, NAV_CONTEXT) !== null;\n      if (isLabel) {\n        const text = rec.el.textContent?.replace(/\\s+/g, " ").trim() ?? "";\n        if (text && text.length <= MAX_LABEL_CHARS && text.includes(" ")) {\n          stats.push({\n            element: describe(rec.el),\n            kind: "label",\n            lines: textLinesDeep(rec.el),\n            items: 1\n          });\n        }\n      }\n    }\n    return stats;\n  }\n\n  // ../analyzers/src/fingerprint.ts\n  var LANDMARKS = /* @__PURE__ */ new Set([\n    "HEADER",\n    "NAV",\n    "MAIN",\n    "ASIDE",\n    "FOOTER",\n    "SECTION",\n    "ARTICLE",\n    "FORM"\n  ]);\n  var MAX_DEPTH = 5;\n  var MAX_ELEMENTS = 400;\n  function isStructural(rec, depth) {\n    if (depth <= 3) return true;\n    if (LANDMARKS.has(rec.el.tagName)) return true;\n    const d = rec.style.display;\n    return depth <= MAX_DEPTH && (d.includes("flex") || d.includes("grid"));\n  }\n  function rowsAndColumns(children) {\n    const rows = [];\n    const counts = [];\n    for (const c of children) {\n      const tol = Math.max(4, Math.min(c.rect.height / 2, 24));\n      const i = rows.findIndex((t) => Math.abs(t - c.rect.top) < tol);\n      if (i === -1) {\n        rows.push(c.rect.top);\n        counts.push(1);\n      } else {\n        counts[i] = (counts[i] ?? 0) + 1;\n      }\n    }\n    return counts.join(".");\n  }\n  function layoutSignature(snap, index) {\n    const children = /* @__PURE__ */ new Map();\n    for (const rec of snap.records) {\n      if (!rec.parent || rec.outOfFlow === "fixed") continue;\n      const list = children.get(rec.parent);\n      if (list) list.push(rec);\n      else children.set(rec.parent, [rec]);\n    }\n    const branchDepth = /* @__PURE__ */ new Map();\n    for (const rec of snap.records) {\n      const parent = rec.parent;\n      const parentDepth = parent ? branchDepth.get(parent) ?? 0 : 0;\n      const branches2 = parent ? (children.get(parent)?.length ?? 0) > 1 : true;\n      branchDepth.set(rec, parentDepth + (branches2 ? 1 : 0));\n    }\n    const parts = [];\n    for (const rec of snap.records) {\n      if (parts.length >= MAX_ELEMENTS) break;\n      if (rec.outOfFlow === "fixed" || !isStructural(rec, branchDepth.get(rec) ?? 0)) continue;\n      const kids = (children.get(rec) ?? []).filter(\n        (c) => !c.outOfFlow && !c.style.display.startsWith("inline")\n      );\n      const s = rec.style;\n      let mode = s.display;\n      if (mode.includes("flex")) mode += `/${s.flexDirection}`;\n      const wraps = mode.includes("flex") && s.flexWrap !== "nowrap";\n      const arrangement = kids.length > 1 && !wraps ? rowsAndColumns(kids) : String(kids.length);\n      parts.push(`${index(rec.el)}=${mode}:${arrangement}`);\n    }\n    return parts.join("|");\n  }\n  var MEDIA_EM = 16;\n  var QUERY_UNITS = "(px|em|rem)";\n  function parseContainerCondition(text) {\n    const out = [];\n    const name2 = text.match(/^\\s*(?!not\\b|style\\b|scroll-state\\b)([a-zA-Z_][\\w-]*)\\s*(?=\\(|$)/)?.[1] ?? null;\n    const add = (value, unit, after) => out.push({ name: name2, value: Number.parseFloat(value), unit, after });\n    const legacy = new RegExp(`(min|max)-(?:width|inline-size)\\\\s*:\\\\s*([\\\\d.]+)${QUERY_UNITS}`, "g");\n    for (let m = legacy.exec(text); m; m = legacy.exec(text)) {\n      add(m[2] ?? "0", m[3] ?? "px", m[1] === "max");\n    }\n    const range = new RegExp(`(?:width|inline-size)\\\\s*(>=|>|<=|<)\\\\s*([\\\\d.]+)${QUERY_UNITS}`, "g");\n    for (let m = range.exec(text); m; m = range.exec(text)) {\n      add(m[2] ?? "0", m[3] ?? "px", m[1] === "<=" || m[1] === ">");\n    }\n    const reversed = new RegExp(\n      `([\\\\d.]+)${QUERY_UNITS}\\\\s*(>=|>|<=|<)\\\\s*(?:width|inline-size)`,\n      "g"\n    );\n    for (let m = reversed.exec(text); m; m = reversed.exec(text)) {\n      add(m[1] ?? "0", m[2] ?? "px", m[3] === "<" || m[3] === ">=");\n    }\n    return out;\n  }\n  var queryCache = null;\n  function containerQueries() {\n    if (typeof CSSContainerRule === "undefined") return [];\n    const roots = [document, ...shadowRoots()];\n    const sheets = roots.flatMap((r) => [...r.styleSheets, ...r.adoptedStyleSheets ?? []]);\n    const key = sheets.map((s) => {\n      try {\n        return s.cssRules.length;\n      } catch {\n        return -1;\n      }\n    }).join(",");\n    if (queryCache?.key === key) return queryCache.queries;\n    const queries = [];\n    const seen = /* @__PURE__ */ new Set();\n    const walk = (rules) => {\n      for (const rule of rules) {\n        if (rule instanceof CSSContainerRule) {\n          for (const q of parseContainerCondition(rule.conditionText)) {\n            const id = `${q.name}|${q.value}${q.unit}|${q.after}`;\n            if (!seen.has(id)) {\n              seen.add(id);\n              queries.push(q);\n            }\n          }\n        }\n        if (rule instanceof CSSImportRule) {\n          try {\n            if (rule.styleSheet) walk(rule.styleSheet.cssRules);\n          } catch {\n          }\n        } else if ("cssRules" in rule && rule.cssRules) {\n          walk(rule.cssRules);\n        }\n      }\n    };\n    for (const sheet of sheets) {\n      try {\n        walk(sheet.cssRules);\n      } catch {\n      }\n    }\n    queryCache = { key, queries };\n    return queries;\n  }\n  var MAX_CONTAINER_BITS = 256;\n  function containerSignature(snap) {\n    const queries = containerQueries();\n    if (!queries.length) return void 0;\n    const rootFont = Number.parseFloat(getComputedStyle(document.documentElement).fontSize) || 16;\n    let bits = "";\n    for (const rec of snap.records) {\n      const s = rec.style;\n      if (!s.containerType || s.containerType === "normal") continue;\n      const names = s.containerName.split(/\\s+/);\n      const size = rec.rect.width - (Number.parseFloat(s.paddingLeft) || 0) - (Number.parseFloat(s.paddingRight) || 0) - (Number.parseFloat(s.borderLeftWidth) || 0) - (Number.parseFloat(s.borderRightWidth) || 0);\n      for (const q of queries) {\n        if (q.name && !names.includes(q.name)) continue;\n        const unit = q.unit === "px" ? 1 : q.unit === "em" ? Number.parseFloat(s.fontSize) || 16 : rootFont;\n        const threshold = q.value * unit;\n        bits += (q.after ? size > threshold : size >= threshold) ? "1" : "0";\n        if (bits.length >= MAX_CONTAINER_BITS) return bits;\n      }\n    }\n    return bits || void 0;\n  }\n  function declaredBreakpoints() {\n    const found = /* @__PURE__ */ new Set();\n    const toPx = (value, unit) => Number.parseFloat(value) * (unit === "px" ? 1 : MEDIA_EM);\n    const after = (w) => Math.floor(w) + 1;\n    const read = (text) => {\n      const legacy = /(min|max)-width\\s*:\\s*([\\d.]+)(px|em|rem)/g;\n      for (let m = legacy.exec(text); m; m = legacy.exec(text)) {\n        const [, kind, value = "0", unit = "px"] = m;\n        const w = toPx(value, unit);\n        found.add(Math.round(kind === "max" ? after(w) : w));\n      }\n      const range = /width\\s*(>=|>|<=|<)\\s*([\\d.]+)(px|em|rem)/g;\n      for (let m = range.exec(text); m; m = range.exec(text)) {\n        const [, op, value = "0", unit = "px"] = m;\n        const w = toPx(value, unit);\n        found.add(Math.round(op === "<=" || op === ">" ? after(w) : w));\n      }\n      const reversed = /([\\d.]+)(px|em|rem)\\s*(>=|>|<=|<)\\s*width/g;\n      for (let m = reversed.exec(text); m; m = reversed.exec(text)) {\n        const [, value = "0", unit = "px", op] = m;\n        const w = toPx(value, unit);\n        found.add(Math.round(op === "<" || op === ">=" ? after(w) : w));\n      }\n    };\n    const walk = (rules) => {\n      for (const rule of rules) {\n        if (typeof CSSContainerRule !== "undefined" && rule instanceof CSSContainerRule) {\n          continue;\n        }\n        if (rule instanceof CSSMediaRule) read(rule.conditionText ?? rule.media.mediaText);\n        else if (rule instanceof CSSImportRule) {\n          read(rule.media.mediaText);\n          readSheet(rule.styleSheet);\n          continue;\n        }\n        if ("cssRules" in rule && rule.cssRules)\n          walk(rule.cssRules);\n      }\n    };\n    const readSheet = (sheet) => {\n      if (!sheet) return;\n      read(sheet.media.mediaText);\n      try {\n        walk(sheet.cssRules);\n      } catch {\n      }\n    };\n    const roots = [document, ...shadowRoots()];\n    for (const root of roots) {\n      for (const sheet of root.styleSheets) readSheet(sheet);\n      for (const sheet of root.adoptedStyleSheets ?? []) readSheet(sheet);\n    }\n    return [...found].filter((w) => w > 0).sort((a, b) => a - b);\n  }\n\n  // ../analyzers/src/states.ts\n  var CANDIDATES = [\n    \'[role="tab"]\',\n    "[aria-expanded]",\n    "[aria-haspopup]",\n    "[popovertarget]",\n    "[commandfor]",\n    "[data-bs-toggle]",\n    "[data-toggle]",\n    "details > summary",\n    "button",\n    \'[role="button"]\'\n  ].join(",");\n  var MENU_CLASS = /(hamburger|burger|navbar-toggler|nav-?toggle|toggle-?nav|menu-?(toggle|button|btn|icon|trigger)|toggle-?menu|mobile-?(menu|nav)-?(toggle|button|btn|trigger)?|drawer-?toggle|sidebar-?toggle|offcanvas-?toggle)/i;\n  var MENU_LABEL = /^(?:(?:open|toggle|show)\\s+)?(?:the\\s+)?(?:(?:main|site|mobile|primary)\\s+)?(?:menu|navigation|nav|sidebar)(?:\\s+menu)?$|^[\u2630\u2261]$/i;\n  var MAX_TOGGLES = 40;\n  function nameOf(el) {\n    const aria = el.getAttribute("aria-label")?.trim();\n    if (aria) return aria;\n    const by = el.getAttribute("aria-labelledby");\n    if (by) {\n      const text2 = by.split(/\\s+/).map((id) => document.getElementById(id)?.textContent ?? "").join(" ").replace(/\\s+/g, " ").trim();\n      if (text2) return text2;\n    }\n    const text = (el.textContent ?? "").replace(/\\s+/g, " ").trim();\n    if (text) return text;\n    return el.getAttribute("title")?.trim() ?? "";\n  }\n  function shortLabel(el, kind) {\n    const name2 = nameOf(el);\n    if (!/[\\p{L}\\p{N}]/u.test(name2)) return kind;\n    return name2.length > 40 ? `${name2.slice(0, 37)}...` : name2;\n  }\n  function targetOf(el, attr) {\n    const id = el.getAttribute(attr);\n    if (!id) return null;\n    return el.getRootNode().getElementById?.(id) ?? null;\n  }\n  function bootstrapKind(value) {\n    switch (value) {\n      case "modal":\n        return "dialog";\n      case "offcanvas":\n      case "dropdown":\n        return "menu";\n      case "collapse":\n        return "disclosure";\n      default:\n        return null;\n    }\n  }\n  function looksLikeMenu(el) {\n    const names = [\n      typeof el.className === "string" ? el.className : "",\n      el.id,\n      el.getAttribute("data-testid") ?? ""\n    ].join(" ");\n    return MENU_CLASS.test(names) || MENU_LABEL.test(nameOf(el));\n  }\n  function kindOf(el) {\n    if (el.matches("details > summary")) {\n      const details = el.parentElement;\n      return details.open || details.querySelector(":scope > summary") !== el ? null : "details";\n    }\n    if (el.matches(\'input, select, textarea, [role="combobox"], [contenteditable]\')) return null;\n    if (el.getAttribute("role") === "tab")\n      return el.getAttribute("aria-selected") === "true" ? null : "tab";\n    if (el.hasAttribute("popovertarget")) {\n      return el.getAttribute("popovertargetaction") === "hide" ? null : "popover";\n    }\n    if (el.hasAttribute("commandfor")) {\n      const command = el.getAttribute("command");\n      if (command === "show-modal") return "dialog";\n      if (command === "toggle-popover" || command === "show-popover") return "popover";\n      return null;\n    }\n    const expanded = el.getAttribute("aria-expanded");\n    if (expanded === "true") return null;\n    const popup = el.getAttribute("aria-haspopup");\n    if (popup === "dialog") return "dialog";\n    if (popup && popup !== "false") return "menu";\n    const bootstrap = bootstrapKind(\n      el.getAttribute("data-bs-toggle") ?? el.getAttribute("data-toggle")\n    );\n    if (bootstrap) return bootstrap;\n    if (expanded === "false") return looksLikeMenu(el) ? "menu" : "disclosure";\n    if (el.matches(\'button, [role="button"]\') && looksLikeMenu(el)) return "menu";\n    return null;\n  }\n  function safeToClick(el) {\n    if (el.matches(\':disabled, [aria-disabled="true"]\')) return false;\n    if (el instanceof HTMLButtonElement && el.type === "submit" && el.form) return false;\n    const href = el instanceof HTMLAnchorElement ? el.getAttribute("href") : null;\n    return !href || href.startsWith("#") || /^javascript:/i.test(href);\n  }\n  function sidewaysScroller(el) {\n    for (let p = el.parentElement; p && p !== document.body; p = p.parentElement) {\n      const { overflowX } = getComputedStyle(p);\n      if ((overflowX === "auto" || overflowX === "scroll") && p.scrollWidth > p.clientWidth) return p;\n    }\n    return null;\n  }\n  function isShown(el, scrolls = false) {\n    const r = el.getBoundingClientRect();\n    if (r.width < 1 || r.height < 1) return false;\n    if ((r.right <= 0 || r.left >= window.innerWidth) && !(scrolls && sidewaysScroller(el)))\n      return false;\n    const check = el.checkVisibility;\n    if (check && !check.call(el, { opacityProperty: true, visibilityProperty: true })) return false;\n    if (!check && getComputedStyle(el).visibility === "hidden") return false;\n    return !el.closest(\'[aria-hidden="true"], [inert]\');\n  }\n  function ignored(el, rules) {\n    const marked = closestComposed(el, "[data-breakhound-ignore]");\n    if (marked) {\n      const scope = (marked.getAttribute("data-breakhound-ignore") ?? "").split(/[\\s,]+/);\n      if (scope.every((s) => !s) || scope.includes("all") || scope.includes("states")) return true;\n    }\n    return rules.some((rule) => {\n      if (rule.detectors) return false;\n      try {\n        return Boolean(closestComposed(el, rule.selector));\n      } catch {\n        return false;\n      }\n    });\n  }\n  function groupOf(el, kind) {\n    const shape = (e) => e ? `${e.tagName}.${[...e.classList].map((c) => c.replace(/\\d+/g, "")).sort().join(".")}` : "";\n    const panel = targetOf(el, "aria-controls");\n    return `${kind}|${shape(el)}|${shape(el.parentElement)}|${panel ? shape(panel) : ""}`;\n  }\n  var PRIORITY = {\n    menu: 0,\n    dialog: 0,\n    popover: 1,\n    tab: 1,\n    disclosure: 2,\n    details: 3\n  };\n  function findToggles(rules = []) {\n    const out = [];\n    const panels = /* @__PURE__ */ new Set();\n    for (const el of document.querySelectorAll(CANDIDATES)) {\n      if (out.length >= MAX_TOGGLES) break;\n      if (el.closest(DEV_OVERLAYS)) continue;\n      const kind = kindOf(el);\n      if (!kind || !safeToClick(el) || !isShown(el, kind === "tab") || ignored(el, rules)) continue;\n      const panel = targetOf(el, "aria-controls") ?? targetOf(el, "popovertarget");\n      if (panel) {\n        if (panels.has(panel)) continue;\n        panels.add(panel);\n      }\n      const inHeader = Boolean(el.closest(\'header, nav, [role="banner"], [role="navigation"]\'));\n      out.push({\n        selector: cachedSelector(el),\n        kind,\n        label: shortLabel(el, kind),\n        // Each tab shows different content, unlike the questions of an FAQ.\n        group: kind === "tab" ? `tab|${cachedSelector(el)}` : groupOf(el, kind),\n        priority: PRIORITY[kind] * 2 + (inHeader ? 0 : 1)\n      });\n    }\n    return out;\n  }\n  var toggles = /* @__PURE__ */ new Map();\n  function toggleOf(selector) {\n    const known = toggles.get(selector);\n    if (known?.isConnected) return known;\n    const el = resolveSelector(selector);\n    if (el) toggles.set(selector, el);\n    return el;\n  }\n  function toggleState(selector) {\n    const el = toggleOf(selector);\n    if (!el) return { shown: false, open: null };\n    const shown = isShown(el, el.getAttribute("role") === "tab");\n    if (el.matches("details > summary")) {\n      return { shown, open: el.parentElement.open };\n    }\n    if (el.getAttribute("role") === "tab")\n      return { shown, open: el.getAttribute("aria-selected") === "true" };\n    const expanded = el.getAttribute("aria-expanded");\n    if (expanded === "true" || expanded === "false") return { shown, open: expanded === "true" };\n    const target = targetOf(el, "popovertarget") ?? targetOf(el, "commandfor");\n    if (target instanceof HTMLDialogElement) return { shown, open: target.open };\n    if (target?.hasAttribute("popover")) {\n      try {\n        return { shown, open: target.matches(":popover-open") };\n      } catch {\n        return { shown, open: null };\n      }\n    }\n    return { shown, open: null };\n  }\n  function setDetails(selector, open) {\n    const details = toggleOf(selector)?.parentElement;\n    if (details instanceof HTMLDetailsElement) details.open = open;\n  }\n  function clickPoint(selector) {\n    const el = toggleOf(selector);\n    if (!el) return null;\n    let r = el.getBoundingClientRect();\n    if (r.top < 0 || r.bottom > window.innerHeight) {\n      el.scrollIntoView({ block: "center", inline: "nearest" });\n      r = el.getBoundingClientRect();\n    }\n    const row = r.left < 0 || r.right > window.innerWidth ? sidewaysScroller(el) : null;\n    if (row) {\n      const box = row.getBoundingClientRect();\n      row.scrollLeft += r.left + r.width / 2 - (box.left + box.width / 2);\n      r = el.getBoundingClientRect();\n    }\n    const x = Math.min(window.innerWidth - 1, Math.max(0, r.left + r.width / 2));\n    const y = Math.min(window.innerHeight - 1, Math.max(0, r.top + r.height / 2));\n    let hit = document.elementFromPoint(x, y);\n    while (hit?.shadowRoot) {\n      const inner = hit.shadowRoot.elementFromPoint(x, y);\n      if (!inner || inner === hit) break;\n      hit = inner;\n    }\n    if (!hit) return null;\n    return hit === el || el.contains(hit) || el.getRootNode() !== document && hit.contains(el) ? { x, y } : null;\n  }\n  var before = null;\n  function markShown() {\n    before = new WeakSet([document.body]);\n    for (const el of document.body.querySelectorAll("*")) if (isShown(el)) before.add(el);\n  }\n  function newlyShown(toggle) {\n    const seen = before;\n    before = null;\n    if (!seen) return null;\n    const trigger = toggleOf(toggle);\n    let best = null;\n    for (const el of document.body.querySelectorAll("*")) {\n      if (seen.has(el) || trigger && (trigger === el || trigger.contains(el))) continue;\n      if (el.parentElement && !seen.has(el.parentElement) && isShown(el.parentElement)) continue;\n      if (!isShown(el)) continue;\n      const r = el.getBoundingClientRect();\n      const area = r.width * r.height;\n      if (!best || area > best.area) best = { el, area };\n    }\n    return best && best.area >= 2e3 ? cachedSelector(best.el) : null;\n  }\n  function selectorShown(selector) {\n    const el = resolveSelector(selector);\n    return el ? isShown(el) : false;\n  }\n\n  // ../analyzers/src/types.ts\n  var DETECTOR_IDS = [\n    "page-overflow",\n    "content-overflow",\n    "media-overflow",\n    "overlap",\n    "unexpected-wrap",\n    "clipped-text",\n    "squished-text",\n    "distorted-media",\n    "small-tap-target",\n    "tiny-text",\n    "oversized-text",\n    "edge-gutter",\n    "viewport-meta"\n  ];\n\n  // ../analyzers/src/highlight.ts\n  var OVERLAY_ATTR = "data-breakhound-overlay";\n  function find(selector) {\n    return selector ? resolveSelector(selector) : null;\n  }\n  function overlay(style) {\n    const div = document.createElement("div");\n    div.setAttribute(OVERLAY_ATTR, "");\n    Object.assign(div.style, {\n      position: "absolute",\n      zIndex: "2147483647",\n      pointerEvents: "none",\n      ...style\n    });\n    document.documentElement.appendChild(div);\n  }\n  function highlight(opts) {\n    const target = find(opts.selector);\n    if (!target) return null;\n    const boxes = [{ el: target, color: "#e11d48" }];\n    const other = find(opts.related);\n    if (other && other !== target) boxes.push({ el: other, color: "#f59e0b" });\n    const sx = window.scrollX;\n    const sy = window.scrollY;\n    const vw = document.documentElement.clientWidth;\n    let top = Number.POSITIVE_INFINITY;\n    let bottom = Number.NEGATIVE_INFINITY;\n    let right = vw;\n    for (const { el, color } of boxes) {\n      const r = el.getBoundingClientRect();\n      if (r.width === 0 && r.height === 0) continue;\n      top = Math.min(top, r.top + sy);\n      bottom = Math.max(bottom, r.bottom + sy);\n      right = Math.max(right, r.right + sx);\n      overlay({\n        left: `${r.left + sx - 2}px`,\n        top: `${r.top + sy - 2}px`,\n        width: `${r.width + 4}px`,\n        height: `${r.height + 4}px`,\n        outline: `3px solid ${color}`,\n        background: `${color}14`\n      });\n    }\n    if (!Number.isFinite(top)) return null;\n    const docHeight = document.documentElement.scrollHeight;\n    const y = Math.max(0, top - opts.pad);\n    const end = Math.min(docHeight, bottom + opts.pad, y + opts.maxHeight);\n    if (opts.showEdge) {\n      overlay({\n        left: `${vw - 1}px`,\n        top: `${y}px`,\n        width: "0",\n        height: `${end - y}px`,\n        borderLeft: "2px dashed #2563eb"\n      });\n    }\n    const scrollWidth = document.documentElement.scrollWidth;\n    return {\n      x: 0,\n      y,\n      width: Math.min(Math.max(vw, Math.ceil(right) + 16), Math.max(vw, scrollWidth)),\n      height: Math.max(1, end - y)\n    };\n  }\n  function clearHighlights() {\n    for (const el of document.querySelectorAll(`[${OVERLAY_ATTR}]`)) el.remove();\n  }\n\n  // ../analyzers/src/settle.ts\n  var frame = () => new Promise((resolve) => requestAnimationFrame(() => resolve()));\n  async function settleAfterResize(maxWaitMs) {\n    await frame();\n    await frame();\n    const probe = window.__breakhound_settle;\n    if (probe && probe.pending() > 0) {\n      const deadline = performance.now() + maxWaitMs;\n      while (probe.pending() > 0 && performance.now() < deadline) {\n        await new Promise((resolve) => setTimeout(resolve, 10));\n      }\n      await frame();\n      await frame();\n    }\n    window.scrollTo(0, 0);\n  }\n\n  // ../analyzers/src/index.ts\n  var DETECTORS = {\n    "page-overflow": pageOverflow,\n    "media-overflow": mediaOverflow,\n    "content-overflow": contentOverflow,\n    overlap,\n    "clipped-text": clippedText,\n    "squished-text": squishedText,\n    "distorted-media": distortedMedia,\n    "small-tap-target": smallTapTargets,\n    "tiny-text": tinyText,\n    "oversized-text": oversizedText,\n    "edge-gutter": edgeGutter,\n    "viewport-meta": viewportMeta\n  };\n  var IGNORE_ATTR = "data-breakhound-ignore";\n  function parseDetectors(value) {\n    const list = (value ?? "").split(/[\\s,]+/).filter(Boolean);\n    return list.length === 0 || list.includes("all") ? "all" : new Set(list);\n  }\n  function isIgnored(info, detector, rules) {\n    if (!info) return false;\n    const el = elementOf(info);\n    if (!el) return false;\n    for (let p = el; p; p = composedParent(p)) {\n      if (!p.hasAttribute(IGNORE_ATTR)) continue;\n      const scope = parseDetectors(p.getAttribute(IGNORE_ATTR));\n      if (scope === "all" || scope.has(detector)) return true;\n    }\n    for (const rule of rules) {\n      if (rule.detectors && !rule.detectors.includes(detector)) continue;\n      try {\n        if (closestComposed(el, rule.selector)) return true;\n      } catch {\n      }\n    }\n    return false;\n  }\n  function analyze(options = {}) {\n    const enabled = new Set(options.detectors ?? DETECTOR_IDS);\n    const rules = options.ignore ?? [];\n    const snap = snapshot();\n    const findings = [];\n    for (const [id, run] of Object.entries(DETECTORS)) {\n      if (!enabled.has(id)) continue;\n      for (const f of run(snap)) {\n        if (isIgnored(f.element, id, rules) || isIgnored(f.related, id, rules)) continue;\n        findings.push(f);\n      }\n    }\n    const wraps = enabled.has("unexpected-wrap") ? wrapStats(snap).filter((w) => !isIgnored(w.element, "unexpected-wrap", rules)) : [];\n    const containers = containerSignature(snap);\n    return {\n      width: snap.viewportWidth,\n      findings,\n      wraps,\n      signature: layoutSignature(snap, cachedSelector),\n      ...containers ? { containers } : {},\n      ...options.toggles ? { toggles: findToggles(rules) } : {}\n    };\n  }\n  var MEDIA_CONTENT = /* @__PURE__ */ new Set([\n    "IMG",\n    "SVG",\n    "svg",\n    "CANVAS",\n    "VIDEO",\n    "IFRAME",\n    "OBJECT",\n    "EMBED"\n  ]);\n  function hasContent() {\n    const visit = (el) => {\n      if (el.matches(DEV_OVERLAYS)) return false;\n      if (MEDIA_CONTENT.has(el.tagName)) {\n        const r = el.getBoundingClientRect();\n        return r.width > 0 && r.height > 0;\n      }\n      for (const node of el.childNodes) {\n        if (node.nodeType === Node.TEXT_NODE && node.textContent?.trim()) {\n          const range = document.createRange();\n          range.selectNodeContents(node);\n          if (range.getClientRects().length > 0) return true;\n        }\n      }\n      return renderedChildren(el).some(visit);\n    };\n    return document.body ? visit(document.body) : false;\n  }\n\n  // ../analyzers/src/inject.ts\n  var api = {\n    analyze,\n    declaredBreakpoints,\n    settleAfterResize,\n    highlight,\n    clearHighlights,\n    hasContent,\n    resolveSelector,\n    toggleState,\n    setDetails,\n    clickPoint,\n    markShown,\n    newlyShown,\n    selectorShown,\n    findByText\n  };\n  window.__breakhound = api;\n})();\n');
    await evaluate(session, () => window.__breakhound?.settleAfterResize(1e3));
    const issue = job.focus ?? selectedIssue();
    if (!issue || !activeAt(issue, job.width)) {
      await evaluate(session, () => window.__breakhound?.clearHighlights());
      return;
    }
    const found = await evaluate(
      session,
      (o) => {
        const api = window.__breakhound;
        if (!api) return false;
        api.clearHighlights();
        const el = api.resolveSelector(o.selector);
        if (!el) return false;
        if (o.scroll) el.scrollIntoView({ block: "center", inline: "nearest" });
        api.highlight({
          selector: o.selector,
          related: o.related,
          showEdge: o.edge,
          pad: 0,
          maxHeight: 1e5
        });
        return true;
      },
      {
        selector: issue.element.selector,
        related: issue.related?.selector ?? null,
        edge: issue.detector === "page-overflow",
        scroll: job.scroll
      }
    );
    if (!found && job.scroll) {
      notify(
        "That element isn't on the page right now. It may only appear after something else happens, like opening a menu.",
        "note"
      );
    }
  }
  async function resetView() {
    pending = null;
    while (pumping) await pause3(20);
    if (session.isAttached) {
      await evaluate(session, () => window.__breakhound?.clearHighlights()).catch(() => {
      });
      await session.send("Emulation.clearDeviceMetricsOverride").catch(() => {
      });
      await session.detach();
    }
    state.viewing = null;
    state.natural = null;
    renderPlayhead();
    renderViewing();
    if (state.phase === "done") renderIssues();
  }
  function inspect(issue) {
    const selector = JSON.stringify(issue.element.selector);
    chrome.devtools.inspectedWindow.eval(
      `(() => {
      let el = null;
      try {
        el = window.__breakhound ? window.__breakhound.resolveSelector(${selector}) : document.querySelector(${selector});
      } catch {}
      if (el) inspect(el);
      return !!el;
    })()`,
      (found, problem) => {
        if (problem) {
          notify(
            `Couldn't select it in Elements: ${problem.isException ? problem.value : problem.details?.[0] ?? "DevTools refused"}. DevTools won't let extensions do this on chrome:// pages, the Chrome Web Store, file:// pages without file access, or a page that is still loading.`
          );
        } else if (!found) {
          notify(
            "That element isn't on the page right now. It may only appear after something else happens, like opening a menu.",
            "note"
          );
        }
      }
    );
  }
  function activeAt(issue, width) {
    return issue.ranges.some((r) => width >= r.from && width <= r.to);
  }
  function selectedIssue() {
    return state.result?.issues.find((i) => i.id === state.selected) ?? null;
  }
  function visibleIssues() {
    const issues = state.result?.issues ?? [];
    const f = state.filter;
    if (f === "all") return issues;
    if (f === "here") {
      const at = state.viewing;
      return at === null ? issues : issues.filter((i) => activeAt(i, at));
    }
    return issues.filter((i) => i.severity === f);
  }
  function select(issue, width) {
    state.selected = issue?.id ?? null;
    renderIssues();
    renderLanes();
    if (issue) view(width ?? issue.worstAt, { focus: issue, scroll: true });
  }
  function renderToolbar() {
    const scanning = state.phase === "scanning";
    label(ui.scan, "sweep", state.result ? "Scan again" : "Scan");
    ui.scan.disabled = scanning;
    ui.stop.hidden = !scanning;
    ui.stop.disabled = state.stopping;
    label(ui.stop, "stop", state.stopping ? "Stopping" : "Stop");
    ui.min.disabled = scanning;
    ui.max.disabled = scanning;
    for (const b of [allWidths, ...deviceButtons]) b.disabled = scanning;
    ui.reload.disabled = scanning;
    ui.modePage.disabled = scanning;
    ui.modeSite.disabled = scanning;
    ui.modePage.setAttribute("aria-pressed", String(state.mode === "page"));
    ui.modeSite.setAttribute("aria-pressed", String(state.mode === "site"));
    ui.reloadSwitch.hidden = state.mode === "site";
    ui.copyAll.hidden = scanning || !state.pages.some((p) => p.route.issues.some((i) => i.severity !== "info"));
    ui.send.hidden = ui.copyAll.hidden;
    ui.send.disabled = agent.sending;
    label(ui.send, "send", agent.sending ? "Sending" : "Send to agent");
  }
  function renderPages() {
    const site = state.pages.length > 1 || state.scanning !== null || state.from !== null;
    ui.pages.hidden = !site;
    ui.rulerPage.hidden = !site;
    const shown = state.phase === "scanning" ? state.scanning?.route : state.result?.route;
    ui.rulerPage.textContent = shown ?? "";
    if (!site) return;
    const chips = state.pages.map((p, i) => {
      const r = p.route;
      const worst = SEVERITIES.find((s) => r.issues.some((x2) => x2.severity === s));
      const dot = r.status !== "scanned" ? "failed" : worst ?? "clean";
      const selected = state.phase === "done" && i === state.current;
      const chip = h(
        "button",
        {
          class: "page-chip",
          type: "button",
          role: "tab",
          "aria-selected": String(selected),
          title: r.status === "scanned" ? `${r.url}
${r.issues.length} ${r.issues.length === 1 ? "issue" : "issues"}` : `${r.url}
${r.error ?? "Could not be scanned"}`
        },
        h("i", { class: `dot ${dot}` }),
        h("span", { class: "path" }, r.route),
        r.status === "scanned" ? h("span", { class: "count" }, String(r.issues.length)) : null
      );
      chip.addEventListener("click", () => {
        if (state.phase !== "done" || i === state.current) return;
        showPage(i);
        render();
        if (state.viewing !== null) view(state.viewing);
      });
      return chip;
    });
    if (state.phase === "scanning" && state.scanning) {
      chips.push(
        h(
          "span",
          { class: "page-chip pending" },
          h("i", { class: "dot" }),
          h("span", { class: "path" }, state.scanning.route)
        )
      );
    }
    ui.pages.replaceChildren(...chips);
  }
  function stat(name, value, sub, cls = "") {
    return h(
      "div",
      { class: `stat ${cls}` },
      h("div", { class: "label" }, name),
      h("div", { class: "value" }, value),
      h("div", { class: "sub" }, sub)
    );
  }
  function liveCounts() {
    let layouts = 0;
    let problems = 0;
    let last = null;
    for (const w of [...state.live.keys()].sort((a, b) => a - b)) {
      const m = state.live.get(w);
      if (!m) continue;
      if (m.layout !== last) layouts++;
      last = m.layout;
      if (m.worst) problems++;
    }
    return { layouts, problems };
  }
  function duration(ms) {
    const seconds = ms / 1e3;
    if (seconds < 10) return `${seconds.toFixed(1)}s`;
    if (seconds < 60) return `${Math.round(seconds)}s`;
    const whole = Math.round(seconds);
    return `${Math.floor(whole / 60)}m ${String(whole % 60).padStart(2, "0")}s`;
  }
  function renderStats() {
    const { min, max } = state.range;
    if (state.phase === "scanning") {
      const at = state.scanAt ?? min;
      const pct = Math.max(0, Math.min(100, Math.round((at - min) / (max - min) * 100)));
      const { layouts, problems } = liveCounts();
      const page = state.scanning;
      ui.status.textContent = state.paused ? "Paused: the tab is out of view" : state.checking ? `Checking your agent's fixes \xB7 ${page ? `page ${page.index + 1} of ${page.planned} \xB7 ` : ""}${pct}%` : page ? `Page ${page.index + 1} of about ${page.planned} \xB7 ${pct}%` : `Sniffing \xB7 ${pct}%`;
      if (page) {
        const found = state.pages.reduce((n, p) => n + p.route.issues.length, 0);
        ui.stats.replaceChildren(
          stat("Page", `${page.index + 1} of ${page.planned}`, page.route),
          stat("Measuring", `${at}px`, `${pct}% of the way to ${max}px`),
          stat(
            "Time",
            duration(Date.now() - state.startedAt.getTime()),
            `${state.pages.length} ${state.pages.length === 1 ? "page" : "pages"} done`
          ),
          stat("Issues so far", String(found), "on the pages done")
        );
        return;
      }
      ui.stats.replaceChildren(
        stat("Measuring", `${at}px`, `${pct}% of the way to ${max}px`),
        stat(
          "Time",
          duration(Date.now() - state.startedAt.getTime()),
          `${state.measured} ${state.measured === 1 ? "width" : "widths"} measured so far`
        ),
        stat("Layouts so far", String(layouts), "runs of widths that share a layout"),
        stat(
          "Something breaks at",
          String(problems),
          problems === 1 ? "width so far" : "widths so far"
        )
      );
      return;
    }
    ui.status.textContent = "";
    const r = state.result;
    if (!r) return;
    const bp = r.breakpoints;
    const url = new URL(r.url);
    if (state.pages.length > 1 || state.from) {
      const { summary } = createScanResult(
        state.pages.map((p) => p.route),
        { version: "1.0.5", startedAt: state.startedAt, minWidth: min, maxWidth: max, step: 16 }
      );
      const scanned = state.pages.filter((p) => p.route.status === "scanned").length;
      const failed = state.pages.length - scanned;
      const total = state.pages.reduce((n, p) => n + p.route.durationMs, 0);
      ui.stats.replaceChildren(
        stat(
          "Issues",
          String(summary.uniqueIssues),
          h(
            "span",
            { class: "sevs" },
            ...SEVERITIES.flatMap((s) => {
              const n = summary.bySeverity[s];
              return n ? [h("span", {}, h("i", { class: `dot ${s}` }), `${n} ${s}`)] : [];
            }),
            summary.uniqueIssues ? null : "nothing breaks"
          )
        ),
        stat(
          "Pages",
          String(scanned),
          failed ? `${failed} could not be scanned` : `found from ${state.from ?? "links"}`
        ),
        stat("Scan time", duration(total), `${min}\u2013${max}px on every page`),
        stat(
          "This page",
          url.pathname + url.hash,
          r.status === "scanned" ? `${bp.observed.length} layout ${bp.observed.length === 1 ? "change" : "changes"}` : "could not be scanned",
          "page"
        )
      );
      return;
    }
    ui.stats.replaceChildren(
      stat(
        "Issues",
        String(r.issues.length),
        h(
          "span",
          { class: "sevs" },
          ...SEVERITIES.flatMap((s) => {
            const n = r.issues.filter((i) => i.severity === s).length;
            return n ? [h("span", {}, h("i", { class: `dot ${s}` }), `${n} ${s}`)] : [];
          }),
          r.issues.length ? null : "nothing breaks"
        )
      ),
      stat(
        "Layout changes",
        String(bp.observed.length),
        bp.unexplained.length ? `${bp.unexplained.length} with no media or container query` : bp.observed.length ? "all at media or container queries" : "one layout at every width"
      ),
      stat("Scan time", duration(r.durationMs), `${r.measurements} widths, ${min}\u2013${max}px`),
      stat("Page", url.pathname + url.hash, url.host, "page")
    );
  }
  function x(width) {
    const { min, max } = state.range;
    return (width - min) / (max - min) * 100;
  }
  function cssVar(name) {
    return getComputedStyle(document.documentElement).getPropertyValue(name).trim();
  }
  function drawZones() {
    const canvas = ui.zones;
    const dpr = window.devicePixelRatio || 1;
    const w = canvas.clientWidth;
    const ht = canvas.clientHeight;
    if (!w || !ht) return;
    if (canvas.width !== Math.round(w * dpr) || canvas.height !== Math.round(ht * dpr)) {
      canvas.width = Math.round(w * dpr);
      canvas.height = Math.round(ht * dpr);
    }
    const g = canvas.getContext("2d");
    if (!g) return;
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    g.clearRect(0, 0, w, ht);
    g.save();
    g.beginPath();
    g.roundRect(0, 0, w, ht, 4);
    g.clip();
    g.fillStyle = cssVar("--surface");
    g.fillRect(0, 0, w, ht);
    const colors = {
      a: cssVar("--zone-a"),
      b: cssVar("--zone-b"),
      change: cssVar("--change"),
      unexplained: cssVar("--unexplained"),
      error: cssVar("--error"),
      warning: cssVar("--warning"),
      info: cssVar("--info")
    };
    const px = (width) => Math.round(x(width) / 100 * w);
    const unexplained = new Set(state.result?.breakpoints.unexplained ?? []);
    const end = state.phase === "scanning" ? state.scanAt ?? state.range.min : state.range.max;
    const widths = [...state.live.keys()].sort((a, b) => a - b);
    const bands = ht - 6;
    const zones = [];
    const problems = [];
    for (let i = 0; i < widths.length; i++) {
      const width = widths[i];
      const m = state.live.get(width);
      if (!m) continue;
      const to = widths[i + 1] ?? Math.max(width, end);
      const zone = zones[zones.length - 1];
      if (zone && zone.layout === m.layout) zone.to = to;
      else zones.push({ from: width, to, layout: m.layout });
      const worst = state.result ? worstIssueAt(width) : m.worst;
      const problem = problems[problems.length - 1];
      if (worst && problem && problem.worst === worst && problem.to === width) problem.to = to;
      else if (worst) problems.push({ from: width, to, worst });
    }
    zones.forEach((zone, i) => {
      g.fillStyle = i % 2 ? colors.b : colors.a;
      g.fillRect(px(zone.from), 0, Math.max(1, px(zone.to) - px(zone.from)), bands);
      if (i === 0) return;
      const odd = unexplained.has(zone.from);
      g.fillStyle = odd ? colors.unexplained : colors.change;
      g.fillRect(px(zone.from) - (odd ? 1 : 0), 0, odd ? 2 : 1, bands);
    });
    for (const p of problems) {
      g.fillStyle = colors[p.worst];
      g.fillRect(px(p.from), ht - 4, Math.max(2, px(p.to) - px(p.from)), 4);
    }
    g.restore();
  }
  function worstIssueAt(width) {
    const here = state.result?.issues.filter((i) => activeAt(i, width)) ?? [];
    return SEVERITIES.find((s) => here.some((i) => i.severity === s)) ?? null;
  }
  function labelStep() {
    const span = state.range.max - state.range.min;
    const width = ui.timeline.clientWidth || 600;
    for (const step of [50, 100, 200, 250, 500, 1e3]) {
      if (step / span * width >= 64) return step;
    }
    return 2e3;
  }
  function renderAxis() {
    const { min, max } = state.range;
    const step = labelStep();
    const items = [h("span", { class: "label start", style: "left:0" }, `${min}`)];
    for (let w = Math.ceil((min + 1) / step) * step; w < max; w += step) {
      if (x(w) < 5 || x(w) > 95) continue;
      items.push(h("span", { class: "tick", style: `left:${x(w)}%` }));
      items.push(h("span", { class: "label", style: `left:${x(w)}%` }, `${w}`));
    }
    items.push(h("span", { class: "label end", style: "left:100%" }, `${max}`));
    const bp = state.phase === "done" ? state.result?.breakpoints : void 0;
    for (const w of bp?.declared ?? []) {
      items.push(
        h("span", { class: "declared", style: `left:${x(w)}%`, title: `Media query at ${w}px` })
      );
    }
    for (const w of bp?.unexplained ?? []) {
      items.push(
        h("span", {
          class: "unexplained",
          style: `left:${x(w)}%`,
          title: `The layout changes at ${w}px with no media or container query there`
        })
      );
    }
    ui.axis.replaceChildren(...items);
    const devices = [
      { width: 375, name: "Phone" },
      { width: 768, name: "Tablet" },
      { width: 1280, name: "Laptop" },
      { width: 1536, name: "Desktop" }
    ];
    const total = ui.timeline.clientWidth || 600;
    let lastPct = Number.NEGATIVE_INFINITY;
    const shown = [];
    for (const d of devices) {
      const pct = x(d.width);
      if (pct < 4 || pct > 96 || (pct - lastPct) / 100 * total < 56) continue;
      lastPct = pct;
      shown.push(h("span", { style: `left:${pct}%`, title: `${d.width}px` }, d.name));
    }
    ui.devices.replaceChildren(...shown);
  }
  function renderLanes() {
    const issues = state.phase === "done" ? visibleIssues() : [];
    const rows = [];
    const sorted = [...issues].sort((a, b) => (a.ranges[0]?.from ?? 0) - (b.ranges[0]?.from ?? 0));
    const gap = (state.range.max - state.range.min) * 0.01;
    for (const issue of sorted) {
      const from = issue.ranges[0]?.from ?? 0;
      const to = issue.ranges[issue.ranges.length - 1]?.to ?? from;
      let row = rows.find((r) => r.end + gap < from);
      if (!row) {
        row = { end: to, issues: [] };
        rows.push(row);
      }
      row.end = to;
      row.issues.push(issue);
    }
    ui.lanes.classList.toggle("focus", !!state.selected);
    ui.lanes.replaceChildren(
      ...rows.map(
        (row) => h(
          "div",
          { class: "lane" },
          ...row.issues.flatMap(
            (issue) => issue.ranges.map(
              (r) => h("span", {
                class: `lane-bar ${issue.severity}${issue.id === state.selected ? " selected" : ""}`,
                style: `left:${x(r.from)}%;width:${Math.max(0, x(r.to) - x(r.from))}%`,
                title: `${issue.title} \xB7 ${formatRange(r)}`,
                "data-id": issue.id
              })
            )
          )
        )
      )
    );
  }
  function placeLine(line, width, text) {
    const pct = x(width);
    line.style.left = `${pct}%`;
    line.classList.toggle("left", pct < 4);
    line.classList.toggle("right", pct > 96);
    line.firstElementChild.textContent = text;
  }
  function renderPlayhead() {
    const scanning = state.phase === "scanning";
    const width = scanning ? state.scanAt : state.viewing;
    ui.timeline.classList.toggle("scanning", scanning);
    ui.playhead.hidden = width === null;
    if (width !== null) placeLine(ui.playhead, width, `${width}px`);
    ui.timeline.setAttribute("aria-valuemin", String(state.range.min));
    ui.timeline.setAttribute("aria-valuemax", String(state.range.max));
    ui.timeline.setAttribute("aria-valuenow", String(state.viewing ?? state.range.min));
    ui.timeline.setAttribute(
      "aria-valuetext",
      state.viewing === null ? "The tab is at its own width" : `${state.viewing}px`
    );
  }
  function renderViewing() {
    const w = state.viewing;
    ui.viewing.hidden = w === null || state.phase === "scanning";
    if (w !== null) {
      const scale = fitScale(w, state.natural ?? void 0);
      ui.viewingText.textContent = scale < 1 ? `Showing ${w}px, zoomed to ${Math.round(scale * 100)}% to fit` : `Showing ${w}px`;
    }
    if (state.phase === "done") {
      renderFilters();
      markHere();
    }
  }
  function renderTimeline() {
    renderAxis();
    renderLanes();
    drawZones();
    renderPlayhead();
    renderViewing();
  }
  function renderFilters() {
    const r = state.result;
    if (!r || state.phase !== "done" || !r.issues.length) {
      ui.filters.replaceChildren();
      return;
    }
    if (state.filter === "here" && state.viewing === null) state.filter = "all";
    const chip = (f, text, n, dot) => {
      const b = h(
        "button",
        { class: "chip", type: "button", "aria-pressed": String(state.filter === f) },
        dot ? h("i", { class: `dot ${dot}` }) : null,
        text,
        h("span", { class: "count" }, String(n))
      );
      b.addEventListener("click", () => {
        state.filter = f;
        renderFilters();
        renderIssues();
        renderLanes();
      });
      return b;
    };
    const chips = [chip("all", "All", r.issues.length)];
    for (const s of SEVERITIES) {
      const n = r.issues.filter((i) => i.severity === s).length;
      if (n) chips.push(chip(s, `${SEVERITY_NAMES[s]}s`, n, s));
    }
    const at = state.viewing;
    if (at !== null) {
      chips.push(chip("here", `At ${at}px`, r.issues.filter((i) => activeAt(i, at)).length, "here"));
    }
    ui.filters.replaceChildren(...chips);
  }
  function markHere() {
    if (state.filter === "here") {
      renderIssues();
      return;
    }
    for (const li of ui.issues.querySelectorAll(".issue")) {
      const issue = state.result?.issues.find((i) => i.id === li.dataset.id);
      li.classList.toggle(
        "here",
        !!issue && state.viewing !== null && activeAt(issue, state.viewing)
      );
    }
  }
  function issueRow(issue) {
    const selected = issue.id === state.selected;
    const head = h(
      "button",
      { class: "issue-head", type: "button", "aria-expanded": String(selected) },
      h("i", { class: `dot ${issue.severity}` }),
      h(
        "span",
        { class: "issue-title" },
        issue.title,
        " ",
        h("span", { class: "here-tag" }, "at this width")
      ),
      h("span", { class: "ranges" }, formatRanges(issue.ranges)),
      h(
        "span",
        { class: "issue-meta" },
        h("span", {}, DETECTOR_LABELS[issue.detector]),
        h("code", {}, issue.element.selector)
      )
    );
    head.addEventListener("click", () => select(selected ? null : issue));
    const here = state.viewing !== null && activeAt(issue, state.viewing);
    const li = h(
      "li",
      {
        class: `issue${selected ? " selected" : ""}${here ? " here" : ""}`,
        "data-id": issue.id
      },
      head
    );
    if (selected && !state.wide) li.append(detailFor(issue));
    return li;
  }
  function evidenceRows(issue) {
    const rows = [];
    for (const [key, value] of Object.entries(issue.evidence)) {
      const name = key.replace(/([A-Z])/g, " $1").toLowerCase();
      const text = typeof value === "number" && /px|width|height|overflow/i.test(key) ? `${value}px` : String(value);
      rows.push(
        h("dt", {}, `${name.charAt(0).toUpperCase()}${name.slice(1)}`),
        h("dd", { class: "num" }, text)
      );
    }
    return rows;
  }
  function detailFor(issue) {
    const copySelector = h("button", {
      class: "icon-btn",
      type: "button",
      title: "Copy selector",
      "aria-label": "Copy selector"
    });
    copySelector.append(icon("copy"));
    copySelector.addEventListener("click", () => void copyWith(copySelector, issue.element.selector));
    return h(
      "div",
      { class: "detail" },
      h(
        "div",
        { class: "badges" },
        h("span", { class: `badge ${issue.severity}` }, SEVERITY_NAMES[issue.severity]),
        h("span", { class: "badge" }, DETECTOR_LABELS[issue.detector])
      ),
      h("h2", {}, issue.title),
      h(
        "div",
        { class: "range-chips" },
        ...issue.ranges.map((r) => {
          const b = h(
            "button",
            { class: "range-chip", type: "button", title: `Show the page at ${r.from}px` },
            formatRange(r)
          );
          b.addEventListener("click", () => view(r.from, { focus: issue, scroll: true }));
          return b;
        }),
        h("span", {}, `worst at ${issue.worstAt}px`)
      ),
      h(
        "dl",
        { class: "facts" },
        h("dt", {}, "Element"),
        h("dd", {}, h("code", {}, issue.element.selector), copySelector),
        issue.related && h("dt", {}, "Together with"),
        issue.related && h("dd", {}, h("code", {}, issue.related.selector)),
        issue.element.text && h("dt", {}, "Text"),
        issue.element.text && h("dd", {}, `\u201C${issue.element.text}\u201D`),
        ...evidenceRows(issue)
      ),
      issue.suggestion && h("div", { class: "fix" }, h("h3", {}, "Likely fix"), h("p", {}, issue.suggestion)),
      h(
        "div",
        { class: "actions" },
        button(
          "target",
          `Show at ${issue.worstAt}px`,
          () => view(issue.worstAt, { focus: issue, scroll: true })
        ),
        inDevtools && button("inspect", "Select in Elements", () => inspect(issue)),
        button("copy", "Copy prompt", (b) => void copyWith(b, prompt([issue.fingerprint])))
      )
    );
  }
  function overview() {
    const r = state.result;
    const bp = r.breakpoints;
    const unexplained = new Set(bp.unexplained);
    return h(
      "div",
      { class: "detail" },
      h("h3", {}, "Layout changes"),
      bp.observed.length ? h(
        "div",
        { class: "changes" },
        ...bp.observed.map((w) => {
          const odd = unexplained.has(w);
          const b = h(
            "button",
            {
              class: `range-chip${odd ? " unexplained" : ""}`,
              type: "button",
              title: odd ? "No media or container query here" : "At a media or container query"
            },
            `${w}px`
          );
          b.addEventListener("click", () => view(w));
          return b;
        })
      ) : h("p", { class: "muted" }, "The layout is the same at every width."),
      h(
        "p",
        { class: "muted" },
        r.issues.length ? "Pick an issue to see the page at the width where it is worst, with the element outlined." : "Drag across the timeline to watch the page at any width."
      )
    );
  }
  function renderIssues() {
    ui.split.classList.toggle("wide", state.wide && state.phase === "done");
    if (state.phase === "scanning") {
      ui.issues.replaceChildren(
        h(
          "li",
          { class: "empty-list" },
          h("strong", {}, "Sniffing\u2026"),
          "Issues are listed as soon as every width is measured."
        )
      );
      ui.detail.hidden = true;
      return;
    }
    const r = state.result;
    if (!r) return;
    if (r.status !== "scanned") {
      ui.issues.replaceChildren(
        h(
          "li",
          { class: "empty-list" },
          h("strong", {}, "This page couldn't be scanned."),
          r.error ?? ""
        )
      );
      ui.detail.hidden = true;
      return;
    }
    const issues = visibleIssues();
    if (!r.issues.length) {
      ui.issues.replaceChildren(
        h(
          "li",
          { class: "empty-list" },
          h("strong", {}, "Nothing breaks."),
          `No issues between ${state.range.min}px and ${state.range.max}px.`
        )
      );
    } else if (!issues.length) {
      ui.issues.replaceChildren(h("li", { class: "empty-list" }, "Nothing here with this filter."));
    } else {
      ui.issues.replaceChildren(...issues.map(issueRow));
    }
    ui.detail.hidden = !state.wide;
    if (state.wide) {
      const selected = selectedIssue();
      ui.detail.replaceChildren(...(selected ? detailFor(selected) : overview()).childNodes);
    }
  }
  function render() {
    document.body.dataset.phase = state.phase;
    const showResults = state.phase === "scanning" || state.pages.some((p) => p.route.status === "scanned");
    ui.intro.hidden = showResults;
    ui.results.hidden = !showResults;
    renderToolbar();
    if (!showResults) return;
    renderStats();
    renderPages();
    renderFilters();
    renderIssues();
    renderTimeline();
  }
  function widthAt(clientX) {
    const box = ui.timeline.getBoundingClientRect();
    const frac = Math.min(1, Math.max(0, (clientX - box.left) / box.width));
    const { min, max } = state.range;
    return Math.round(min + frac * (max - min));
  }
  var dragging = false;
  ui.timeline.addEventListener("pointerdown", (e) => {
    if (state.phase !== "done" || e.button !== 0) return;
    const width = widthAt(e.clientX);
    const bar = e.target.closest(".lane-bar");
    const issue = bar ? state.result?.issues.find((i) => i.id === bar.dataset.id) : void 0;
    if (issue) {
      select(issue, activeAt(issue, width) ? width : issue.worstAt);
      return;
    }
    dragging = true;
    ui.timeline.setPointerCapture(e.pointerId);
    ui.hover.hidden = true;
    view(width, { settle: false });
  });
  ui.timeline.addEventListener("pointermove", (e) => {
    if (state.phase !== "done") return;
    const width = widthAt(e.clientX);
    if (dragging) {
      view(width, { settle: false });
      return;
    }
    ui.hover.hidden = false;
    placeLine(ui.hover, width, `${width}px`);
  });
  var endDrag = (e) => {
    if (!dragging) return;
    dragging = false;
    ui.timeline.releasePointerCapture(e.pointerId);
    view(widthAt(e.clientX));
  };
  ui.timeline.addEventListener("pointerup", endDrag);
  ui.timeline.addEventListener("pointercancel", endDrag);
  ui.timeline.addEventListener("pointerleave", () => {
    ui.hover.hidden = true;
  });
  var keyTimer;
  ui.timeline.addEventListener("keydown", (e) => {
    if (state.phase !== "done") return;
    const from = state.viewing ?? state.natural?.width ?? state.range.min;
    const step = e.shiftKey ? 10 : 1;
    let to = null;
    if (e.key === "ArrowRight" || e.key === "ArrowUp") to = from + step;
    else if (e.key === "ArrowLeft" || e.key === "ArrowDown") to = from - step;
    else if (e.key === "Home") to = state.range.min;
    else if (e.key === "End") to = state.range.max;
    else if (e.key === "Escape") {
      void resetView();
      return;
    } else return;
    e.preventDefault();
    view(to, { settle: false });
    clearTimeout(keyTimer);
    keyTimer = setTimeout(() => {
      if (state.viewing !== null) view(state.viewing);
    }, 250);
  });
  ui.issues.addEventListener("keydown", (e) => {
    if (e.key !== "ArrowDown" && e.key !== "ArrowUp") return;
    const heads = [...ui.issues.querySelectorAll(".issue-head")];
    const at = heads.indexOf(document.activeElement);
    if (at === -1) return;
    e.preventDefault();
    heads[Math.max(0, Math.min(heads.length - 1, at + (e.key === "ArrowDown" ? 1 : -1)))]?.focus();
  });
  label(ui.introScan, "sweep", "Scan this page");
  label(ui.copyAll, "copy", "Copy prompt");
  label(ui.viewingReset, "reset", "Back to its own width");
  ui.noticeClose.append(icon("close"));
  ui.scan.addEventListener("click", () => void scan());
  ui.introScan.addEventListener("click", () => void scan());
  ui.stop.addEventListener("click", () => {
    state.stopping = true;
    renderToolbar();
  });
  ui.viewingReset.addEventListener("click", () => void resetView());
  ui.noticeClose.addEventListener("click", () => notify(null));
  ui.copyAll.addEventListener("click", () => void copyWith(ui.copyAll, prompt()));
  ui.send.addEventListener("click", () => void sendToAgent());
  ui.noticeAction.addEventListener("click", () => noticeAction?.(ui.noticeAction));
  ui.agent.addEventListener("click", () => {
    void findServers().then((servers) => {
      const projects = byProject(servers);
      if (!projects.length) {
        agent.online = false;
        renderAgent();
        return;
      }
      pickProject(projects, (server) => {
        void tabUrl().then((url) => {
          const origin = originOf(url);
          if (origin) remember(origin, server.root);
          listen(server);
        });
      });
    });
  });
  addEventListener("keydown", (e) => {
    if (e.key === "Escape") hideMenu();
  });
  addEventListener("click", (e) => {
    const target = e.target;
    if (!ui.agentMenu.hidden && !ui.agentMenu.contains(target) && !ui.send.contains(target) && !ui.agent.contains(target))
      hideMenu();
  });
  for (const input of [ui.min, ui.max, ui.reload]) input.addEventListener("change", saveSettings);
  for (const [button2, mode] of [
    [ui.modePage, "page"],
    [ui.modeSite, "site"]
  ]) {
    button2.addEventListener("click", () => {
      state.mode = mode;
      saveSettings();
      renderToolbar();
    });
  }
  session.onHidden = (hidden) => {
    state.paused = hidden;
    if (hidden) {
      notify(
        "Paused while the tab is out of view. Chrome stops drawing hidden tabs, so breakhound waits, and carries on by itself when you switch back to it.",
        "note"
      );
      scheduleLive();
    } else {
      notify(null);
      scheduleLive();
    }
  };
  session.onDetach = () => {
    if (inDevtools) {
      chrome.devtools.inspectedWindow.eval(
        `document.querySelectorAll(${JSON.stringify(LEFTOVERS)}).forEach((el) => el.remove())`,
        () => {
        }
      );
    }
    state.stopping = state.phase === "scanning";
    pending = null;
    state.viewing = null;
    state.natural = null;
    renderPlayhead();
    renderViewing();
  };
  function pageChanged() {
    if (state.phase === "scanning" || navigating || Date.now() - navigatedAt < 3e3) return;
    void resetView();
    if (state.result && state.pages.length === 1) {
      notify("The page changed since this scan. Scan again to see where it stands now.", "note");
    }
  }
  if (inDevtools) {
    chrome.devtools.network.onNavigated.addListener(pageChanged);
  } else {
    chrome.tabs?.onUpdated.addListener((id, change) => {
      if (id === tabId && change.status === "loading") pageChanged();
    });
  }
  var WIDE_AT = 760;
  var laidOutAt = document.body.clientWidth;
  var relayout = 0;
  new ResizeObserver(() => {
    const width = document.body.clientWidth;
    if (width === laidOutAt || relayout) return;
    relayout = requestAnimationFrame(() => {
      relayout = 0;
      laidOutAt = document.body.clientWidth;
      const wide = laidOutAt - 24 >= WIDE_AT;
      if (wide !== state.wide) {
        state.wide = wide;
        if (state.phase === "done") renderIssues();
      }
      if (!ui.results.hidden) {
        renderAxis();
        drawZones();
      }
    });
  }).observe(document.body);
  var refit = 0;
  addEventListener("resize", () => {
    clearTimeout(refit);
    refit = window.setTimeout(() => {
      if (state.viewing === null || state.phase === "scanning" || !session.isAttached) return;
      measureAgain = true;
      view(state.viewing);
    }, 300);
  });
  addEventListener("unhandledrejection", (e) => {
    e.preventDefault();
    const reason = e.reason instanceof Error ? e.reason.message : String(e.reason);
    console.warn("breakhound:", e.reason);
    notify(`Something went wrong: ${reason}`);
  });
  addEventListener("pagehide", () => {
    if (session.isAttached) void session.detach();
  });
  loadSettings();
  renderPresets();
  state.wide = document.body.clientWidth - 24 >= WIDE_AT;
  render();
  if (scanOnOpen) void scan();
  void reconnect();
})();
