"use strict";
(() => {
  // packages/extension/src/background.ts
  var MENU_ID = "breakhound-scan";
  var PAGES = ["http://*/*", "https://*/*", "file:///*"];
  function sidePanelPath(tabId, scan) {
    return `panel.html?tab=${tabId}${scan ? `&scan=${Date.now()}` : ""}`;
  }
  function openPanel(tabId, scan) {
    if (tabId === void 0 || tabId < 0) return;
    chrome.sidePanel.setOptions({ tabId, path: sidePanelPath(tabId, scan), enabled: true }).catch(() => {
    });
    chrome.sidePanel.open({ tabId }).catch((error) => {
      console.warn("breakhound: could not open the side panel", error);
    });
  }
  chrome.runtime.onInstalled.addListener(() => {
    chrome.contextMenus.removeAll(
      () => chrome.contextMenus.create({
        id: MENU_ID,
        title: "Scan with breakhound",
        contexts: ["page", "frame", "selection", "link", "image", "video", "audio", "editable"],
        documentUrlPatterns: PAGES
      })
    );
  });
  chrome.contextMenus.onClicked.addListener((info, tab) => {
    if (info.menuItemId === MENU_ID) openPanel(tab?.id, true);
  });
  chrome.action.onClicked.addListener((tab) => openPanel(tab.id, false));
})();
